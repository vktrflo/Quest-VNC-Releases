<#
.SYNOPSIS
    Quest VNC setup for Windows: installs TightVNC Server and the Quest VNC sound sender in one go.

.DESCRIPTION
    Normally started by double-clicking "Install Quest VNC.cmd". It asks for:
      * the VNC port (default 5900),
      * the sound port (default 5910),
      * a password (typed twice), used for both the picture (VNC) and the sound,
    then installs or reconfigures TightVNC Server (as a Windows service), copies QuestVncAudio.exe to
    "%ProgramFiles%\Quest VNC", opens both ports in Windows Firewall for Private networks, and makes the
    sound sender start hidden at every sign-in of the user who ran the setup.

    Running it again upgrades in place and lets you change the ports or the password.
    Works with Windows PowerShell 5.1 (built into Windows 10 and 11); needs no extra modules.

.PARAMETER VncPort
    TCP port for TightVNC. Skips the question.
.PARAMETER AudioPort
    TCP port for the sound sender. Skips the question.
.PARAMETER Password
    Password for VNC and sound. Passing it makes the setup unattended (no questions).
.PARAMETER Unattended
    Ask nothing: ports not given keep their current values (or the defaults), and the password must be given
    with -Password unless a previous install's password can be kept.
.PARAMETER Uninstall
    Removes the sound sender, its sign-in task, firewall rules and files, and asks whether to remove TightVNC too.
.PARAMETER RemoveTightVnc
    With -Uninstall: also uninstall TightVNC without asking.
.PARAMETER KeepTightVnc
    With -Uninstall: keep TightVNC without asking.
.PARAMETER TargetUser
    Account whose sign-in starts the sound sender (DOMAIN\name). Defaults to the user who started the setup.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -VncPort 5900 -AudioPort 5910 -Password s3cret
.EXAMPLE
    powershell -ExecutionPolicy Bypass -File install.ps1 -Uninstall -RemoveTightVnc
#>
[CmdletBinding()]
param(
    [int]$VncPort = 0,
    [int]$AudioPort = 0,
    [string]$Password,
    [switch]$Unattended,
    [switch]$Uninstall,
    [switch]$RemoveTightVnc,
    [switch]$KeepTightVnc,
    [string]$TargetUser,
    [string]$TargetLocalAppData,
    [switch]$PauseAtEnd,
    # Internal: the password handed from the non-elevated to the elevated run, Base64 (UTF-8), so quotes survive.
    [string]$PasswordBase64
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'   # Invoke-WebRequest is very slow in 5.1 when it draws progress

# ----------------------------------------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------------------------------------
$Script:ProductName      = 'Quest VNC'
$Script:SetupVersion     = '1.0.0'
$Script:PasswordGiven    = $false   # set from the command line at the entry point
$Script:DefaultVncPort   = 5900
$Script:DefaultAudioPort = 5910
$Script:ScanPorts        = @(5900, 5901, 5902, 5903)   # what the headset app's Scan button tries
$Script:InstallDir       = [IO.Path]::Combine("$env:ProgramFiles", 'Quest VNC')
$Script:SenderExeName    = 'QuestVncAudio.exe'
$Script:ConfigKey        = 'HKLM:\SOFTWARE\Quest VNC'
$Script:UninstallKey     = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\QuestVNC'
$Script:TaskPath         = '\Quest VNC\'
$Script:FirewallGroup    = 'Quest VNC'
$Script:TightVncKey      = 'HKLM:\SOFTWARE\TightVNC\Server'
$Script:TightVncService  = 'tvnserver'
$Script:WingetId         = 'GlavSoft.TightVNC'
# Fallback when winget isn't available. Pinned release; hash from the winget-pkgs manifest for this version.
# The file must also carry a valid GlavSoft Authenticode signature, which is the check that really counts.
$Script:TightVncMsiUrl    = 'https://www.tightvnc.com/download/2.8.89/tightvnc-2.8.89-gpl-setup-64bit.msi'
$Script:TightVncMsiSha256 = 'DFF8D7E40A81E0B86BA1D9D5CC0D4F22D08354C50C9CBDC0825BBB6CCFB1073C'
# VNC stores passwords DES-encrypted with this fixed key (the d3des key 23,82,107,6,35,78,88,7 with each byte's
# bits reversed, which is what standard DES implementations such as .NET's expect).
$Script:VncDesKey = [byte[]](0xE8, 0x4A, 0xD6, 0x60, 0xC4, 0x72, 0x1A, 0xE0)

# ----------------------------------------------------------------------------------------------------------
# Pure helpers (no system changes; unit-tested by tests/install.tests.ps1)
# ----------------------------------------------------------------------------------------------------------

function Test-PortText {
    <# Returns an error message for a port typed by the user, or $null when it's a usable number. #>
    param([string]$Text)
    $t = "$Text".Trim()
    if ($t -notmatch '^\d{1,5}$') { return "'$t' is not a port number. Use a whole number from 1024 to 65535." }
    $n = [int]$t
    if ($n -lt 1024 -or $n -gt 65535) { return "Port $n is out of range. Use 1024 to 65535 (5900 is the usual VNC port)." }
    return $null
}

function Get-PortConflict {
    <#
        Why a port can't be used, or $null.
          $Port         the port being checked
          $OtherPort    the port already chosen for the other service (0 = none yet)
          $Listeners    hashtable port -> process name, for ports something is listening on now
          $OwnNames     process names that belong to this setup (re-running may reuse their ports)
          $Excluded     array of @(start, end) ranges Windows reserves (Hyper-V, WSL, ...)
    #>
    param([int]$Port, [int]$OtherPort, [hashtable]$Listeners, [string[]]$OwnNames, [object[]]$Excluded)
    if ($OtherPort -ne 0 -and $Port -eq $OtherPort) { return "Port $Port is already chosen for the other service. Pick a different one." }
    if ($Listeners -and $Listeners.ContainsKey($Port)) {
        $owner = [string]$Listeners[$Port]
        if (-not ($OwnNames -contains $owner)) {
            return "Port $Port is already in use by '$owner'. Pick another port, or close that program first."
        }
    }
    foreach ($r in @($Excluded)) {
        if ($null -eq $r) { continue }
        if ($Port -ge $r[0] -and $Port -le $r[1]) { return "Port $Port is reserved by Windows (range $($r[0])-$($r[1]), often Hyper-V or WSL). Pick another port." }
    }
    return $null
}

function ConvertFrom-NetstatListeners {
    <# Parses 'netstat -ano' output into a hashtable port -> PID for TCP sockets in the LISTENING state. #>
    param([string[]]$Lines)
    $result = @{}
    foreach ($line in $Lines) {
        # e.g. "  TCP    0.0.0.0:5900     0.0.0.0:0     LISTENING     4242"  or  "  TCP    [::]:5900   [::]:0   LISTENING   4242"
        # The state word is translated on non-English Windows, so a listener is recognised by its 0.0.0.0:0 / [::]:0 remote end.
        if ($line -match '^\s*TCP\s+\S*:(\d+)\s+(0\.0\.0\.0|\[::\]):0\s+\S+\s+(\d+)\s*$') {
            $p = [int]$Matches[1]
            if (-not $result.ContainsKey($p)) { $result[$p] = [int]$Matches[3] }
        }
    }
    return $result
}

function ConvertFrom-ExcludedPortRanges {
    <# Parses 'netsh interface ipv4 show excludedportrange protocol=tcp' output into @(start, end) pairs. #>
    param([string[]]$Lines)
    $ranges = @()
    foreach ($line in $Lines) {
        if ($line -match '^\s*(\d+)\s+(\d+)\b') { $ranges += , @([int]$Matches[1], [int]$Matches[2]) }
    }
    return , $ranges
}

function Get-TightVncMsiProperties {
    <#
        Documented TightVNC MSI properties for a server-only, service-mode install.
        The password is deliberately NOT passed here (it would end up in command lines and MSI/winget logs, and
        quoting it through winget is fragile); Set-TightVncConfig writes it to the registry right after install.
        Until then the server refuses all connections (AcceptRfbConnections=0), so it is never open without one.
    #>
    param([int]$RfbPort)
    return @(
        'ADDLOCAL=Server',
        'SERVER_REGISTER_AS_SERVICE=1',
        'SERVER_ADD_FIREWALL_EXCEPTION=1',
        'SET_RFBPORT=1', "VALUE_OF_RFBPORT=$RfbPort",
        'SET_USEVNCAUTHENTICATION=1', 'VALUE_OF_USEVNCAUTHENTICATION=1',
        'SET_ACCEPTRFBCONNECTIONS=1', 'VALUE_OF_ACCEPTRFBCONNECTIONS=0',
        'SET_ACCEPTHTTPCONNECTIONS=1', 'VALUE_OF_ACCEPTHTTPCONNECTIONS=0',
        'SET_LOOPBACKONLY=1', 'VALUE_OF_LOOPBACKONLY=0',
        'SET_USECONTROLAUTHENTICATION=1', 'VALUE_OF_USECONTROLAUTHENTICATION=1'
    )
}

function Get-TightVncMsiexecArguments {
    <# Full msiexec argument string for installing the MSI at $MsiPath silently, logging to $LogPath. #>
    param([string]$MsiPath, [int]$RfbPort, [string]$LogPath)
    $parts = @('/i', (ConvertTo-QuotedArgument $MsiPath), '/qn', '/norestart')
    if ($LogPath) { $parts += @('/l*v', (ConvertTo-QuotedArgument $LogPath)) }
    $parts += Get-TightVncMsiProperties -RfbPort $RfbPort
    return ($parts -join ' ')
}

function Get-WingetInstallArguments {
    <#
        winget arguments for TightVNC. For MSI/WiX packages winget runs "msiexec /i <msi> <args>", and --override
        REPLACES all of winget's own <args> (its /quiet /norestart and logging), so the override must say /qn
        /norestart itself, then our properties.
    #>
    param([int]$RfbPort)
    $override = (@('/qn', '/norestart') + (Get-TightVncMsiProperties -RfbPort $RfbPort)) -join ' '
    return @('install', '--id', $Script:WingetId, '--exact', '--source', 'winget', '--architecture', 'x64',
             '--silent', '--accept-package-agreements', '--accept-source-agreements', '--override', $override)
}

function ConvertTo-QuotedArgument {
    <# Quotes one argument for a Windows command line (CommandLineToArgvW rules). #>
    param([string]$Value)
    if ($Value -ne '' -and $Value -notmatch '[\s"]') { return $Value }
    $escaped = [regex]::Replace($Value, '(\\*)"', { param($m) ($m.Groups[1].Value * 2) + '\"' })
    $escaped = [regex]::Replace($escaped, '(\\+)$', { param($m) $m.Groups[1].Value * 2 })
    return '"' + $escaped + '"'
}

function ConvertTo-VncPasswordBytes {
    <# Encrypts a password the way VNC servers store it: first 8 bytes, zero-padded, DES-ECB with the fixed key. #>
    param([string]$Plain)
    $bytes = New-Object byte[] 8
    $src = [Text.Encoding]::ASCII.GetBytes($Plain)
    [Array]::Copy($src, $bytes, [Math]::Min(8, $src.Length))
    $des = [Security.Cryptography.DES]::Create()
    try {
        $des.Mode = [Security.Cryptography.CipherMode]::ECB
        $des.Padding = [Security.Cryptography.PaddingMode]::None
        $enc = $des.CreateEncryptor($Script:VncDesKey, (New-Object byte[] 8))
        return , $enc.TransformFinalBlock($bytes, 0, 8)
    } finally { $des.Dispose() }
}

function ConvertFrom-VncPasswordBytes {
    <# Decrypts a stored VNC password (the inverse of ConvertTo-VncPasswordBytes). #>
    param([byte[]]$Encrypted)
    $des = [Security.Cryptography.DES]::Create()
    try {
        $des.Mode = [Security.Cryptography.CipherMode]::ECB
        $des.Padding = [Security.Cryptography.PaddingMode]::None
        $dec = $des.CreateDecryptor($Script:VncDesKey, (New-Object byte[] 8))
        $plain = $dec.TransformFinalBlock($Encrypted, 0, 8)
        return [Text.Encoding]::ASCII.GetString($plain).TrimEnd([char]0)
    } finally { $des.Dispose() }
}

function Test-PasswordText {
    <# Returns an error message for an unusable password, or $null. #>
    param([string]$Plain)
    if ([string]::IsNullOrEmpty($Plain)) { return 'The password cannot be empty.' }
    if ($Plain -notmatch '^[\x20-\x7E]+$') {
        return 'Please use only English letters, digits, spaces and the usual symbols (VNC passwords cannot contain other characters).'
    }
    return $null
}

function Get-ExePathFromImagePath {
    <# Extracts the program path from a service ImagePath such as '"C:\Program Files\TightVNC\tvnserver.exe" -service'. #>
    param([string]$ImagePath)
    if (-not $ImagePath) { return $null }
    $p = [Environment]::ExpandEnvironmentVariables($ImagePath.Trim())
    if ($p.StartsWith('"')) {
        $end = $p.IndexOf('"', 1)
        if ($end -gt 1) { return $p.Substring(1, $end - 1) }
        return $p.Trim('"')
    }
    $i = $p.ToLowerInvariant().IndexOf('.exe')
    if ($i -ge 0) { return $p.Substring(0, $i + 4) }
    return $p
}

function Get-SenderArguments {
    <# Command-line arguments for the background sound sender. The password stays in the file, off the command line. #>
    param([int]$Port, [string]$PasswordFile)
    return "--background --port $Port --password-file $(ConvertTo-QuotedArgument $PasswordFile)"
}

function Get-TaskNameForUser {
    <# Scheduled task name for a user; task names can't contain '\'. #>
    param([string]$User)
    $short = ($User -split '\\')[-1]
    $short = $short -replace '[\\/:*?"<>|]', '_'
    return "Sound sender ($short)"
}

# ----------------------------------------------------------------------------------------------------------
# Console helpers
# ----------------------------------------------------------------------------------------------------------

function Write-Step([string]$Text) { Write-Host ''; Write-Host "== $Text" -ForegroundColor Cyan }
function Write-Ok([string]$Text)   { Write-Host "   $Text" -ForegroundColor Green }
function Write-Info([string]$Text) { Write-Host "   $Text" }
function Write-Warn([string]$Text) { Write-Host "   WARNING: $Text" -ForegroundColor Yellow }

function Read-YesNo {
    param([string]$Question, [bool]$Default)
    $hint = if ($Default) { '[Y/n]' } else { '[y/N]' }
    while ($true) {
        $a = (Read-Host "$Question $hint").Trim().ToLowerInvariant()
        if ($a -eq '') { return $Default }
        if ($a -in @('y', 'yes')) { return $true }
        if ($a -in @('n', 'no')) { return $false }
        Write-Host '   Please answer y or n.'
    }
}

function ConvertFrom-SecureStringToPlain([Security.SecureString]$Secure) {
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

# ----------------------------------------------------------------------------------------------------------
# System queries
# ----------------------------------------------------------------------------------------------------------

function Assert-SupportedWindows {
    if ([Environment]::OSVersion.Platform -ne 'Win32NT' -or -not [Environment]::Is64BitOperatingSystem) { throw 'This setup needs 64-bit Windows 10 or 11.' }
    if (-not [Environment]::Is64BitProcess) { throw 'Please run this setup with 64-bit PowerShell (use "Install Quest VNC.cmd").' }
}

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-ListeningPorts {
    <# Hashtable port -> process name for every TCP port something listens on right now. #>
    $byPid = @{}
    try {
        foreach ($c in @(Get-NetTCPConnection -State Listen -ErrorAction Stop)) {
            if (-not $byPid.ContainsKey([int]$c.LocalPort)) { $byPid[[int]$c.LocalPort] = [int]$c.OwningProcess }
        }
    } catch {
        $byPid = ConvertFrom-NetstatListeners -Lines (& netstat.exe -ano -p TCP)
        $v6 = ConvertFrom-NetstatListeners -Lines (& netstat.exe -ano -p TCPv6)
        foreach ($k in $v6.Keys) { if (-not $byPid.ContainsKey($k)) { $byPid[$k] = $v6[$k] } }
    }
    $names = @{}
    foreach ($port in $byPid.Keys) {
        $procId = $byPid[$port]
        $name = "process $procId"
        if ($procId -eq 4) { $name = 'System (a Windows service)' }
        else {
            $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
            if ($p) { $name = $p.ProcessName }
        }
        $names[$port] = $name
    }
    return $names
}

function Get-ExcludedPortRanges {
    try { return , (ConvertFrom-ExcludedPortRanges -Lines (& netsh.exe interface ipv4 show excludedportrange protocol=tcp 2>$null)) }
    catch { return , @() }
}

function Get-TightVncInstall {
    <# What's installed: service and exe path, plus the MSI uninstall entry if any. #>
    $info = [ordered]@{ ServiceExists = $false; ExePath = $null; ProductCode = $null; DisplayName = $null; InstallDir = $null }
    $svcKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$Script:TightVncService"
    if (Test-Path $svcKey) {
        $info.ServiceExists = $true
        $info.ExePath = Get-ExePathFromImagePath ((Get-ItemProperty $svcKey).ImagePath)
    }
    foreach ($root in @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
        if (-not (Test-Path $root)) { continue }
        foreach ($k in Get-ChildItem $root -ErrorAction SilentlyContinue) {
            $p = Get-ItemProperty $k.PSPath -ErrorAction SilentlyContinue
            if ($p -and ($p.PSObject.Properties.Name -contains 'DisplayName') -and $p.DisplayName -like 'TightVNC*') {
                $info.DisplayName = $p.DisplayName
                if ($k.PSChildName -match '^\{[0-9A-Fa-f-]{36}\}$') { $info.ProductCode = $k.PSChildName }
                if ($p.PSObject.Properties.Name -contains 'InstallLocation' -and $p.InstallLocation) { $info.InstallDir = $p.InstallLocation }
            }
        }
    }
    if (-not $info.ExePath) {
        foreach ($d in @($info.InstallDir, (Join-Path $env:ProgramFiles 'TightVNC'))) {
            if ($d -and (Test-Path (Join-Path $d 'tvnserver.exe'))) { $info.ExePath = Join-Path $d 'tvnserver.exe'; break }
        }
    }
    return New-Object psobject -Property $info
}

function Get-SavedConfig {
    $cfg = @{}
    if (Test-Path $Script:ConfigKey) {
        $p = Get-ItemProperty $Script:ConfigKey
        foreach ($n in @('VncPort', 'AudioPort', 'TargetUser', 'PasswordFile', 'InstalledTightVnc', 'Version')) {
            if ($p.PSObject.Properties.Name -contains $n) { $cfg[$n] = $p.$n }
        }
    }
    return $cfg
}

function Get-LanAddresses {
    $ips = @()
    try {
        $ips = @(Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.IPv4DefaultGateway -and $_.NetAdapter.Status -eq 'Up' } |
                 ForEach-Object { $_.IPv4Address.IPAddress })
    } catch { }
    if ($ips.Count -eq 0) {
        try {
            $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
                     Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
                     ForEach-Object { $_.IPAddress })
        } catch { }
    }
    return @($ips | Select-Object -Unique)
}

function Resolve-TargetUser {
    <# Works out whose sign-in should start the sound sender, and that user's SID and Local AppData folder. #>
    param([string]$User, [string]$LocalAppData)
    $current = [Security.Principal.WindowsIdentity]::GetCurrent()
    if (-not $User) {
        $User = $current.Name
        # Elevated with someone else's admin account (e.g. a standard user typed an admin password): the sound
        # must come from the person sitting at the PC, so prefer the signed-in console user.
        try {
            $console = (Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName
            if ($console -and $console -ne $User) {
                Write-Info "Setting up sound for $console (the signed-in user), not $User."
                $User = $console; $LocalAppData = $null
            }
        } catch { }
    }
    $sid = (New-Object Security.Principal.NTAccount($User)).Translate([Security.Principal.SecurityIdentifier]).Value
    if ($sid -eq 'S-1-5-18') { throw 'The sound sender must run as a real user, not SYSTEM. Run the setup as that user, or pass -TargetUser DOMAIN\name.' }
    if (-not $LocalAppData) {
        if ($sid -eq $current.User.Value) { $LocalAppData = [Environment]::GetFolderPath('LocalApplicationData') }
        else {
            $profileDir = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\$sid" -ErrorAction Stop).ProfileImagePath
            $LocalAppData = Join-Path ([Environment]::ExpandEnvironmentVariables($profileDir)) 'AppData\Local'
        }
    }
    return New-Object psobject -Property @{ Name = $User; Sid = $sid; LocalAppData = $LocalAppData }
}

# ----------------------------------------------------------------------------------------------------------
# Questions
# ----------------------------------------------------------------------------------------------------------

function Read-Port {
    param([string]$Label, [int]$Default, [int]$OtherPort, [hashtable]$Listeners, [object[]]$Excluded)
    $own = @('tvnserver', 'QuestVncAudio')
    while ($true) {
        $text = Read-Host "$Label [$Default]"
        if ("$text".Trim() -eq '') { $text = "$Default" }
        $err = Test-PortText $text
        if (-not $err) { $err = Get-PortConflict -Port ([int]$text) -OtherPort $OtherPort -Listeners $Listeners -OwnNames $own -Excluded $Excluded }
        if (-not $err) { return [int]$text }
        Write-Warn $err
    }
}

function Read-NewPassword {
    param([string]$Existing)
    Write-Host ''
    Write-Host '   Choose a password for this PC. The headset asks for it when it connects (picture and sound).'
    Write-Host '   VNC only uses the first 8 characters, so 8 is a good length.'
    if ($Existing) { Write-Host '   Press Enter to keep the current password.' }
    while ($true) {
        $first = ConvertFrom-SecureStringToPlain (Read-Host '   Password' -AsSecureString)
        if ($first -eq '' -and $Existing) { return $Existing }
        $err = Test-PasswordText $first
        if ($err) { Write-Warn $err; continue }
        $second = ConvertFrom-SecureStringToPlain (Read-Host '   Type it again' -AsSecureString)
        if ($first -cne $second) { Write-Warn 'The two passwords are different. Please try again.'; continue }
        if ($first.Length -gt 8) {
            Write-Warn "That's $($first.Length) characters; VNC only checks the first 8 ($($first.Substring(0, 8)))."
            Write-Info 'Type the whole password in Quest VNC and both picture and sound will work.'
            if (-not (Read-YesNo '   Keep this password?' $true)) { continue }
        }
        return $first
    }
}

# ----------------------------------------------------------------------------------------------------------
# TightVNC
# ----------------------------------------------------------------------------------------------------------

function Install-TightVncWithWinget {
    param([int]$RfbPort)
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) { Write-Info 'winget is not available on this PC; downloading TightVNC directly instead.'; return $false }
    Write-Info 'Installing TightVNC with winget (this can take a minute)...'
    $wingetArgs = Get-WingetInstallArguments -RfbPort $RfbPort
    # Show winget's messages but not its progress bars and spinners.
    & $winget.Source @wingetArgs | ForEach-Object {
        $line = "$_".Trim()
        if ($line -match '[A-Za-z]{3}' -and $line -notmatch '[\u2580-\u259F]') { Write-Info "winget: $line" }
    }
    $code = $LASTEXITCODE
    if ($code -eq 0 -and (Get-TightVncInstall).ServiceExists) { return $true }
    Write-Warn ("winget could not install TightVNC (exit code 0x{0:X8}); trying the direct download." -f $code)
    return $false
}

function Install-TightVncFromDownload {
    param([int]$RfbPort)
    $dir = Join-Path $env:TEMP ('QuestVNC-' + [Guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $dir | Out-Null
    $msi = Join-Path $dir ([IO.Path]::GetFileName($Script:TightVncMsiUrl))
    try {
        Write-Info "Downloading $Script:TightVncMsiUrl"
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $Script:TightVncMsiUrl -OutFile $msi -UseBasicParsing

        $sig = Get-AuthenticodeSignature -FilePath $msi
        $subject = if ($sig.SignerCertificate) { $sig.SignerCertificate.Subject } else { '(none)' }
        if ($sig.Status -ne 'Valid' -or $subject -notmatch 'GlavSoft') {
            throw "The downloaded TightVNC installer is not properly signed by GlavSoft (status: $($sig.Status), signer: $subject). Not installing it."
        }
        Write-Ok "Signature OK: $subject"
        $hash = (Get-FileHash -Path $msi -Algorithm SHA256).Hash
        if ($hash -ne $Script:TightVncMsiSha256) {
            # The signature above is what proves the file is genuine; a different hash just means GlavSoft rebuilt it.
            Write-Warn "The file's SHA-256 ($hash) differs from the one this setup expected, but it is validly signed by GlavSoft, so continuing."
        }

        $log = Join-Path $env:TEMP 'QuestVNC-TightVNC-msi.log'
        $msiArgs = Get-TightVncMsiexecArguments -MsiPath $msi -RfbPort $RfbPort -LogPath $log
        Write-Info 'Installing TightVNC Server...'
        $p = Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\msiexec.exe') -ArgumentList $msiArgs -Wait -PassThru
        if ($p.ExitCode -eq 3010 -or $p.ExitCode -eq 1641) { Write-Warn 'TightVNC asks for a restart; it should work now, but restart the PC if it does not.' }
        elseif ($p.ExitCode -ne 0) { throw "The TightVNC installer failed (code $($p.ExitCode)). Details: $log" }
    } finally {
        Remove-Item -LiteralPath $dir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

function Install-TightVnc {
    param([int]$RfbPort)
    $tv = Get-TightVncInstall
    if ($tv.ServiceExists -and $tv.ExePath -and (Test-Path $tv.ExePath)) {
        Write-Ok "TightVNC Server is already installed ($($tv.ExePath)); updating its settings."
        return $false
    }
    if ($tv.ExePath -and (Test-Path $tv.ExePath)) {
        # Installed, but not as a service (e.g. "application mode" only): register the service.
        Write-Info 'TightVNC is installed but not as a service; registering the service.'
        $p = Start-Process -FilePath $tv.ExePath -ArgumentList '-install -silent' -Wait -PassThru
        if ((Get-TightVncInstall).ServiceExists) { return $false }
        Write-Warn "Registering the service failed (code $($p.ExitCode)); reinstalling TightVNC Server."
    }
    if (-not (Install-TightVncWithWinget -RfbPort $RfbPort)) { Install-TightVncFromDownload -RfbPort $RfbPort }
    if (-not (Get-TightVncInstall).ServiceExists) { throw 'TightVNC Server did not install as a service. Install TightVNC yourself from tightvnc.com (choose "Custom" > Server), then run this setup again.' }
    Write-Ok 'TightVNC Server installed.'
    return $true
}

function Set-TightVncConfig {
    <# Writes the service-mode settings and restarts the TightVNC service. #>
    param([int]$RfbPort, [string]$PlainPassword)
    if (-not (Test-Path $Script:TightVncKey)) { New-Item -Path $Script:TightVncKey -Force | Out-Null }
    $enc = ConvertTo-VncPasswordBytes $PlainPassword
    $dwords = [ordered]@{
        RfbPort = $RfbPort; AcceptRfbConnections = 1; UseVncAuthentication = 1
        AcceptHttpConnections = 0; LoopbackOnly = 0; UseControlAuthentication = 1
    }
    Stop-Service -Name $Script:TightVncService -Force -ErrorAction SilentlyContinue
    foreach ($k in $dwords.Keys) { Set-ItemProperty -Path $Script:TightVncKey -Name $k -Value $dwords[$k] -Type DWord }
    Set-ItemProperty -Path $Script:TightVncKey -Name Password -Value $enc -Type Binary
    # The control password protects TightVNC's own settings window (tray icon); same password, for simplicity.
    Set-ItemProperty -Path $Script:TightVncKey -Name ControlPassword -Value $enc -Type Binary
    Set-Service -Name $Script:TightVncService -StartupType Automatic
    Start-Service -Name $Script:TightVncService
    Write-Ok "TightVNC Server is running on port $RfbPort with your password."
}

function Uninstall-TightVnc {
    $tv = Get-TightVncInstall
    if ($tv.ProductCode) {
        Write-Info "Uninstalling $($tv.DisplayName)..."
        $p = Start-Process -FilePath (Join-Path $env:SystemRoot 'System32\msiexec.exe') -ArgumentList "/x $($tv.ProductCode) /qn /norestart" -Wait -PassThru
        if ($p.ExitCode -in @(0, 1605, 3010, 1641)) {
            # TightVNC leaves its settings (including the stored password) behind; they're ours, so remove them.
            Remove-Item -Path 'HKLM:\SOFTWARE\TightVNC' -Recurse -Force -ErrorAction SilentlyContinue
            Write-Ok 'TightVNC removed.'; return
        }
        Write-Warn "msiexec could not remove TightVNC (code $($p.ExitCode))."
    }
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        & $winget.Source uninstall --id $Script:WingetId --exact --silent --accept-source-agreements | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Remove-Item -Path 'HKLM:\SOFTWARE\TightVNC' -Recurse -Force -ErrorAction SilentlyContinue
            Write-Ok 'TightVNC removed.'; return
        }
    }
    Write-Warn 'Could not remove TightVNC automatically. Remove it in Settings > Apps > Installed apps.'
}

# ----------------------------------------------------------------------------------------------------------
# Sound sender
# ----------------------------------------------------------------------------------------------------------

function Stop-SoundSender {
    foreach ($t in @(Get-ScheduledTask -TaskPath $Script:TaskPath -ErrorAction SilentlyContinue)) {
        Stop-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -ErrorAction SilentlyContinue
    }
    # Any running copy (also one started by hand) would hold the sound port or lock the exe being replaced.
    $procs = @(Get-Process -Name 'QuestVncAudio' -ErrorAction SilentlyContinue)
    foreach ($p in $procs) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
    foreach ($p in $procs) { try { $p.WaitForExit(5000) | Out-Null } catch { } }
}

function Remove-OldStartupShortcuts {
    <# The sender used to be started from the Startup folder by hand; that copy would hold the sound port. #>
    param([string]$LocalAppData, [bool]$Interactive)
    $startup = Join-Path (Split-Path $LocalAppData -Parent) 'Roaming\Microsoft\Windows\Start Menu\Programs\Startup'
    if (-not (Test-Path -LiteralPath $startup)) { return }
    $shell = New-Object -ComObject WScript.Shell
    foreach ($lnk in @(Get-ChildItem -LiteralPath $startup -Filter *.lnk -ErrorAction SilentlyContinue)) {
        $target = $shell.CreateShortcut($lnk.FullName).TargetPath
        if ($target -and ([IO.Path]::GetFileName($target) -ieq $Script:SenderExeName)) {
            Write-Warn "Found an older way of starting the sound sender: $($lnk.FullName)"
            if (-not $Interactive -or (Read-YesNo '   Remove it? (the setup now starts the sound sender for you)' $true)) {
                Remove-Item -LiteralPath $lnk.FullName -Force
                Write-Ok 'Removed.'
            }
        }
    }
}

function Find-SenderExe {
    $candidates = @(
        (Join-Path $PSScriptRoot $Script:SenderExeName),
        (Join-Path $PSScriptRoot "..\..\audio-sender\publish\$Script:SenderExeName")
    )
    foreach ($c in $candidates) { if (Test-Path -LiteralPath $c) { return (Resolve-Path -LiteralPath $c).Path } }
    throw "Can't find $Script:SenderExeName next to this script. If you opened the zip without extracting it, extract it first (right-click > Extract All), then run 'Install Quest VNC.cmd' from the extracted folder."
}

function Copy-SetupFiles {
    param([string]$SenderSource)
    New-Item -ItemType Directory -Path $Script:InstallDir -Force | Out-Null
    $dest = Join-Path $Script:InstallDir $Script:SenderExeName
    if ($SenderSource -ne $dest) {
        $tries = 0
        while ($true) {
            try { Copy-Item -LiteralPath $SenderSource -Destination $dest -Force; break }
            catch { if (++$tries -ge 10) { throw }; Start-Sleep -Milliseconds 500 }  # old copy may still be closing
        }
    }
    # Keep the setup files so it can be uninstalled or reconfigured later from Program Files or Settings > Apps.
    foreach ($f in @('install.ps1', 'Install Quest VNC.cmd', 'Uninstall Quest VNC.cmd', 'README.md')) {
        $src = Join-Path $PSScriptRoot $f
        $dst = Join-Path $Script:InstallDir $f
        if ((Test-Path -LiteralPath $src) -and ($src -ne $dst)) { Copy-Item -LiteralPath $src -Destination $dst -Force }
    }
    return $dest
}

function Write-PasswordFile {
    <# Saves the sound password where only the user (plus SYSTEM and administrators) can read it. #>
    param([string]$Path, [string]$Plain, [string]$UserSid)
    $dir = Split-Path $Path -Parent
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    if (-not (Test-Path -LiteralPath $Path)) { [IO.File]::WriteAllText($Path, '') }
    $acl = New-Object Security.AccessControl.FileSecurity
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($sid in @($UserSid, 'S-1-5-18', 'S-1-5-32-544')) {
        $id = New-Object Security.Principal.SecurityIdentifier($sid)
        $acl.AddAccessRule((New-Object Security.AccessControl.FileSystemAccessRule($id, 'FullControl', 'Allow')))
    }
    Set-Acl -LiteralPath $Path -AclObject $acl
    [IO.File]::WriteAllText($Path, $Plain, (New-Object Text.UTF8Encoding($false)))
}

function Register-SoundSender {
    param([string]$ExePath, [int]$Port, [string]$PasswordFile, [string]$User)
    foreach ($t in @(Get-ScheduledTask -TaskPath $Script:TaskPath -ErrorAction SilentlyContinue)) {
        Unregister-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -Confirm:$false
    }
    $name = Get-TaskNameForUser $User
    $action = New-ScheduledTaskAction -Execute $ExePath -Argument (Get-SenderArguments -Port $Port -PasswordFile $PasswordFile) -WorkingDirectory $Script:InstallDir
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $User
    # Interactive: runs inside the user's own session (needed to capture their speakers), only while they're signed in.
    $principal = New-ScheduledTaskPrincipal -UserId $User -LogonType Interactive -RunLevel Limited
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden `
        -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -Priority 4 `
        -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
    $task = New-ScheduledTask -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
        -Description 'Sends this PC''s sound to the Quest VNC headset app. Installed by the Quest VNC setup.'
    Register-ScheduledTask -TaskPath $Script:TaskPath -TaskName $name -InputObject $task -Force | Out-Null
    Start-ScheduledTask -TaskPath $Script:TaskPath -TaskName $name
    Write-Ok "Sound sender installed; it starts by itself whenever $User signs in."
}

function Set-FirewallRules {
    param([int]$VncPortNum, [int]$AudioPortNum, [string]$SenderExe, [string]$TightVncExe)
    Get-NetFirewallRule -Group $Script:FirewallGroup -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    New-NetFirewallRule -DisplayName "Quest VNC sound (TCP $AudioPortNum)" -Group $Script:FirewallGroup -Direction Inbound `
        -Action Allow -Protocol TCP -LocalPort $AudioPortNum -Program $SenderExe -Profile Private | Out-Null
    $vncArgs = @{ DisplayName = "Quest VNC picture - TightVNC (TCP $VncPortNum)"; Group = $Script:FirewallGroup; Direction = 'Inbound'
                  Action = 'Allow'; Protocol = 'TCP'; LocalPort = $VncPortNum; Profile = 'Private' }
    if ($TightVncExe) { $vncArgs.Program = $TightVncExe }
    New-NetFirewallRule @vncArgs | Out-Null
    Write-Ok "Windows Firewall allows ports $VncPortNum and $AudioPortNum on Private (home) networks."
}

function Test-PublicNetwork {
    param([bool]$Interactive)
    $public = @()
    try { $public = @(Get-NetConnectionProfile -ErrorAction Stop | Where-Object { $_.NetworkCategory -eq 'Public' }) } catch { return }
    foreach ($n in $public) {
        Write-Warn "Your network '$($n.Name)' is set to Public, so Windows blocks the headset from connecting."
        if ($Interactive -and (Read-YesNo '   Is this your home network, and should it be switched to Private?' $true)) {
            try { Set-NetConnectionProfile -InterfaceIndex $n.InterfaceIndex -NetworkCategory Private; Write-Ok "'$($n.Name)' is now Private." }
            catch { Write-Warn "Couldn't change it: $($_.Exception.Message). Change it in Settings > Network & internet > (your network) > Private." }
        } else {
            Write-Info 'Change it in Settings > Network & internet > (your network) > Private network.'
        }
    }
}

function Wait-ForListener {
    param([int]$Port, [int]$Seconds)
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        if ((Get-ListeningPorts).ContainsKey($Port)) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

function Register-UninstallEntry {
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $script = Join-Path $Script:InstallDir 'install.ps1'
    New-Item -Path $Script:UninstallKey -Force | Out-Null
    $values = @{
        DisplayName = 'Quest VNC (TightVNC setup + sound sender)'; DisplayVersion = $Script:SetupVersion; Publisher = 'Quest VNC'
        InstallLocation = $Script:InstallDir; DisplayIcon = (Join-Path $Script:InstallDir $Script:SenderExeName)
        UninstallString = "`"$ps`" -NoProfile -ExecutionPolicy Bypass -File `"$script`" -Uninstall -PauseAtEnd"
        ModifyPath = "`"$ps`" -NoProfile -ExecutionPolicy Bypass -File `"$script`" -PauseAtEnd"
    }
    foreach ($k in $values.Keys) { Set-ItemProperty -Path $Script:UninstallKey -Name $k -Value $values[$k] }
    Set-ItemProperty -Path $Script:UninstallKey -Name NoRepair -Value 1 -Type DWord
}

# ----------------------------------------------------------------------------------------------------------
# Install / uninstall
# ----------------------------------------------------------------------------------------------------------

function Invoke-Install {
    $saved = Get-SavedConfig
    $interactive = -not ($Unattended.IsPresent -or $Script:PasswordGiven -or $PasswordBase64)
    if ($PasswordBase64) { $Script:Password = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($PasswordBase64)) }

    Write-Host ''
    Write-Host 'Quest VNC setup for Windows' -ForegroundColor White
    Write-Host 'Installs TightVNC Server (the picture) and the Quest VNC sound sender, and connects them to your headset.'
    if ($saved.Count -gt 0) { Write-Host 'Quest VNC is already set up on this PC: this run updates it and lets you change the ports or password.' }

    Assert-SupportedWindows

    $user = Resolve-TargetUser -User $TargetUser -LocalAppData $TargetLocalAppData
    $senderSource = Find-SenderExe

    # Current values become the defaults, so re-running only changes what you change.
    $tvExisting = $null
    if (Test-Path $Script:TightVncKey) {
        $tvProps = Get-ItemProperty $Script:TightVncKey
        if ($tvProps.PSObject.Properties.Name -contains 'RfbPort') { $tvExisting = [int]$tvProps.RfbPort }
    }
    $defVnc = if ($saved.ContainsKey('VncPort')) { [int]$saved.VncPort } elseif ($tvExisting) { $tvExisting } else { $Script:DefaultVncPort }
    $defAudio = if ($saved.ContainsKey('AudioPort')) { [int]$saved.AudioPort } else { $Script:DefaultAudioPort }
    $passwordFile = Join-Path $user.LocalAppData 'Quest VNC\audio-password.txt'
    $existingPassword = $null
    if (Test-Path -LiteralPath $passwordFile) {
        $existingPassword = [IO.File]::ReadAllText($passwordFile, [Text.Encoding]::UTF8).TrimEnd("`r", "`n")
        if (Test-PasswordText $existingPassword) { $existingPassword = $null }
    }

    $listeners = Get-ListeningPorts
    $excluded = Get-ExcludedPortRanges
    $own = @('tvnserver', 'QuestVncAudio')

    Write-Step 'Settings'
    if ($VncPort -ne 0) {
        $err = Test-PortText "$VncPort"
        if (-not $err) { $err = Get-PortConflict -Port $VncPort -OtherPort 0 -Listeners $listeners -OwnNames $own -Excluded $excluded }
        if ($err) { throw "VNC port: $err" }
        $vnc = $VncPort
    } elseif ($interactive) {
        Write-Host '   Port for the picture (VNC). Press Enter for the usual one.'
        $vnc = Read-Port -Label '   VNC port' -Default $defVnc -OtherPort 0 -Listeners $listeners -Excluded $excluded
    } else {
        $vnc = $defVnc
        $err = Get-PortConflict -Port $vnc -OtherPort 0 -Listeners $listeners -OwnNames $own -Excluded $excluded
        if ($err) { throw "VNC port: $err" }
    }

    if ($AudioPort -ne 0) {
        $err = Test-PortText "$AudioPort"
        if (-not $err) { $err = Get-PortConflict -Port $AudioPort -OtherPort $vnc -Listeners $listeners -OwnNames $own -Excluded $excluded }
        if ($err) { throw "Sound port: $err" }
        $audio = $AudioPort
    } elseif ($interactive) {
        Write-Host '   Port for the sound. Press Enter for the usual one.'
        $audioDefault = if ($defAudio -eq $vnc) { $Script:DefaultAudioPort } else { $defAudio }
        $audio = Read-Port -Label '   Sound port' -Default $audioDefault -OtherPort $vnc -Listeners $listeners -Excluded $excluded
    } else {
        $audio = $defAudio
        $err = Get-PortConflict -Port $audio -OtherPort $vnc -Listeners $listeners -OwnNames $own -Excluded $excluded
        if ($err) { throw "Sound port: $err" }
    }

    if ($Script:Password) {
        $err = Test-PasswordText $Script:Password
        if ($err) { throw "Password: $err" }
        if ($Script:Password.Length -gt 8) { Write-Warn 'VNC only checks the first 8 characters of the password.' }
        $plain = $Script:Password
    } elseif ($interactive) {
        $plain = Read-NewPassword -Existing $existingPassword
    } elseif ($existingPassword) {
        $plain = $existingPassword
    } else { throw 'No password given. Pass -Password, or run the setup without -Unattended to be asked.' }

    Test-PublicNetwork -Interactive $interactive

    Write-Step 'TightVNC Server (the picture)'
    $installedNow = Install-TightVnc -RfbPort $vnc
    Set-TightVncConfig -RfbPort $vnc -PlainPassword $plain
    $tvExe = (Get-TightVncInstall).ExePath

    Write-Step 'Quest VNC sound sender'
    Remove-OldStartupShortcuts -LocalAppData $user.LocalAppData -Interactive $interactive
    Stop-SoundSender
    $senderExe = Copy-SetupFiles -SenderSource $senderSource
    Write-PasswordFile -Path $passwordFile -Plain $plain -UserSid $user.Sid
    Set-FirewallRules -VncPortNum $vnc -AudioPortNum $audio -SenderExe $senderExe -TightVncExe $tvExe
    Register-SoundSender -ExePath $senderExe -Port $audio -PasswordFile $passwordFile -User $user.Name

    New-Item -Path $Script:ConfigKey -Force | Out-Null
    $installedTv = if ($saved.ContainsKey('InstalledTightVnc')) { [int]$saved.InstalledTightVnc } else { 0 }
    if ($installedNow) { $installedTv = 1 }
    $cfg = @{ VncPort = $vnc; AudioPort = $audio; InstalledTightVnc = $installedTv }
    foreach ($k in $cfg.Keys) { Set-ItemProperty -Path $Script:ConfigKey -Name $k -Value $cfg[$k] -Type DWord }
    Set-ItemProperty -Path $Script:ConfigKey -Name TargetUser -Value $user.Name
    Set-ItemProperty -Path $Script:ConfigKey -Name PasswordFile -Value $passwordFile
    Set-ItemProperty -Path $Script:ConfigKey -Name Version -Value $Script:SetupVersion
    Register-UninstallEntry

    Write-Step 'Checking'
    $vncUp = Wait-ForListener -Port $vnc -Seconds 15
    $audioUp = Wait-ForListener -Port $audio -Seconds 15
    if ($vncUp) { Write-Ok "Picture (TightVNC) is listening on port $vnc." } else { Write-Warn "TightVNC is not listening on port $vnc yet. Check the 'TightVNC Server' service in services.msc." }
    if ($audioUp) { Write-Ok "Sound sender is listening on port $audio." }
    else {
        $log = Join-Path $user.LocalAppData 'Quest VNC\audio.log'
        Write-Warn "The sound sender is not listening on port $audio yet. It starts at sign-in; its log is $log"
    }

    Write-Summary -Vnc $vnc -Audio $audio
}

function Write-Summary {
    param([int]$Vnc, [int]$Audio)
    $ips = @(Get-LanAddresses)
    Write-Host ''
    Write-Host '================================================================' -ForegroundColor Green
    Write-Host ' Quest VNC is ready on this PC' -ForegroundColor Green
    Write-Host '================================================================' -ForegroundColor Green
    if ($ips.Count -gt 0) { Write-Host "  This PC's address: $($ips -join ', ')" } else { Write-Host "  This PC's address: (not found; see Settings > Network & internet)" }
    Write-Host "  VNC port (picture): $Vnc"
    Write-Host "  Sound port:         $Audio"
    Write-Host '  Password:           the one you just chose'
    Write-Host ''
    Write-Host '  On the headset:'
    if ($Script:ScanPorts -contains $Vnc) {
        Write-Host '   1. In Quest VNC, press Scan and pick this PC (or add it by its address).'
    } else {
        $example = if ($ips.Count -gt 0) { "$($ips[0]):$Vnc" } else { "<address>:$Vnc" }
        Write-Host "   1. In Quest VNC, add this PC by its address with port $Vnc (e.g. $example). Scan only looks at ports 5900-5903."
    }
    $step = 2
    if ($Audio -ne $Script:DefaultAudioPort) {
        Write-Host "   $step. Open the PC's Edit screen and set Audio port to $Audio."
        $step++
    }
    Write-Host "   $step. Connect and type the password. Sound plays in the headset."
    Write-Host ''
    Write-Host '  To change ports or the password later, run "Install Quest VNC.cmd" again.'
    Write-Host '  To remove: Settings > Apps > Installed apps > Quest VNC, or "Uninstall Quest VNC.cmd".'
}

function Invoke-Uninstall {
    $saved = Get-SavedConfig
    $interactive = -not $Unattended -and -not $RemoveTightVnc -and -not $KeepTightVnc
    Write-Host ''
    Write-Host 'Removing Quest VNC from this PC' -ForegroundColor White

    Write-Step 'Sound sender'
    Stop-SoundSender
    foreach ($t in @(Get-ScheduledTask -TaskPath $Script:TaskPath -ErrorAction SilentlyContinue)) {
        Unregister-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -Confirm:$false
    }
    try {
        $scheduler = New-Object -ComObject Schedule.Service
        $scheduler.Connect()
        $scheduler.GetFolder('\').DeleteFolder('Quest VNC', 0)
    } catch { }
    Get-NetFirewallRule -Group $Script:FirewallGroup -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    if ($saved.ContainsKey('PasswordFile') -and $saved.PasswordFile) {
        $userDir = Split-Path $saved.PasswordFile -Parent
        if ((Split-Path $userDir -Leaf) -eq 'Quest VNC') { Remove-Item -LiteralPath $userDir -Recurse -Force -ErrorAction SilentlyContinue }
    }
    $here = (Get-Location).Path
    if ($here -like "$Script:InstallDir*") { Set-Location $env:SystemRoot }
    Remove-Item -LiteralPath $Script:InstallDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path -LiteralPath $Script:InstallDir) { Write-Warn "Some files in $Script:InstallDir could not be removed; delete the folder after restarting." }
    Remove-Item -Path $Script:UninstallKey -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $Script:ConfigKey -Recurse -Force -ErrorAction SilentlyContinue
    Write-Ok 'Sound sender, its sign-in task, firewall rules and files removed.'

    Write-Step 'TightVNC Server'
    $tv = Get-TightVncInstall
    if (-not $tv.ServiceExists -and -not $tv.ProductCode) { Write-Info 'TightVNC is not installed.' }
    else {
        $weInstalled = $saved.ContainsKey('InstalledTightVnc') -and [int]$saved.InstalledTightVnc -eq 1
        $remove = $false
        if ($RemoveTightVnc) { $remove = $true }
        elseif ($KeepTightVnc) { $remove = $false }
        elseif ($interactive) {
            if (-not $weInstalled) { Write-Info 'TightVNC was already on this PC before Quest VNC was set up.' }
            $remove = Read-YesNo '   Also uninstall TightVNC Server?' $weInstalled
        }
        if ($remove) { Uninstall-TightVnc } else { Write-Info 'TightVNC Server is kept (remove it any time in Settings > Apps).' }
    }
    Write-Host ''
    Write-Host 'Done.' -ForegroundColor Green
}

function Invoke-Elevated {
    <# Re-runs this script as administrator in a new window, passing on the options and who the real user is. #>
    # From a 32-bit PowerShell, Sysnative reaches the 64-bit one (System32 would be redirected).
    $ps = Join-Path $env:SystemRoot 'Sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if (-not (Test-Path $ps)) { $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe' }
    $a = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (ConvertTo-QuotedArgument $PSCommandPath), '-PauseAtEnd')
    if (-not $TargetUser) {
        $who = [Security.Principal.WindowsIdentity]::GetCurrent().Name
        $a += @('-TargetUser', (ConvertTo-QuotedArgument $who), '-TargetLocalAppData', (ConvertTo-QuotedArgument ([Environment]::GetFolderPath('LocalApplicationData')))) }
    else {
        $a += @('-TargetUser', (ConvertTo-QuotedArgument $TargetUser))
        if ($TargetLocalAppData) { $a += @('-TargetLocalAppData', (ConvertTo-QuotedArgument $TargetLocalAppData)) }
    }
    if ($VncPort) { $a += @('-VncPort', "$VncPort") }
    if ($AudioPort) { $a += @('-AudioPort', "$AudioPort") }
    if ($Script:PasswordGiven) { $a += @('-PasswordBase64', [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($Script:Password))) }
    foreach ($s in @('Unattended', 'Uninstall', 'RemoveTightVnc', 'KeepTightVnc')) { if ((Get-Variable -Name $s -Scope Script -ValueOnly).IsPresent) { $a += "-$s" } }
    Write-Host 'Quest VNC setup needs administrator rights. Please choose Yes in the Windows prompt.'
    try {
        $p = Start-Process -FilePath $ps -ArgumentList ($a -join ' ') -Verb RunAs -Wait -PassThru
        return $p.ExitCode
    } catch {
        Write-Host 'Setup was not allowed to run as administrator, so nothing was changed.' -ForegroundColor Yellow
        return 1
    }
}

# ----------------------------------------------------------------------------------------------------------
# Entry point (skipped when the file is dot-sourced by the tests)
# ----------------------------------------------------------------------------------------------------------
if ($MyInvocation.InvocationName -ne '.') {
    $Script:PasswordGiven = $PSBoundParameters.ContainsKey('Password')
    if (-not (Test-IsAdmin)) {
        $code = Invoke-Elevated
        if ($null -eq $code) { $code = 0 }
        if ($PauseAtEnd -and $code -ne 0) { Read-Host 'Press Enter to close' | Out-Null }
        exit $code
    }
    $transcript = Join-Path $env:TEMP 'QuestVNC-setup.log'
    # No transcript when the password came on the command line: the transcript header records the command line.
    if (-not ($Script:PasswordGiven -or $PasswordBase64)) { try { Start-Transcript -Path $transcript -Force | Out-Null } catch { } }
    $exitCode = 0
    try {
        if ($Uninstall) { Invoke-Uninstall } else { Invoke-Install }
    } catch {
        $exitCode = 1
        Write-Host ''
        Write-Host "Setup stopped: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "Details are in $transcript" -ForegroundColor Red
        Write-Host ($_.ScriptStackTrace) -ForegroundColor DarkGray
    } finally {
        try { Stop-Transcript | Out-Null } catch { }
    }
    if ($PauseAtEnd) { Write-Host ''; Read-Host 'Press Enter to close' | Out-Null }
    exit $exitCode
}
