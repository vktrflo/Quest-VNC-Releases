# Quest VNC setup for Windows

This sets up a Windows PC so you can see and hear it from the Quest VNC app on your headset.
One double-click installs and configures everything:

* **TightVNC Server** (free, from GlavSoft) sends the PC's picture and takes your mouse and keyboard.
  It is installed as a Windows service, so it runs even before you sign in.
* **Quest VNC sound sender** (`QuestVncAudio.exe`) sends whatever the PC is playing to the headset.
  It runs hidden in the background whenever you sign in to Windows.

Both use one password that you choose during setup.

Needs 64-bit Windows 10 or 11 and an internet connection (to download TightVNC).

## Install

1. Extract the zip: right-click it and choose **Extract All**. (Running the setup from inside the zip doesn't work.)
2. Open the extracted folder and double-click **Install Quest VNC.cmd**.
   * If Windows says **"Windows protected your PC"**, click **More info**, then **Run anyway**.
     This appears because the setup isn't from the Microsoft Store.
   * Windows then asks **"Do you want to allow this app to make changes to your device?"**. Choose **Yes**.
     The setup needs this to install a service and open the firewall. A new window opens and the setup continues there.
3. Answer three questions. Press **Enter** to accept the suggested value:
   * **VNC port** (usually **5900**): the network port for the picture.
   * **Sound port** (usually **5910**): the network port for the sound. It must be different from the VNC port.
   * **Password**, typed twice (it isn't shown while you type).
     VNC only checks the first **8 characters**, so a password of up to 8 characters is best.
     Use English letters, numbers, spaces and normal symbols.

   If a port is already used by another program, the setup tells you and asks again.
4. If your Wi-Fi or network is set to **Public**, the setup offers to switch it to **Private**. Say yes if it's your home network:
   Windows blocks the headset on Public networks.
5. At the end the setup shows a summary like this:

   ```
   This PC's address: 192.168.1.23
   VNC port (picture): 5900
   Sound port:         5910
   ```

   and what to do on the headset. Press Enter to close the window.

## On the headset

1. In Quest VNC, press **Scan** and choose this PC, or add it by the address shown in the summary.
   Scan only finds PCs on ports 5900 to 5903; for another VNC port, add the PC by hand (address and port).
2. If you picked a sound port other than 5910, open the PC's **Edit** screen and set **Audio port** to that number.
3. Connect and type your password. You'll hear the PC in the headset.
   The **Audio password** in the Edit screen can stay empty: the app uses the VNC password for sound too.

If your password is longer than 8 characters, type all of it in Quest VNC. The picture only checks the first 8, but the sound checks the whole password.

## Changing the ports or the password later

Run **Install Quest VNC.cmd** again (from the zip folder, or from `C:\Program Files\Quest VNC`).
It shows your current settings as the suggested answers, so press Enter for anything you don't want to change.
For the password, pressing Enter keeps the current one.
After changing a port, update it in the PC's Edit screen in Quest VNC.

Re-running the setup is also how you update to a newer version.

## Uninstall

Either:

* **Settings > Apps > Installed apps** (Windows 11) or **Apps & features** (Windows 10), find **Quest VNC** and choose **Uninstall**, or
* double-click **Uninstall Quest VNC.cmd** (in the zip folder, or in `C:\Program Files\Quest VNC`).

This removes the sound sender, its sign-in start-up, its firewall rules and its files. It then asks whether to remove
TightVNC Server too. The suggested answer is Yes if this setup installed TightVNC, and No if TightVNC was already on the PC.

## What exactly is installed

| What | Where |
| --- | --- |
| TightVNC Server (service "TightVNC Server", starts with Windows) | `C:\Program Files\TightVNC` |
| Sound sender and a copy of this setup | `C:\Program Files\Quest VNC` |
| Sign-in task that starts the sound sender, hidden, for the user who ran the setup | Task Scheduler, folder **Quest VNC** |
| Your password for the sound sender, readable only by you (and administrators) | `%LOCALAPPDATA%\Quest VNC\audio-password.txt` |
| Sound sender log | `%LOCALAPPDATA%\Quest VNC\audio.log` |
| Firewall rules "Quest VNC sound" and "Quest VNC picture - TightVNC", Private networks only | Windows Defender Firewall |

TightVNC is set up with: VNC password required, the setup's port, its built-in web viewer turned off, and its own settings
window (the TightVNC tray icon) protected by the same password. Its installer also adds its usual firewall exception.

TightVNC comes from `winget` (Windows' built-in package manager) when it's available, otherwise it is downloaded
directly from tightvnc.com. The download is only installed if it carries GlavSoft's valid digital signature.

The sound sender only runs while you're signed in, because it captures the sound of your own session.
It sends the sound of the user who ran the setup. On a PC shared by several people, run the setup from the account whose
sound you want.

## Troubleshooting

**The headset can't find or connect to the PC**
* Make sure the headset and the PC are on the same network (same Wi-Fi router).
* Check the network is **Private**: Settings > Network & internet > (your Wi-Fi or Ethernet) > **Private network**.
  The firewall rules only allow connections on Private networks.
* Check the address: run the setup again and look at the summary, or type `ipconfig` in a Command Prompt.
* Other security software (a third-party antivirus firewall) may need its own exception for ports 5900 and 5910.

**Picture works but no sound**
* The sound port in the app's Edit screen must match the one you chose (default 5910).
* Sign out of Windows and back in, or restart the PC; the sound sender starts at sign-in.
* Look at the log: press Win+R, type `%LOCALAPPDATA%\Quest VNC\audio.log`, press Enter.
  "wrong password" lines mean the password typed in the headset doesn't match; type the whole password, or set
  **Audio password** in the Edit screen.
* Check it's running: Task Manager > Details should list `QuestVncAudio.exe`.
* Test with a beep: open a Command Prompt and run
  `"C:\Program Files\Quest VNC\QuestVncAudio.exe" --test-tone --port 5999`, then temporarily set Audio port 5999 in the app
  (Windows Firewall will ask to allow it). Press Ctrl+C to stop.

**"Port ... is already in use"**
Another program is using that port, for example another VNC server, or an older Quest VNC Server. Choose another port,
or close/uninstall the other program and run the setup again.

**"Port ... is reserved by Windows"**
Hyper-V, WSL or Docker reserved a range of ports. Choose a port outside the range shown.

**The setup window closes straight away or says scripts are disabled**
Your PC's policy may block PowerShell scripts. Open **Windows PowerShell as administrator** and run:
`powershell -ExecutionPolicy Bypass -File "C:\path\to\install.ps1"` (with the real path to the extracted folder).

**TightVNC didn't install**
Install it yourself from tightvnc.com (choose the 64-bit installer, then **Custom** and only **TightVNC Server**),
then run this setup again. It will find TightVNC and just configure it.

**Where's the setup log?**
`%TEMP%\QuestVNC-setup.log` (press Win+R and paste that). TightVNC's own install log, if it was downloaded directly,
is `%TEMP%\QuestVNC-TightVNC-msi.log`.

## For administrators: unattended install

Run from an elevated PowerShell (so the password doesn't need to be handed to a new window):

```
powershell -ExecutionPolicy Bypass -File install.ps1 -VncPort 5900 -AudioPort 5910 -Password "secret12"
```

Giving `-Password` skips all questions. Other options:

* `-Unattended`: ask nothing; ports not given keep their current values (or the defaults), and the current password
  is kept on a re-run.
* `-TargetUser PC\name`: whose sign-in starts the sound sender (default: the user running the setup, or the signed-in
  user when run as SYSTEM).
* `-Uninstall`, with `-RemoveTightVnc` or `-KeepTightVnc` to skip the question.

Exit code 0 means success. The password passed with `-Password` is visible to other administrators in the process list
while the setup runs.

## For developers

* `install.ps1` is Windows PowerShell 5.1 code with no extra modules. Its pure helpers are tested by
  `tests/install.tests.ps1`, which runs on Windows PowerShell or on PowerShell 7 on any OS:
  `pwsh -NoProfile -File tests/install.tests.ps1`.
* `../package.sh` (in `installers/`) builds `QuestVncAudio.exe` from `../audio-sender` and makes `dist/QuestVncSetup-<version>-windows.zip` along with the Linux and macOS setups.
  Without the zip, the setup also finds the exe at `../../audio-sender/publish/QuestVncAudio.exe` in a source checkout.
* The TightVNC fallback download is pinned to 2.8.89 (URL and SHA-256 at the top of `install.ps1`, taken from the
  winget-pkgs manifest). A different hash only produces a warning; the GlavSoft Authenticode signature is what's enforced.
* TightVNC settings are written to `HKLM\SOFTWARE\TightVNC\Server` (the password DES-encrypted the standard VNC way)
  rather than passed as MSI properties, so the password never appears in a command line or install log.
