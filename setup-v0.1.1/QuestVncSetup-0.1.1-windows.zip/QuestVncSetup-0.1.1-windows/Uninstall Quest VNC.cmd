@echo off
rem Removes the Quest VNC sound sender and its settings, and asks whether to remove TightVNC too.
setlocal
if not exist "%~dp0install.ps1" goto :missing
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
rem Kept on one line: the uninstaller may delete this very file, and cmd must not read it again afterwards.
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -Uninstall -PauseAtEnd %* & exit /b
:missing
echo.
echo Quest VNC uninstall can't find install.ps1 next to this file.
echo You can also remove Quest VNC in Settings ^> Apps ^> Installed apps.
echo.
pause
exit /b 1
