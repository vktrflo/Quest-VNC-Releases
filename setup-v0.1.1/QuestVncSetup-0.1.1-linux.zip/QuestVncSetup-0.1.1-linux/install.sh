#!/usr/bin/env bash
# Quest VNC for Linux: one-step setup of a TigerVNC virtual desktop plus the sound sender.
#
#   ./install.sh               install, or upgrade / change ports and password (asks questions)
#   ./install.sh --uninstall   stop and remove everything this installer set up
#   ./install.sh --help        all options, including the ones for scripted installs
#
# Run it as your normal user. It uses sudo only to install missing packages, to open the
# firewall ports, and (if needed) to let your services run from boot.
set -euo pipefail

VERSION=1
HERE=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
CONFIG_HOME=${XDG_CONFIG_HOME:-$HOME/.config}
DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}
CONF_DIR="$CONFIG_HOME/questvnc"
DATA_DIR="$DATA_HOME/questvnc"
UNIT_DIR="$CONFIG_HOME/systemd/user"
SETTINGS="$CONF_DIR/linux-install.conf"
VNC_PW_FILE="$CONF_DIR/vncpasswd"
AUDIO_PW_FILE="$CONF_DIR/audio-password"
XAUTH_FILE="$CONF_DIR/Xauthority"
SENDER="$DATA_DIR/questvnc-audio.py"
HELPER="$DATA_DIR/questvnc-helper"
SINK=questvnc
UNITS=(questvnc.target questvnc-xvnc.service questvnc-desktop.service questvnc-audio.service)

# ---------------------------------------------------------------- output and questions

bold() { if [ -t 1 ]; then printf '\033[1m%s\033[0m\n' "$*"; else printf '%s\n' "$*"; fi; }
say() { printf '%s\n' "$*"; }
warn() { printf 'Note: %s\n' "$*" >&2; }
die() { printf 'Error: %s\n' "$*" >&2; exit 1; }

INTERACTIVE=1
[ -t 0 ] || INTERACTIVE=0

# ask_value "Question" default -> REPLY (the default when not interactive or on empty input)
ask_value() {
    REPLY=
    if [ "$INTERACTIVE" = 1 ]; then
        read -r -p "$1 [$2]: " REPLY || REPLY=
    fi
    REPLY=${REPLY:-$2}
}

# ask_yn "Question" y|n -> status 0 for yes (the default when not interactive or on empty input)
ask_yn() {
    local hint=y/N ans=
    [ "$2" = y ] && hint=Y/n
    if [ "$INTERACTIVE" = 1 ]; then
        read -r -p "$1 [$hint] " ans || ans=
    fi
    ans=${ans:-$2}
    case $ans in [yY]*) return 0 ;; *) return 1 ;; esac
}

have() { command -v "$1" >/dev/null 2>&1; }
IS_WSL=0
grep -qi microsoft /proc/sys/kernel/osrelease 2>/dev/null && IS_WSL=1

usage() {
    cat <<EOF
Usage: $0 [options]
       $0 --uninstall [--yes]

Sets up a TigerVNC virtual desktop and the Quest VNC sound sender as services of your user,
so the Quest VNC headset app can connect to this PC with picture and sound.

Options (each also as an environment variable, for scripted installs):
  --vnc-port N         VNC port (default 5901)                 QUESTVNC_VNC_PORT
  --sound-port N       sound port (default 5910)               QUESTVNC_SOUND_PORT
  --password-file F    read the password from the first line   QUESTVNC_PASSWORD (the password itself)
  --geometry WxH       virtual screen size (default 1920x1080) QUESTVNC_GEOMETRY
  --display N         X display number (default: VNC port - 5900 when free, else the first free from :10)
                                                               QUESTVNC_DISPLAY
  --desktop NAME|CMD   xfce, mate, lxqt, cinnamon, lxde, kde, gnome, or a command
                                                               QUESTVNC_DESKTOP
  --no-boot            don't start at boot without signing in (no "linger")
  --no-firewall        leave the firewall alone
  --no-start           write and enable everything, but don't start it now
  -y, --yes            don't ask: use the given values, the current ones or the defaults
  --uninstall          remove everything this installer set up
EOF
}

# ---------------------------------------------------------------- arguments

MODE=install
OPT_VNC_PORT=${QUESTVNC_VNC_PORT:-}
OPT_SOUND_PORT=${QUESTVNC_SOUND_PORT:-}
OPT_PASSWORD=${QUESTVNC_PASSWORD:-}
OPT_GEOMETRY=${QUESTVNC_GEOMETRY:-}
OPT_DESKTOP=${QUESTVNC_DESKTOP:-}
OPT_DISPLAY=${QUESTVNC_DISPLAY:-}
OPT_BOOT=1
OPT_FIREWALL=1
OPT_START=1
while [ $# -gt 0 ]; do
    case $1 in
        --uninstall) MODE=uninstall ;;
        --vnc-port) OPT_VNC_PORT=${2:?--vnc-port needs a value}; shift ;;
        --vnc-port=*) OPT_VNC_PORT=${1#*=} ;;
        --sound-port) OPT_SOUND_PORT=${2:?--sound-port needs a value}; shift ;;
        --sound-port=*) OPT_SOUND_PORT=${1#*=} ;;
        --password-file|--password-file=*)
            if [ "$1" = --password-file ]; then f=${2:?--password-file needs a file}; shift; else f=${1#*=}; fi
            [ -r "$f" ] || die "cannot read $f"
            IFS= read -r OPT_PASSWORD < "$f" || true
            OPT_PASSWORD=${OPT_PASSWORD%$'\r'} ;;
        --geometry) OPT_GEOMETRY=${2:?--geometry needs a value}; shift ;;
        --geometry=*) OPT_GEOMETRY=${1#*=} ;;
        --display) OPT_DISPLAY=${2:?--display needs a value}; shift ;;
        --display=*) OPT_DISPLAY=${1#*=} ;;
        --desktop) OPT_DESKTOP=${2:?--desktop needs a value}; shift ;;
        --desktop=*) OPT_DESKTOP=${1#*=} ;;
        --no-boot) OPT_BOOT=0 ;;
        --no-firewall) OPT_FIREWALL=0 ;;
        --no-start) OPT_START=0 ;;
        -y|--yes) INTERACTIVE=0 ;;
        -h|--help) usage; exit 0 ;;
        *) usage >&2; exit 2 ;;
    esac
    shift
done

if [ "$(id -u)" = 0 ] && [ "${QUESTVNC_ALLOW_ROOT:-}" != 1 ]; then
    die "run this as the user who will use the headset, not as root (it asks for sudo when needed)."
fi
USER_NAME=$(id -un)

SUDO=
if [ "$(id -u)" != 0 ]; then
    SUDO=sudo
fi
need_sudo() {
    [ -z "$SUDO" ] || have sudo || die "sudo is missing; ask an administrator to run: $*"
}

# ---------------------------------------------------------------- previous install

# Values from an earlier run (they become the defaults when re-running).
VNC_PORT='' SOUND_PORT='' DISPLAY_NUM='' GEOMETRY='' DESKTOP_CMD='' DESKTOP_NAME='' DESKTOP_ID=''
FIREWALL_DONE='' LINGER_BY_US='' PKGS_ADDED='' PKG_MANAGER=
if [ -f "$SETTINGS" ]; then
    # shellcheck disable=SC1090
    . "$SETTINGS"
fi
OLD_VNC_PORT=$VNC_PORT OLD_SOUND_PORT=$SOUND_PORT OLD_DISPLAY=$DISPLAY_NUM OLD_FIREWALL=$FIREWALL_DONE

save_settings() {
    mkdir -p "$CONF_DIR"
    {
        echo "# Written by the Quest VNC Linux installer (version $VERSION). Re-run install.sh to change."
        local k
        for k in VNC_PORT SOUND_PORT DISPLAY_NUM GEOMETRY DESKTOP_ID DESKTOP_NAME DESKTOP_CMD \
                 FIREWALL_DONE LINGER_BY_US PKGS_ADDED PKG_MANAGER; do
            printf '%s=%q\n' "$k" "${!k}"
        done
    } > "$SETTINGS.tmp"
    mv -f "$SETTINGS.tmp" "$SETTINGS"
}

# ---------------------------------------------------------------- systemd user manager

user_systemd_ok() { systemctl --user show-environment >/dev/null 2>&1; }

stop_units() {
    if user_systemd_ok; then
        systemctl --user stop questvnc.target questvnc-desktop.service questvnc-audio.service \
            questvnc-xvnc.service >/dev/null 2>&1 || true
    fi
}

# ---------------------------------------------------------------- firewall

ufw_active() { have ufw && $SUDO ufw status 2>/dev/null | grep -qi '^status: active'; }
firewalld_active() { have firewall-cmd && [ "$(firewall-cmd --state 2>/dev/null)" = running ]; }

# firewall_ports add|remove "kind:port,port"
firewall_ports() {
    local action=$1 kind=${2%%:*} ports=${2#*:} p
    [ -n "$2" ] || return 0
    IFS=, read -r -a plist <<< "$ports"
    case $kind in
        ufw)
            for p in "${plist[@]}"; do
                if [ "$action" = add ]; then $SUDO ufw allow "$p/tcp" comment 'Quest VNC' >/dev/null
                else $SUDO ufw delete allow "$p/tcp" >/dev/null 2>&1 || true; fi
            done ;;
        firewalld)
            for p in "${plist[@]}"; do
                if [ "$action" = add ]; then $SUDO firewall-cmd -q --permanent --add-port="$p/tcp"
                else $SUDO firewall-cmd -q --permanent --remove-port="$p/tcp" 2>/dev/null || true; fi
            done
            $SUDO firewall-cmd -q --reload ;;
    esac
}

# ---------------------------------------------------------------- uninstall

if [ "$MODE" = uninstall ]; then
    bold "Uninstalling Quest VNC (virtual desktop and sound)"
    if user_systemd_ok; then
        systemctl --user disable --now "${UNITS[@]}" >/dev/null 2>&1 || true
    fi
    for u in "${UNITS[@]}"; do rm -f "$UNIT_DIR/$u"; done
    if user_systemd_ok; then
        systemctl --user daemon-reload || true
        systemctl --user reset-failed "${UNITS[@]}" >/dev/null 2>&1 || true
    fi
    say "Stopped and removed the services."
    if have pactl; then
        for m in $(pactl list short modules 2>/dev/null | awk -v s="sink_name=$SINK" '$2 == "module-null-sink" && index($0, s) {print $1}'); do
            pactl unload-module "$m" 2>/dev/null || true
        done
    fi
    if [ -n "$FIREWALL_DONE" ] && ask_yn "Close the firewall ports this installer opened (${FIREWALL_DONE#*:})?" y; then
        need_sudo "remove the firewall rules"
        firewall_ports remove "$FIREWALL_DONE" && say "Closed them."
    fi
    if [ "$LINGER_BY_US" = 1 ] && ask_yn "Stop starting your user services at boot without signing in (turn off linger)?" y; then
        loginctl --no-ask-password disable-linger "$USER_NAME" 2>/dev/null \
            || { need_sudo "loginctl disable-linger $USER_NAME"; $SUDO loginctl disable-linger "$USER_NAME"; } || true
    fi
    rm -rf "$DATA_DIR"
    rm -f "$VNC_PW_FILE" "$AUDIO_PW_FILE" "$XAUTH_FILE" "$SETTINGS" "$SETTINGS.tmp"
    rmdir "$CONF_DIR" 2>/dev/null || true
    say "Removed $DATA_DIR and the password files in $CONF_DIR."
    if [ -n "$PKGS_ADDED" ]; then
        if ask_yn "Also remove the packages the installer added ($PKGS_ADDED)?" n; then
            need_sudo "remove $PKGS_ADDED"
            read -r -a pk <<< "$PKGS_ADDED"
            case $PKG_MANAGER in
                apt) $SUDO apt-get remove -y "${pk[@]}" ;;
                dnf) $SUDO dnf remove -y "${pk[@]}" ;;
                pacman) $SUDO pacman -Rs --noconfirm "${pk[@]}" ;;
                zypper) $SUDO zypper --non-interactive remove "${pk[@]}" ;;
            esac || warn "removing the packages failed; remove them with your package manager."
        else
            say "Kept the packages: $PKGS_ADDED"
        fi
    fi
    bold "Quest VNC is uninstalled."
    exit 0
fi

# ---------------------------------------------------------------- install: files we ship

SENDER_SRC=
for f in "$HERE/questvnc-audio.py" "$HERE/../../audio-sender/linux/questvnc-audio.py"; do
    if [ -f "$f" ]; then SENDER_SRC=$f; break; fi
done
[ -n "$SENDER_SRC" ] || die "questvnc-audio.py was not found next to install.sh (or in ../../audio-sender/linux)."

bold "Quest VNC for Linux: TigerVNC virtual desktop + sound for the headset"
[ -f "$SETTINGS" ] && say "Found an earlier install: press Enter to keep each current value."
say

# ---------------------------------------------------------------- packages

PM=
if have apt-get; then PM=apt
elif have dnf; then PM=dnf
elif have pacman; then PM=pacman
elif have zypper; then PM=zypper
fi

find_xvnc() {
    XVNC=
    if have Xtigervnc; then XVNC=$(command -v Xtigervnc)
    elif have Xvnc && Xvnc -version 2>&1 | grep -qi tigervnc; then XVNC=$(command -v Xvnc)
    fi
    VNCPASSWD=
    if have vncpasswd; then VNCPASSWD=$(command -v vncpasswd)
    elif have tigervncpasswd; then VNCPASSWD=$(command -v tigervncpasswd)
    fi
}

apt_has() { apt-cache show "$1" >/dev/null 2>&1; }

# Fills WANT with the packages for what is missing; MISSING with a readable list.
plan_packages() {
    WANT=() MISSING=()
    find_xvnc
    if [ -z "$XVNC" ]; then
        MISSING+=("TigerVNC server")
        case $PM in
            apt) WANT+=(tigervnc-standalone-server) ;;
            dnf) WANT+=(tigervnc-server) ;;
            pacman) WANT+=(tigervnc) ;;
            zypper) WANT+=(xorg-x11-Xvnc) ;;
        esac
    fi
    if [ -z "$VNCPASSWD" ]; then
        MISSING+=(vncpasswd)
        case $PM in
            apt) if apt_has tigervnc-tools; then WANT+=(tigervnc-tools); else WANT+=(tigervnc-common); fi ;;
            dnf) WANT+=(tigervnc-server) ;;
            pacman) WANT+=(tigervnc) ;;
            zypper) WANT+=(tigervnc) ;;
        esac
    fi
    if ! have xauth; then
        MISSING+=(xauth)
        case $PM in
            apt|zypper) WANT+=(xauth) ;;
            dnf) WANT+=(xorg-x11-xauth) ;;
            pacman) WANT+=(xorg-xauth) ;;
        esac
    fi
    if ! have python3; then
        MISSING+=(python3)
        case $PM in pacman) WANT+=(python) ;; *) WANT+=(python3) ;; esac
    fi
    # pactl makes the headset's own sound output; parec captures it (pw-record also works).
    if ! have pactl || { ! have parec && ! have pw-record; }; then
        MISSING+=("pactl/parec")
        case $PM in
            pacman) WANT+=(libpulse) ;;
            *) WANT+=(pulseaudio-utils) ;;
        esac
    fi
    if ! have dbus-run-session; then
        MISSING+=(dbus-run-session)
        case $PM in
            apt) WANT+=(dbus-x11) ;;
            dnf) WANT+=(dbus-tools) ;;
            pacman) WANT+=(dbus) ;;
            zypper) WANT+=(dbus-1-tools) ;;
        esac
    fi
}

install_packages() {   # install_packages pkg...
    [ $# -gt 0 ] || return 0
    [ -n "$PM" ] || die "no supported package manager (apt, dnf, pacman, zypper) found. Install these yourself: $*"
    need_sudo "install $*"
    say "Installing: $*"
    case $PM in
        apt) $SUDO apt-get update -q && $SUDO apt-get install -y "$@" ;;
        dnf) $SUDO dnf install -y "$@" ;;
        pacman) $SUDO pacman -S --needed --noconfirm "$@" ;;
        zypper) $SUDO zypper --non-interactive install "$@" ;;
    esac || die "installing the packages failed (see above)."
    local p
    for p in "$@"; do
        case " $PKGS_ADDED " in *" $p "*) ;; *) PKGS_ADDED="${PKGS_ADDED:+$PKGS_ADDED }$p" ;; esac
    done
    PKG_MANAGER=$PM
}

plan_packages
if [ ${#MISSING[@]} -gt 0 ]; then
    # De-duplicate (dnf and pacman name the same package twice).
    mapfile -t WANT < <(printf '%s\n' "${WANT[@]}" | awk 'NF && !seen[$0]++')
    say "Missing: ${MISSING[*]}"
    [ -n "$PM" ] || die "no supported package manager found. Install TigerVNC (Xvnc or Xtigervnc, vncpasswd), xauth, python3, pactl/parec and dbus-run-session, then run this again."
    if ask_yn "Install ${WANT[*]} with $PM (uses sudo)?" y; then
        install_packages "${WANT[@]}"
    else
        die "these are needed; install them and run this again."
    fi
    plan_packages
    [ ${#MISSING[@]} -eq 0 ] || die "still missing after installing: ${MISSING[*]}"
else
    say "TigerVNC ($XVNC), vncpasswd, xauth, Python and the sound tools are already installed."
fi

# ---------------------------------------------------------------- desktop

# id | name | start command | XDG_CURRENT_DESKTOP. Ordered by how well each copes with a second
# session of the same user that may also be signed in on the physical screen.
DESKTOPS=(
    "xfce|XFCE|startxfce4|XFCE"
    "mate|MATE|mate-session|MATE"
    "lxqt|LXQt|startlxqt|LXQt"
    "cinnamon|Cinnamon|cinnamon-session|X-Cinnamon"
    "lxde|LXDE|startlxde|LXDE"
    "kde|KDE Plasma (X11)|startplasma-x11|KDE"
    "gnome|GNOME|gnome-session|GNOME"
)

install_xfce() {
    case $PM in
        apt) local pk=(xfce4 xfce4-terminal dbus-x11) p
             need_sudo "install XFCE"
             # Without recommends, so no display manager or other extras come along.
             $SUDO apt-get install -y --no-install-recommends "${pk[@]}" || die "installing XFCE failed."
             for p in "${pk[@]}"; do PKGS_ADDED="${PKGS_ADDED:+$PKGS_ADDED }$p"; done
             PKG_MANAGER=apt ;;
        dnf) install_packages xfce4-session xfwm4 xfce4-panel xfdesktop xfce4-settings Thunar xfce4-terminal ;;
        pacman) install_packages xfce4 ;;
        zypper) install_packages xfce4-session xfwm4 xfce4-panel xfdesktop xfce4-settings thunar xfce4-terminal ;;
        *) die "no supported package manager to install XFCE with." ;;
    esac
    have startxfce4 || die "XFCE was installed but startxfce4 is still missing."
}

pick_desktop_entry() {   # sets DESKTOP_ID DESKTOP_NAME DESKTOP_CMD XDG_DESK from an entry
    IFS='|' read -r DESKTOP_ID DESKTOP_NAME DESKTOP_CMD XDG_DESK <<< "$1"
}

choose_desktop() {
    local e found=() i choice def=1
    XDG_DESK=
    if [ -n "$OPT_DESKTOP" ]; then
        for e in "${DESKTOPS[@]}"; do
            if [ "${e%%|*}" = "${OPT_DESKTOP,,}" ]; then
                pick_desktop_entry "$e"
                have "$DESKTOP_CMD" || die "$DESKTOP_NAME ($DESKTOP_CMD) is not installed."
                return
            fi
        done
        # Any other value is a command line that starts a session.
        DESKTOP_ID=custom DESKTOP_NAME=$OPT_DESKTOP DESKTOP_CMD=$OPT_DESKTOP XDG_DESK=
        have "${OPT_DESKTOP%% *}" || die "'${OPT_DESKTOP%% *}' was not found."
        return
    fi
    for e in "${DESKTOPS[@]}"; do
        IFS='|' read -r _ _ cmd _ <<< "$e"
        have "$cmd" && found+=("$e")
    done
    # GNOME and Plasma usually can't run a second session of a user who is signed in on the
    # screen, and their newest releases have no X11 session at all, so prefer installing XFCE.
    local good=0
    for e in ${found[@]+"${found[@]}"}; do case ${e%%|*} in gnome|kde) ;; *) good=1 ;; esac; done
    if [ "$good" = 0 ] && [ "$DESKTOP_ID" != gnome ] && [ "$DESKTOP_ID" != kde ]; then
        if [ ${#found[@]} -eq 0 ]; then
            say "No desktop that works inside the virtual screen was found (XFCE, MATE, LXQt, Cinnamon, LXDE, KDE or GNOME)."
        else
            say "Only GNOME or KDE Plasma was found. They often can't start a second session for a user"
            say "who is also signed in on the screen, and their newest versions can't run in a VNC screen at all."
        fi
        if ask_yn "Install the XFCE desktop for the headset (light, and works well for this)?" y; then
            install_xfce
            pick_desktop_entry "${DESKTOPS[0]}"
            return
        fi
        [ ${#found[@]} -gt 0 ] || die "install a desktop (for example XFCE) and run this again, or pass --desktop COMMAND."
    fi
    # Default: the current choice when re-running, else the first (preferred) one.
    for i in "${!found[@]}"; do
        [ "${found[$i]%%|*}" = "$DESKTOP_ID" ] && def=$((i + 1))
    done
    if [ ${#found[@]} -gt 1 ] && [ "$INTERACTIVE" = 1 ]; then
        say "Desktops found for the virtual screen:"
        for i in "${!found[@]}"; do
            IFS='|' read -r _ name _ _ <<< "${found[$i]}"
            say "  $((i + 1))) $name"
        done
        while :; do
            ask_value "Which desktop should the headset get?" "$def"
            choice=$REPLY
            if [[ $choice =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le ${#found[@]} ]; then break; fi
            say "Type a number from 1 to ${#found[@]}."
        done
    else
        choice=$def
    fi
    pick_desktop_entry "${found[$((choice - 1))]}"
}

# DESKTOP_ID may hold "custom" from an earlier run: keep that command unless told otherwise.
if [ -z "$OPT_DESKTOP" ] && [ "$DESKTOP_ID" = custom ] && [ -n "$DESKTOP_CMD" ]; then
    OPT_DESKTOP=$DESKTOP_CMD
fi
choose_desktop
say "Desktop for the headset: $DESKTOP_NAME"
case $DESKTOP_ID in
    gnome) warn "GNOME usually refuses to start a second session for a user who is already signed in on the screen, and GNOME 49 and later have no X11 session for a VNC screen at all. If the headset shows a black screen, install XFCE (or MATE) and run this again." ;;
    kde) warn "KDE Plasma may not start a second session while you are signed in to Plasma on the screen. If the headset shows a black screen, install XFCE (or MATE) and run this again." ;;
esac
say

# ---------------------------------------------------------------- ports, password, screen size

port_listening() {   # port_listening P -> 0 when something listens on TCP port P
    if have ss; then
        ss -Hltn 2>/dev/null | awk '{print $4}' | grep -Eq "[:.]$1\$"
    else
        if python3 -c 'import socket,sys; s=socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("", int(sys.argv[1])))' "$1" 2>/dev/null; then
            return 1
        fi
    fi
}

port_ok() {   # port_ok P other_port label -> 0, or prints why not
    local p=$1
    if ! [[ $p =~ ^[0-9]+$ ]] || [ "$p" -lt 1024 ] || [ "$p" -gt 65535 ]; then
        say "  Use a number from 1024 to 65535."; return 1
    fi
    if [ "$p" = "$2" ]; then say "  That's the $3 port already; pick a different one."; return 1; fi
    # Our own services hold the ports of the current install; those count as free.
    if [ "$p" != "$OLD_VNC_PORT" ] && [ "$p" != "$OLD_SOUND_PORT" ] && port_listening "$p"; then
        say "  Port $p is already in use by another program; pick a different one."; return 1
    fi
    return 0
}

choose_port() {   # choose_port "Question" option_value default other label -> PORT
    local q=$1 opt=$2 def=$3 other=$4 label=$5
    if [ -n "$opt" ]; then
        port_ok "$opt" "$other" "$label" || die "port $opt can't be used."
        PORT=$opt; return
    fi
    while :; do
        ask_value "$q" "$def"
        if port_ok "$REPLY" "$other" "$label"; then PORT=$REPLY; return; fi
        [ "$INTERACTIVE" = 1 ] || die "the default $q $def can't be used; pass another one."
    done
}

next_free_port() {   # first port from $1 upward that is free and not $2
    local p=$1
    while [ "$p" = "$2" ] || { [ "$p" != "$OLD_VNC_PORT" ] && [ "$p" != "$OLD_SOUND_PORT" ] && port_listening "$p"; }; do
        p=$((p + 1))
    done
    echo "$p"
}

DEF_VNC=${OLD_VNC_PORT:-$(next_free_port 5901 "")}
choose_port "VNC port for the headset" "$OPT_VNC_PORT" "$DEF_VNC" "" "sound"
VNC_PORT=$PORT
DEF_SOUND=${OLD_SOUND_PORT:-5910}
if ! port_ok "$DEF_SOUND" "$VNC_PORT" VNC >/dev/null; then
    DEF_SOUND=$(next_free_port 5910 "$VNC_PORT")
fi
choose_port "Sound port for the headset" "$OPT_SOUND_PORT" "$DEF_SOUND" "$VNC_PORT" "VNC"
SOUND_PORT=$PORT

# Screen size: the headset can also change it later (TigerVNC accepts size requests).
DEF_GEOM=${GEOMETRY:-1920x1080}
while :; do
    if [ -n "$OPT_GEOMETRY" ]; then REPLY=$OPT_GEOMETRY; else ask_value "Virtual screen size" "$DEF_GEOM"; fi
    if [[ $REPLY =~ ^([0-9]{3,5})x([0-9]{3,5})$ ]] && [ "${BASH_REMATCH[1]}" -le 16384 ] && [ "${BASH_REMATCH[2]}" -le 16384 ]; then
        GEOMETRY=$REPLY; break
    fi
    say "  Write it as WIDTHxHEIGHT, for example 1920x1080."
    [ "$INTERACTIVE" = 1 ] && [ -z "$OPT_GEOMETRY" ] || die "bad screen size '$REPLY'."
done

check_password() {   # check_password PW -> 0 if usable
    if [ ${#1} -lt 6 ]; then say "  Use at least 6 characters."; return 1; fi
    case $1 in *[[:cntrl:]]*) say "  Don't use control characters."; return 1 ;; esac
    return 0
}

PASSWORD=
KEEP_PASSWORD=0
if [ -n "$OPT_PASSWORD" ]; then
    check_password "$OPT_PASSWORD" || die "the given password can't be used."
    PASSWORD=$OPT_PASSWORD
elif [ -s "$VNC_PW_FILE" ] && [ -s "$AUDIO_PW_FILE" ] && ask_yn "Keep the current password?" y; then
    KEEP_PASSWORD=1
elif [ "$INTERACTIVE" = 1 ]; then
    say "Choose the password the headset will use (for both the picture and the sound)."
    say "VNC only checks the first 8 characters, so 8 is the useful length."
    while :; do
        read -r -s -p "Password: " PASSWORD || PASSWORD=; echo
        check_password "$PASSWORD" || continue
        read -r -s -p "Type it again: " PW2 || PW2=; echo
        [ "$PASSWORD" = "$PW2" ] && break
        say "  The two passwords differ; try again."
    done
else
    die "no password given: set QUESTVNC_PASSWORD or use --password-file FILE."
fi
if [ "$KEEP_PASSWORD" = 0 ] && [ ${#PASSWORD} -gt 8 ]; then
    warn "VNC only checks the first 8 characters of the password. Type the whole password in Quest VNC; the sound uses all of it."
fi

# Display number: PORT-5900 when that is 1..99 and free (5901 -> :1, as with vncserver),
# otherwise the first free one from :10 (clear of the ones login screens use).
display_free() {
    [ "$1" = "$OLD_DISPLAY" ] && return 0
    [ ! -e "/tmp/.X$1-lock" ] && [ ! -e "/tmp/.X11-unix/X$1" ]
}
DISPLAY_NUM=
n=$((VNC_PORT - 5900))
if [ -n "$OPT_DISPLAY" ]; then
    [[ $OPT_DISPLAY =~ ^:?([0-9]+)$ ]] || die "bad display number '$OPT_DISPLAY'."
    DISPLAY_NUM=${BASH_REMATCH[1]}
    display_free "$DISPLAY_NUM" || die "display :$DISPLAY_NUM is in use."
elif [ -n "$OLD_DISPLAY" ] && [ "$VNC_PORT" = "$OLD_VNC_PORT" ]; then
    DISPLAY_NUM=$OLD_DISPLAY
elif [ "$n" -ge 1 ] && [ "$n" -le 99 ] && display_free "$n"; then
    DISPLAY_NUM=$n
else
    for ((n = 10; n < 1000; n++)); do
        if display_free "$n"; then DISPLAY_NUM=$n; break; fi
    done
fi
[ -n "$DISPLAY_NUM" ] || die "no free X display number found."

# ---------------------------------------------------------------- start at boot (linger)

LINGER=$(loginctl show-user "$USER_NAME" -p Linger --value 2>/dev/null || true)
if [ "$OPT_BOOT" = 1 ] && [ "$LINGER" != yes ]; then
    say
    say "Quest VNC can start when the PC boots, without anyone signing in on the screen"
    say "(handy for a PC used only from the headset). This turns on systemd \"linger\" for $USER_NAME."
    if ask_yn "Start at boot without signing in?" y; then
        if loginctl --no-ask-password enable-linger "$USER_NAME" 2>/dev/null \
            || { need_sudo "loginctl enable-linger $USER_NAME"; $SUDO loginctl enable-linger "$USER_NAME"; }; then
            LINGER_BY_US=1
            say "Turned on linger: your services now run from boot."
        else
            warn "could not turn on linger; Quest VNC will start when you sign in instead."
        fi
    fi
elif [ "$LINGER" = yes ]; then
    say "Linger is on for $USER_NAME: Quest VNC runs from boot."
fi

# The user's service manager must be reachable (it is after signing in, or once linger is on).
if ! user_systemd_ok; then
    for _ in 1 2 3 4 5 6 7 8 9 10; do
        export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/run/user/$(id -u)}
        user_systemd_ok && break
        sleep 0.5
    done
fi
user_systemd_ok || die "can't reach your systemd user services (systemctl --user). Run this from your own desktop or SSH login, not through 'su' or 'sudo'."

# ---------------------------------------------------------------- sound server

# The sender needs your PulseAudio or PipeWire running, also when nobody is signed in.
AUDIO_WANTS=
unit_exists() { [ -n "$(systemctl --user list-unit-files "$1" --no-legend 2>/dev/null)" ]; }
if unit_exists pipewire-pulse.socket; then
    AUDIO_WANTS="pipewire.socket pipewire-pulse.socket"
    unit_exists wireplumber.service && AUDIO_WANTS="$AUDIO_WANTS wireplumber.service"
elif unit_exists pulseaudio.socket; then
    AUDIO_WANTS="pulseaudio.socket"
fi
if [ -n "$AUDIO_WANTS" ]; then
    for u in $AUDIO_WANTS; do
        st=$(systemctl --user is-enabled "$u" 2>/dev/null || true)
        case $st in
            enabled|enabled-runtime|static|indirect|alias|generated) ;;
            *) systemctl --user enable "$u" >/dev/null 2>&1 && say "Enabled $u so sound works without signing in." || true ;;
        esac
    done
else
    warn "no PulseAudio or PipeWire user service was found; sound only works while that sound server runs."
fi

# ---------------------------------------------------------------- write files

stop_units
mkdir -p "$CONF_DIR" "$DATA_DIR" "$UNIT_DIR"
chmod 700 "$CONF_DIR"

cp "$SENDER_SRC" "$SENDER.tmp" && chmod 755 "$SENDER.tmp" && mv -f "$SENDER.tmp" "$SENDER"

cat > "$HELPER.tmp" <<'EOF'
#!/bin/sh
# Quest VNC helper used by the systemd user units (written by install.sh).
#   questvnc-helper xauth FILE :N    make a fresh X cookie for display :N
#   questvnc-helper wait-x N         wait until display :N accepts connections
set -e
case $1 in
    xauth)
        umask 077
        rm -f "$2" "$2.tmp"
        : > "$2"; : > "$2.tmp"
        cookie=$(od -An -N16 -tx1 /dev/urandom | tr -d ' \n')
        # A wildcard entry (family ffff), so clients match whatever the host name is.
        xauth -q -f "$2.tmp" add "$3" MIT-MAGIC-COOKIE-1 "$cookie"
        xauth -q -f "$2.tmp" nlist "$3" | sed -e 's/^..../ffff/' | xauth -q -f "$2" nmerge -
        rm -f "$2.tmp"
        ;;
    wait-x)
        i=0
        while [ $i -lt 100 ]; do
            [ -S "/tmp/.X11-unix/X$2" ] && exit 0
            sleep 0.1; i=$((i + 1))
        done
        echo "display :$2 did not appear" >&2; exit 1 ;;
    *) echo "usage: $0 xauth FILE :N | wait-x N" >&2; exit 2 ;;
esac
EOF
chmod 755 "$HELPER.tmp" && mv -f "$HELPER.tmp" "$HELPER"

if [ "$KEEP_PASSWORD" = 0 ]; then
    (
        umask 077
        printf '%s\n' "$PASSWORD" | "$VNCPASSWD" -f > "$VNC_PW_FILE.tmp"
        [ "$(wc -c < "$VNC_PW_FILE.tmp")" -ge 8 ] || { rm -f "$VNC_PW_FILE.tmp"; exit 1; }
        mv -f "$VNC_PW_FILE.tmp" "$VNC_PW_FILE"
        printf '%s\n' "$PASSWORD" > "$AUDIO_PW_FILE.tmp"
        mv -f "$AUDIO_PW_FILE.tmp" "$AUDIO_PW_FILE"
    ) || die "$VNCPASSWD could not write the password file."
fi
chmod 600 "$VNC_PW_FILE" "$AUDIO_PW_FILE"
unset PASSWORD PW2 OPT_PASSWORD

# Quote one argument for a systemd Exec line.
uq() {
    local s=$1
    s=${s//\\/\\\\}; s=${s//\"/\\\"}; s=${s//%/%%}; s=${s//\$/\$\$}
    printf '"%s"' "$s"
}

HOST=$(hostname 2>/dev/null || uname -n)
PYTHON=$(command -v python3)
SINK_ARGS=()
have pactl && SINK_ARGS=(--sink "$SINK")

cat > "$UNIT_DIR/questvnc.target" <<EOF
# Written by the Quest VNC installer. Re-run install.sh to change; install.sh --uninstall removes it.
[Unit]
Description=Quest VNC: virtual desktop and sound for the headset
Wants=questvnc-xvnc.service questvnc-desktop.service questvnc-audio.service

[Install]
WantedBy=default.target
EOF

cat > "$UNIT_DIR/questvnc-xvnc.service" <<EOF
# Written by the Quest VNC installer. Re-run install.sh to change; install.sh --uninstall removes it.
[Unit]
Description=Quest VNC virtual screen (TigerVNC on port $VNC_PORT, display :$DISPLAY_NUM)
PartOf=questvnc.target

[Service]
ExecStartPre=$(uq "$HELPER") xauth $(uq "$XAUTH_FILE") :$DISPLAY_NUM
ExecStart=$(uq "$XVNC") :$DISPLAY_NUM -auth $(uq "$XAUTH_FILE") -rfbport $VNC_PORT -rfbauth $(uq "$VNC_PW_FILE") -SecurityTypes VncAuth -localhost=0 -nolisten tcp -geometry $GEOMETRY -depth 24 -AlwaysShared -AcceptSetDesktopSize -desktop $(uq "Quest VNC on $HOST")
Restart=on-failure
RestartSec=3
EOF

# (UnsetEnvironment= also removes Environment= values, so the two lists must not overlap.)
# Force every toolkit onto the virtual X display. With WAYLAND_DISPLAY unset, GTK and Qt still try the
# default Wayland socket (wayland-0) in XDG_RUNTIME_DIR, which on WSL is WSLg's: windows would open on the
# Windows desktop instead of in the headset.
X11_ONLY="GDK_BACKEND=x11 QT_QPA_PLATFORM=xcb CLUTTER_BACKEND=x11 SDL_VIDEODRIVER=x11 MOZ_ENABLE_WAYLAND=0 ELECTRON_OZONE_PLATFORM_HINT=x11"
DESK_ENV="DISPLAY=:$DISPLAY_NUM XDG_SESSION_TYPE=x11 $X11_ONLY"
have pactl && DESK_ENV="$DESK_ENV PULSE_SINK=$SINK"
DESK_UNSET="WAYLAND_DISPLAY DBUS_SESSION_BUS_ADDRESS SESSION_MANAGER XDG_SESSION_ID XDG_SEAT XDG_VTNR GNOME_SETUP_DISPLAY"
if [ -n "$XDG_DESK" ]; then
    DESK_ENV="$DESK_ENV XDG_CURRENT_DESKTOP=$XDG_DESK XDG_SESSION_DESKTOP=$DESKTOP_ID DESKTOP_SESSION=$DESKTOP_ID"
else
    DESK_UNSET="$DESK_UNSET XDG_CURRENT_DESKTOP XDG_SESSION_DESKTOP DESKTOP_SESSION"
fi
cat > "$UNIT_DIR/questvnc-desktop.service" <<EOF
# Written by the Quest VNC installer. Re-run install.sh to change; install.sh --uninstall removes it.
[Unit]
Description=Quest VNC desktop session ($DESKTOP_NAME on display :$DISPLAY_NUM)
BindsTo=questvnc-xvnc.service
After=questvnc-xvnc.service questvnc-audio.service
PartOf=questvnc.target
StartLimitIntervalSec=60
StartLimitBurst=6

[Service]
# Don't inherit the physical screen's session (its D-Bus, Wayland or X display).
UnsetEnvironment=$DESK_UNSET
Environment=$DESK_ENV
Environment=XAUTHORITY=$(uq "$XAUTH_FILE")
ExecStartPre=$(uq "$HELPER") wait-x $DISPLAY_NUM
# A login shell reads ~/.profile, like a normal sign-in; the session gets its own D-Bus. The display
# settings are applied again after it, in case ~/.profile sets DISPLAY (common on WSL).
ExecStart=/bin/sh -lc $(uq "unset WAYLAND_DISPLAY; export DISPLAY=:$DISPLAY_NUM XAUTHORITY='$XAUTH_FILE' $X11_ONLY; exec dbus-run-session -- $DESKTOP_CMD")
# Signing out inside the headset starts a fresh desktop.
Restart=always
RestartSec=2
EOF

AUDIO_UNIT_DEPS=
[ -n "$AUDIO_WANTS" ] && AUDIO_UNIT_DEPS="Wants=$AUDIO_WANTS
After=pipewire.service pipewire-pulse.service wireplumber.service pulseaudio.service"
SENDER_ARGS="--port $SOUND_PORT --password-file $(uq "$AUDIO_PW_FILE")"
for a in ${SINK_ARGS[@]+"${SINK_ARGS[@]}"}; do SENDER_ARGS="$SENDER_ARGS $(uq "$a")"; done
SETUP_LINE=
[ ${#SINK_ARGS[@]} -gt 0 ] && SETUP_LINE="# Make the headset's sound output before the desktop starts (the desktop plays into it).
ExecStartPre=-$(uq "$PYTHON") $(uq "$SENDER") --sink $SINK --setup-sink"
cat > "$UNIT_DIR/questvnc-audio.service" <<EOF
# Written by the Quest VNC installer. Re-run install.sh to change; install.sh --uninstall removes it.
[Unit]
Description=Quest VNC sound sender (port $SOUND_PORT)
PartOf=questvnc.target
$AUDIO_UNIT_DEPS

[Service]
$SETUP_LINE
ExecStart=$(uq "$PYTHON") -u $(uq "$SENDER") $SENDER_ARGS
Restart=always
RestartSec=3
EOF

# ---------------------------------------------------------------- firewall

FIREWALL_KIND=
if [ "$OPT_FIREWALL" = 1 ]; then
    if firewalld_active; then FIREWALL_KIND=firewalld
    elif have ufw && systemctl is-active --quiet ufw 2>/dev/null; then
        # ufw's service runs even when ufw is switched off; ask ufw itself (needs sudo).
        say "Checking whether the ufw firewall is on (sudo may ask for your password)..."
        if ufw_active; then FIREWALL_KIND=ufw; fi
    fi
fi
WANT_FW=
[ -n "$FIREWALL_KIND" ] && WANT_FW="$FIREWALL_KIND:$VNC_PORT,$SOUND_PORT"
if [ -n "$OLD_FIREWALL" ] && [ "$OLD_FIREWALL" != "$WANT_FW" ]; then
    firewall_ports remove "$OLD_FIREWALL" || true
    FIREWALL_DONE=
fi
if [ -n "$WANT_FW" ] && [ "$WANT_FW" != "$FIREWALL_DONE" ]; then
    say
    if ask_yn "The $FIREWALL_KIND firewall is on. Open TCP ports $VNC_PORT and $SOUND_PORT for the headset?" y; then
        need_sudo "open ports $VNC_PORT and $SOUND_PORT"
        if firewall_ports add "$WANT_FW"; then
            FIREWALL_DONE=$WANT_FW
            say "Opened ports $VNC_PORT and $SOUND_PORT."
        else
            warn "opening the ports failed; the headset may not reach this PC."
        fi
    else
        say "Left the firewall alone. The headset needs TCP ports $VNC_PORT and $SOUND_PORT."
    fi
fi

save_settings

# ---------------------------------------------------------------- start

systemctl --user daemon-reload
systemctl --user reset-failed "${UNITS[@]}" >/dev/null 2>&1 || true
systemctl --user enable questvnc.target >/dev/null
if [ "$OPT_START" = 1 ]; then
    systemctl --user start questvnc.target
    SERVICES=(questvnc-xvnc.service questvnc-audio.service questvnc-desktop.service)
    for _ in $(seq 40); do   # up to 20 s: the sound output may wait for the sound server
        all=1
        for u in "${SERVICES[@]}"; do systemctl --user is-active --quiet "$u" || all=0; done
        [ "$all" = 1 ] && break
        sleep 0.5
    done
    for u in "${SERVICES[@]}"; do
        st=$(systemctl --user is-active "$u" 2>/dev/null || true)
        [ "$st" = active ] || warn "$u is ${st:-not running}; see: journalctl --user -u $u"
    done
fi

lan_addresses() {
    local a
    if have ip; then
        ip -4 -o addr show scope global 2>/dev/null | awk '{sub("/.*", "", $4); print $4}'
    elif a=$(hostname -I 2>/dev/null); then
        # shellcheck disable=SC2086
        printf '%s\n' $a | grep -v ':'
    fi
}
ADDRS=$(lan_addresses | paste -sd ' ' - || true)

say
bold "Quest VNC is set up."
say "  This PC:     ${ADDRS:-(no network address found)}  ($HOST)"
say "  VNC port:    $VNC_PORT   (display :$DISPLAY_NUM, $GEOMETRY, $DESKTOP_NAME)"
say "  Sound port:  $SOUND_PORT"
say "  Password:    the one you chose (stored in $CONF_DIR, readable only by you)"
say
case $VNC_PORT in
    5900|5901|5902|5903) step="add this PC (or use Scan)" ;;
    *) step="add this PC with its address and port $VNC_PORT (Scan only tries ports 5900 to 5903)" ;;
esac
if [ "$SOUND_PORT" != 5910 ]; then
    say "In Quest VNC, $step, and in its Edit screen set Audio port to $SOUND_PORT."
else
    say "In Quest VNC, $step."
fi
[ "$OPT_START" = 1 ] || say "Start it with: systemctl --user start questvnc.target"
if [ "$IS_WSL" = 1 ]; then
    say
    bold "This is WSL: the headset can't reach it until Windows passes the ports through."
    say "  WSL normally sits behind Windows on its own private network, so the address above only works from"
    say "  this PC. Easiest fix (Windows 11 22H2 or later): add these lines to %UserProfile%\\.wslconfig,"
    say "  then run 'wsl --shutdown' in Windows and open WSL again:"
    say "      [wsl2]"
    say "      networkingMode=mirrored"
    say "  Then use the Windows PC's own address in Quest VNC, and allow ports $VNC_PORT and $SOUND_PORT"
    say "  in Windows Defender Firewall (Private networks). For other options, see README.md."
fi
say "Run ./install.sh again to change ports or the password; ./install.sh --uninstall removes it."
