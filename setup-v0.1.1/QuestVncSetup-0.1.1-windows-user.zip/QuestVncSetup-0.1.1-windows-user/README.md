# Quest VNC — Per-User Windows Installer

A separate download from the legacy `QuestVncSetup-<version>-windows.zip`.
No administrator rights, no `Program Files`, no Windows service.
Each binary installs itself for the current user.

## Install

1. Open the zip, click `Extract All`, then go to the extracted folder.
2. Double-click **Install Quest VNC (Per User).cmd**.
3. The wrapper asks for the VNC port (default 5900), the audio port (default 5910),
   and a password. The wrapper opens those ports in Windows Firewall under one short
   elevation, then drops back.
4. Both binaries install for your user account and start running hidden. Sign in to
   Windows and they're already there.

The wrapper prints the LAN addresses to point the Quest VNC app at.

## Why a separate download?

- No admin rights required to install or run.
- Each user on the same PC can install independently.
- Uninstall cleans up exactly the user it installed. No shared state.
- The legacy installer (TightVNC, machine-wide) is still available for users who
  want a shared, machine-wide listener.

## Uninstall

Either:
- **Settings > Apps > Installed apps**, then remove *Quest VNC Server* and *Quest VNC
  Audio Sender*. The wrapper uninstalls both with one button: **Uninstall Quest VNC
  (Per User).cmd**.

The wrapper also removes the firewall rules under one elevation.

## Files it touches

| What | Where |
|------|-------|
| Server binary | `%LOCALAPPDATA%\Programs\QuestVncServer\QuestVncServer.exe` |
| Server settings | `%APPDATA%\QuestVncServer\server.conf` (owner-only ACL — your password) |
| Server log | `%LOCALAPPDATA%\QuestVncServer\server.log` |
| Audio binary | `%LOCALAPPDATA%\Programs\QuestVncAudio\QuestVncAudio.exe` |
| Audio settings | `%APPDATA%\QuestVncAudio\settings.conf` |
| Audio log | `%LOCALAPPDATA%\QuestVncAudio\audio.log` |
| Autostart | `HKCU\Software\Microsoft\Windows\CurrentVersion\Run\QuestVncServer` and `…\QuestVncAudio` |
| Apps & features | `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\QuestVncServer` and `…\QuestVncAudio` |
| Start menu | `Quest VNC Server.lnk` and `Quest VNC Audio Sender.lnk` under your Start menu Programs |
| Firewall rules | Two rules, group `Quest VNC`, Private profile only |

## Coexistence with the legacy TightVNC install

The wrapper detects the legacy install (TightVNC, machine-wide) and asks before
removing it. Both can run side-by-side; you pick which one is active on your PC.
