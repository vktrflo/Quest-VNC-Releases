@echo off
rem Quest VNC setup (Per User, no admin needed): double-click this file. It asks for ports and a password
rem (no elevation unless the Windows Firewall step opens the ports) and then installs both binaries.
setlocal
if not exist "%~dp0install.ps1" goto :notextracted
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" -PauseAtEnd %* & exit /b
:notextracted
echo.
echo Quest VNC setup can't find install.ps1 next to this file.
echo If you opened the zip without extracting it, right-click the zip, choose "Extract All",
echo and run "Install Quest VNC (Per User).cmd" from the extracted folder.
echo.
pause
exit /b 1