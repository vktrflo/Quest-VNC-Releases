<#
.SYNOPSIS
Per-user Quest VNC installer. Calls QuestVncServer.exe --install and QuestVncAudio.exe --install,
opens two Windows Firewall rules under one elevation, and exits without persisting admin context.

.DESCRIPTION
The legacy installer in ../installer/install.ps1 uses TightVNC and HKLM. This one uses only HKCU
and %LOCALAPPDATA%. Each binary owns its own lifecycle; this script is glue.

It accepts the same -VncPort / -AudioPort / -Password parameters as the legacy installer so the same
documentation can point at both. -Unattended uses defaults.

.PARAMETER VncPort
Port for the VNC server. 0 = prompt (default), 1..65535 = use that.

.PARAMETER AudioPort
Port for the audio sender. 0 = prompt (default).

.PARAMETER Password
Plaintext password. Used to seed both binaries' settings. The wrapper erases it from memory after use.
For non-interactive installs only; interactive mode hides the prompt.

.PARAMETER Unattended
Use defaults instead of prompting. Pair with -VncPort, -AudioPort, -Password.

.PARAMETER SkipElevation
INTERNAL. Production refuses this. Tests use it to skip the firewall elevation.

.PARAMETER FirewallOnly
INTERNAL. The wrapper re-launches itself with -FirewallOnly <ports> to open the firewall rules
under one short elevation, then drops back.

.PARAMETER Uninstall
Run the uninstall path instead of install.

.PARAMETER PauseAtEnd
Wait for Enter at the end (matches the legacy installer when run by double-click).
#>

[CmdletBinding()]
param(
    [int]$VncPort = 0,
    [int]$AudioPort = 0,
    [string]$Password = '',
    [switch]$Unattended,
    [switch]$SkipElevation,
    [switch]$FirewallOnly,
    [switch]$Uninstall,
    [switch]$PauseAtEnd
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# Constants matching the legacy installer conventions.
$Script:Product       = 'Quest VNC (Per User)'
$Script:ScriptDir      = Split-Path -Parent $MyInvocation.MyCommand.Path
$Script:ServerExe      = Join-Path $Script:ScriptDir 'QuestVncServer.exe'
$Script:AudioExe       = Join-Path $Script:ScriptDir 'QuestVncAudio.exe'
$Script:FwGroup        = 'Quest VNC'
$Script:FwNameServer   = 'Quest VNC (Server)'
$Script:FwNameAudio    = 'Quest VNC (Audio)'
$Script:DefaultVnc     = 5900
$Script:DefaultAudio   = 5910

function Write-Ok   ([string]$Text) { Write-Host '[+] ' -ForegroundColor Green -NoNewline; Write-Host $Text }
function Write-Warn ([string]$Text) { Write-Host '[!] ' -ForegroundColor Yellow -NoNewline; Write-Host $Text }
function Write-Err  ([string]$Text) { Write-Host '[X] ' -ForegroundColor Red   -NoNewline; Write-Host $Text }

function Test-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $p  = New-Object Security.Principal.WindowsPrincipal($id)
    return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Test-PortBusy ([int]$Port) {
    if ($Port -lt 1 -or $Port -gt 65535) { return $false }
    try {
        $c = New-Object Net.Sockets.TcpClient
        $iar = $c.BeginConnect('127.0.0.1', $Port, $null, $null)
        if (-not $iar.AsyncWaitHandle.WaitOne(200)) { $c.Close(); return $false }
        $c.EndConnect($iar); $c.Close(); return $true
    } catch { return $false }
}

function Get-FirstFreePort ([int[]]$Candidates) {
    foreach ($p in $Candidates) { if (-not (Test-PortBusy $p)) { return $p } }
    return $null
}

function Remove-FirewallRuleByName ([string]$DisplayName) {
    Get-NetFirewallRule -DisplayName $DisplayName -ErrorAction SilentlyContinue | Remove-NetFirewallRule -ErrorAction SilentlyContinue
}

function Remove-AllFirewallRules {
    Remove-FirewallRuleByName $Script:FwNameServer
    Remove-FirewallRuleByName $Script:FwNameAudio
}

function Open-FirewallRules ([int]$VncPort, [int]$AudioPort) {
    if ($VncPort -gt 0 -and $AudioPort -gt 0) {
        Remove-AllFirewallRules
        New-NetFirewallRule -DisplayName $Script:FwNameServer -Direction Inbound -Action Allow `
            -Protocol TCP -LocalPort $VncPort -Profile Private -Group $Script:FwGroup | Out-Null
        New-NetFirewallRule -DisplayName $Script:FwNameAudio  -Direction Inbound -Action Allow `
            -Protocol TCP -LocalPort $AudioPort -Profile Private -Group $Script:FwGroup | Out-Null
    } else {
        Remove-AllFirewallRules
    }
}

function Start-PrivilegedFirewall ([int]$VncPort, [int]$AudioPort) {
    if (Test-IsAdmin) { Open-FirewallRules $VncPort $AudioPort; return }
    $args = @(
        '-NoProfile','-ExecutionPolicy','Bypass',
        '-File',"`"$PSCommandPath`"",
        '-FirewallOnly',
        '-VncPort', $VncPort,
        '-AudioPort', $AudioPort
    )
    try {
        Start-Process -FilePath 'powershell.exe' -ArgumentList $args -Verb RunAs -Wait -ErrorAction Stop | Out-Null
    } catch {
        Write-Warn "Couldn't elevate. Open inbound TCP $VncPort and $AudioPort manually in Windows Firewall (Private profile), then re-run this installer."
    }
}

if ($FirewallOnly) {
    if (-not (Test-IsAdmin)) { Write-Err 'FirewallOnly must be invoked elevated.'; exit 1 }
    Open-FirewallRules $VncPort $AudioPort
    Write-Ok "Firewall rules opened (Group '$Script:FwGroup', Private profile)."
    exit 0
}

function Read-Port ([string]$What, [int]$Default, [int[]]$Fallbacks) {
    Write-Host ''
    Write-Host "$What port (default $Default, enter to accept)"
    if ($Fallbacks) { Write-Host "  Free ports tried in order: $($Fallbacks -join ', ')" }
    while ($true) {
        $raw = (Read-Host '> ').Trim()
        if ($raw -eq '') { return $Default }
        if ($raw -match '^\d+$' -and 1 -le [int]$raw -and [int]$raw -le 65535) {
            $p = [int]$raw
            if ($p -eq $Default -or -not (Test-PortBusy $p)) { return $p }
            if ($Fallbacks -and ($alt = Get-FirstFreePort $Fallbacks)) { Write-Host "  Port $p is busy; trying $alt"; return $alt }
            Write-Warn "  Port $p looks busy. Choose another."
            continue
        }
        Write-Warn "  Enter a number between 1 and 65535."
    }
}

function Read-Password {
    Write-Host ''
    Write-Host 'Choose the password the Quest VNC app will use (first 8 chars count). Empty = no password.'
    if (-not [Console]::IsInputRedirected) {
        while ($true) {
            $secure = Read-Host 'Password> ' -AsSecureString
            $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
            $plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
            [Runtime.InteropServices.Marshal]::ZeroFreeCoTaskMemUnicode($bstr)
            if ($plain.Length -eq 0) {
                $ans = Read-Host 'No password means anyone on your network can see this PC and listen to its audio. Continue? [y/N]'
                if ($ans -match '^[yY]') { return '' }
                continue
            }
            if ($plain.Length -gt 8) { Write-Host '  Note: only the first 8 characters count for the VNC password.' }
            $confirm = Read-Host 'Same password again> ' -AsSecureString
            $bstr2 = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($confirm)
            $plain2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr2)
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr2)
            if ($plain -eq $plain2) { return $plain }
            Write-Warn '  The two passwords differ, try again.'
        }
    } else {
        Write-Host '(non-interactive mode: password from -Password)'
        return $Password
    }
}

function Test-LegacyInstall {
    $reg  = 'HKLM:\SOFTWARE\Quest VNC'
    $svc  = 'HKLM:\SYSTEM\CurrentControlSet\Services\tvnserver'
    $path = Join-Path $env:ProgramFiles 'Quest VNC'
    $taskPath = '\Quest VNC\'
    $found = @()
    if (Test-Path $reg)  { $found += "registry at $reg" }
    if (Test-Path $svc)  { $found += 'tvnserver service' }
    if (Test-Path $path) { $found += "install folder at $path" }
    # `schtasks /Query /TN '\Quest VNC\*'` exits 1 even when matching tasks exist (no wildcard
    # support). Use the PowerShell cmdlet, which accepts `-TaskPath` globs.
    try {
        $t = @(Get-ScheduledTask -TaskPath $taskPath -ErrorAction Stop)
        if ($t.Count -gt 0) { $found += "scheduled task under $taskPath ($($t.Count) task(s))" }
    } catch [Microsoft.PowerShell.Cmdlets.GetScheduledTaskCommand.DataNotFoundException] {
        # No tasks under that path; this is a real "none" — not a true error.
    } catch {
        Write-Warn "Could not enumerate scheduled tasks under '$taskPath': $_"
    }
    return $found
}

function Remove-LegacyInstall {
    $legacyCmd = Join-Path (Join-Path $env:ProgramFiles 'Quest VNC') 'Uninstall Quest VNC.cmd'
    if (Test-Path $legacyCmd) {
        & $legacyCmd
    } else {
        $legacyPs1 = Join-Path $ScriptDir '..\windows\install.ps1'
        if (Test-Path $legacyPs1) {
            & powershell -NoProfile -ExecutionPolicy Bypass -File $legacyPs1 -Uninstall
        }
    }
}

function Set-ServerSetting ([string]$Line, [string]$Path) {
    # Replace (or append) a flag line in a settings file, preserving comments and other lines.
    # `$Line` is the full line to write (e.g. '--port 5900'). Any existing line that starts with
    # the same first word is replaced with `$Line`.
    if (-not (Test-Path $Path)) { New-Item -ItemType File -Force -Path $Path | Out-Null }
    $lines = @(Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)
    if ($null -eq $lines -or $lines.Count -eq 0) { $lines = @() }
    $flag = ($Line -split '\s+', 2)[0]
    $found = $false
    $next = foreach ($l in $lines) {
        if ($null -eq $l) { continue }
        $trim = $l.TrimStart()
        if ($trim -match "^$([regex]::Escape($flag))(?:\s|$)") {
            $found = $true
            $Line
        } else { $l }
    }
    if (-not $found) { $next = @($next) + @($Line) }
    $tmp = "$Path.new"
    Set-Content -LiteralPath $tmp -Value ($next -join "`r`n") -Encoding UTF8 -NoNewline
    Move-Item -LiteralPath $tmp -Destination $Path -Force
    Apply-OwnerOnlyAcl $Path
}

# Owner-only ACL: clear inherited DACL, grant FullControl to the current user only.
# Re-applied after every settings-file rewrite (Move-Item preserves file content but
# inherits the parent directory's ACL; on a freshly-installed per-user app, that
# inherited ACL already includes SYSTEM and Administrators in addition to the user).
function Apply-OwnerOnlyAcl ([string]$Path) {
    try {
        $sec = New-Object System.Security.AccessControl.FileSecurity
        $sec.SetAccessRuleProtection($true, $false)
        $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
        $sec.SetOwner([System.Security.Principal.SecurityIdentifier]($me))
        $sec.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule(
            $me, [System.Security.AccessControl.FileSystemRights]::FullControl,
            [System.Security.AccessControl.AccessControlType]::Allow)))
        [System.IO.FileInfo]::new($Path).SetAccessControl($sec)
    } catch {
        Write-Warn "Could not apply owner-only ACL to '$Path': $_"
    }
}

# Convenience wrappers for the two settings files we touch. Caller passes the full
# `--flag value` string (no `<new>` placeholders).
function Set-ServerConfLine    ([string]$Line) {
    Set-ServerSetting $Line (Join-Path $env:APPDATA 'QuestVncServer\server.conf')
}
function Set-AudioConfLine     ([string]$Line) {
    Set-ServerSetting $Line (Join-Path $env:APPDATA 'QuestVncAudio\settings.conf')
}

function Set-AudioRunValue ([int]$Port) {
    $exe = Join-Path $env:LOCALAPPDATA 'Programs\QuestVncAudio\QuestVncAudio.exe'
    $cmd = "`"$exe`" --background --use-server-settings --port $Port"
    $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    Set-ItemProperty -LiteralPath $key -Name 'QuestVncAudio' -Value $cmd
}

function Install-Both ([int]$VncPort, [int]$AudioPort, [string]$Password) {
    # Use a temp file for the password rather than passing it on the command line. Handles passwords
    # containing spaces, quotes, or any other shell-special chars without quoting headaches.
    $pwFile = $null
    try {
        $srvArgs = @('--install')
        if ($VncPort)  { $srvArgs += @('--port', "$VncPort") }
        if ($Password) {
            $pwFile = [IO.Path]::GetTempFileName()
            [System.IO.File]::WriteAllText($pwFile, $Password, [System.Text.UTF8Encoding]::new($false))
            $srvArgs += @('--password-file', $pwFile)
        }
        Write-Host ''
        Write-Host 'Installing Quest VNC Server (per user)...'
        $p = Start-Process -FilePath $Script:ServerExe -ArgumentList $srvArgs -Wait -PassThru -NoNewWindow
        if ($p.ExitCode -ne 0) { Write-Err "Server install failed (exit $($p.ExitCode))."; return $false }

        Write-Host ''
        Write-Host 'Installing Quest VNC Audio Sender (per user)...'
        $audArgs = @('--install', '--port', "$AudioPort")
        if ($pwFile) { $audArgs += @('--password-file', $pwFile) }
        $p = Start-Process -FilePath $Script:AudioExe -ArgumentList $audArgs -Wait -PassThru -NoNewWindow
        if ($p.ExitCode -ne 0) { Write-Err "Audio install failed (exit $($p.ExitCode))."; return $false }
    } finally {
        if ($pwFile -and (Test-Path $pwFile)) {
            Remove-Item -LiteralPath $pwFile -Force -ErrorAction SilentlyContinue
        }
    }
    return $true
}
function Main {
    if (-not $Unattended -and -not $SkipElevation) {
        $legacy = Test-LegacyInstall
        if ($legacy) {
            Write-Warn "Detected legacy Quest VNC install: $($legacy -join '; ')."
            $ans = Read-Host 'Uninstall it? (your per-user install happens either way) [y/N]'
            if ($ans -match '^[yY]') { Remove-LegacyInstall }
        }
    }

    if ($VncPort -eq 0 -and -not $Unattended)   { $VncPort   = Read-Port 'VNC'   $Script:DefaultVnc   @(5900,5901,5902,5903) }
    if ($AudioPort -eq 0 -and -not $Unattended) { $AudioPort = Read-Port 'Audio' $Script:DefaultAudio @(5910,5911,5912,5913) }
    if ([string]::IsNullOrEmpty($Password) -and -not $Unattended -and -not [Console]::IsInputRedirected) {
        $Password = Read-Password
    }
    if ($VncPort -eq 0)   { $VncPort   = $Script:DefaultVnc }
    if ($AudioPort -eq 0) { $AudioPort = $Script:DefaultAudio }

    # If the user is already installed (any binary), reconfigure instead of fresh-install.
    $serverExe  = Join-Path $env:LOCALAPPDATA 'Programs\QuestVncServer\QuestVncServer.exe'
    $audioExe   = Join-Path $env:LOCALAPPDATA 'Programs\QuestVncAudio\QuestVncAudio.exe'
    $reconfig = (Test-Path $serverExe) -or (Test-Path $audioExe)
    if ($reconfig) {
        if (Enter-Reconfigure $VncPort $AudioPort $Password) {
            Write-Ok 'Reconfigured.'
            if ($PauseAtEnd) { Read-Host 'Press Enter to close' }
            exit 0
        }
    }

    if (-not $SkipElevation) {
        Start-PrivilegedFirewall $VncPort $AudioPort
    } else {
        Open-FirewallRules $VncPort $AudioPort
    }

    $ok = Install-Both $VncPort $AudioPort $Password
    if (-not $ok) { if ($PauseAtEnd) { Read-Host 'Press Enter to close' }; exit 1 }

    Write-Host ''
    Write-Ok 'Quest VNC is installed for the current user.'
    Write-Host ''
    Write-Host 'In the Quest VNC app, connect to one of:'
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -ne '127.0.0.1' } |
        ForEach-Object { Write-Host "  $($_.IPAddress)  port $VncPort" }
    Write-Host ''
    Write-Host '  Log files:'
    Write-Host "    %LOCALAPPDATA%\Programs\QuestVncServer\server.log"
    Write-Host "    %LOCALAPPDATA%\QuestVncAudio\audio.log"
    Write-Host ''
    Write-Host '  To uninstall: Settings > Apps > Installed apps, then remove'
    Write-Host '  "Quest VNC Server" and "Quest VNC Audio Sender".'
    Write-Host ''
    if ($PauseAtEnd) { Read-Host 'Press Enter to close' }
}
function Uninstall-Both {
    Write-Host 'Uninstalling Quest VNC Server (per user)...'
    $p = Start-Process -FilePath $Script:ServerExe -ArgumentList '--uninstall' -Wait -PassThru -NoNewWindow
    if ($p.ExitCode -ne 0) { Write-Err "Server uninstall failed (exit $($p.ExitCode))" }
    Write-Host ''
    Write-Host 'Uninstalling Quest VNC Audio Sender (per user)...'
    $p = Start-Process -FilePath $Script:AudioExe -ArgumentList '--uninstall' -Wait -PassThru -NoNewWindow
    if ($p.ExitCode -ne 0) { Write-Err "Audio uninstall failed (exit $($p.ExitCode))" }
}

if ($Uninstall) {
    Uninstall-Both
    # Clear firewall rules under a short elevation; Open-FirewallRules(0 0) removes all.
    if (Test-IsAdmin) {
        Open-FirewallRules 0 0
    } else {
        try {
            Start-Process -FilePath 'powershell.exe' -ArgumentList @(
                '-NoProfile','-ExecutionPolicy','Bypass',
                '-File',"`"$PSCommandPath`"",
                '-FirewallOnly',
                '-VncPort','0','-AudioPort','0'
            ) -Verb RunAs -Wait -ErrorAction Stop | Out-Null
        } catch { Write-Warn 'Could not remove firewall rules; open them manually.' }
    }
    if ($PauseAtEnd) { Read-Host 'Press Enter to close' }
    exit 0
}
function Restart-ServiceHidden ([string]$ExePath, [string[]]$Args) {
    $running = Get-Process -Name ([IO.Path]::GetFileNameWithoutExtension($ExePath)) -ErrorAction SilentlyContinue
    if ($running) {
        foreach ($p in $running) { try { $p.Kill(); $p.WaitForExit(5000) } catch { } }
    }
    Start-Process -FilePath $ExePath -ArgumentList $Args -WindowStyle Hidden
}

function Enter-Reconfigure ([int]$VncPort, [int]$AudioPort, [string]$Password) {
    $serverExeInstalled = Join-Path $env:LOCALAPPDATA 'Programs\QuestVncServer\QuestVncServer.exe'
    $audioExeInstalled  = Join-Path $env:LOCALAPPDATA 'Programs\QuestVncAudio\QuestVncAudio.exe'
    $serverInstalled = Test-Path $serverExeInstalled
    $audioInstalled  = Test-Path $audioExeInstalled

    if (-not $serverInstalled -and -not $audioInstalled) { return $false }

    # Build args lists once. If a new password was supplied, write it to a temp file (avoids
    # quoting headaches on the restart command line and matches how Install-Both does it).
    $pwFile = $null
    if ($Password) {
        $pwFile = [IO.Path]::GetTempFileName()
        [System.IO.File]::WriteAllText($pwFile, $Password, [System.Text.UTF8Encoding]::new($false))
    }
    try {
        if ($serverInstalled -and $VncPort) {
            Set-ServerConfLine "--port $VncPort"
            if ($Password) { Set-ServerConfLine "--password $Password" }
            $srvArgs = @('--background','--port',"$VncPort")
            if ($pwFile) { $srvArgs += @('--password-file', $pwFile) }
            Restart-ServiceHidden $serverExeInstalled $srvArgs | Out-Null
        }
        if ($audioInstalled -and $AudioPort) {
            Set-AudioRunValue $AudioPort | Out-Null
            $audArgs = @('--background','--use-server-settings','--port',"$AudioPort")
            if ($pwFile) { $audArgs += @('--password-file', $pwFile) }
            Restart-ServiceHidden $audioExeInstalled $audArgs | Out-Null
        }
    } finally {
        if ($pwFile -and (Test-Path $pwFile)) {
            Remove-Item -LiteralPath $pwFile -Force -ErrorAction SilentlyContinue
        }
    }
    if (-not $SkipElevation) {
        # Firewall only needs updating when a port changed; Open-FirewallRules(0 0) just clears.
        # For now, when reconfiguring we only update rules if the requested ports differ from what's
        # already open. To keep things simple, we don't loop-resolve — the user can re-run with
        # -SkipElevation in scripts that want to skip the firewall step.
        Start-PrivilegedFirewall $VncPort $AudioPort
    }
    return $true
}

if (-not $FirewallOnly -and -not $Uninstall) {
    if (-not (Test-Path $Script:ServerExe)) { Write-Err "Not next to QuestVncServer.exe. Extract the zip and run this from there."; exit 1 }
    if (-not (Test-Path $Script:AudioExe))  { Write-Err "Not next to QuestVncAudio.exe. Extract the zip and run this from there."; exit 1 }
    Main
}
