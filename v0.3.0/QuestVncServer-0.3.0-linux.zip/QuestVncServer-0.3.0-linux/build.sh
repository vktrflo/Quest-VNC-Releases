#!/bin/sh
# Builds questvnc-server. libjpeg-turbo and zlib are linked statically when their .a files exist,
# so the binary only needs the X11 libraries (libX11, libXext, libXtst, libXfixes, libXdamage) at run time.
set -e
cd "$(dirname "$0")"
CC=${CC:-gcc}
# QVNC_VERSION overrides the release number, OUT the output file and EXTRA_CFLAGS adds compiler flags
# (the tests use these for a "newer" build and for an AddressSanitizer build).
VERSION=${QVNC_VERSION:-$(cat VERSION 2>/dev/null || cat ../VERSION 2>/dev/null || echo dev)}
OUT=${OUT:-questvnc-server}
LIBDIR=$($CC -print-multiarch 2>/dev/null || true)
find_static() {
    for d in /usr/lib/$LIBDIR /usr/lib64 /usr/lib /usr/local/lib; do
        [ -f "$d/$1" ] && { echo "$d/$1"; return; }
    done
}
TJ=$(find_static libturbojpeg.a); Z=$(find_static libz.a)
[ -n "$TJ" ] || TJ=-lturbojpeg
[ -n "$Z" ] || Z=-lz
$CC -std=gnu11 -O2 $EXTRA_CFLAGS -DQVNC_VERSION="\"$VERSION\"" -Wall -Wextra -Wno-unused-parameter -Wno-missing-field-initializers -pthread \
    -o "$OUT" src/main.c src/capture.c src/input.c src/clipboard.c src/audio.c src/encode.c src/des.c src/resize.c src/tight_policy.c src/copyrect.c src/update.c \
    $TJ $Z -lX11 -lXext -lXtst -lXfixes -lXdamage -ldl -lm
[ -n "$EXTRA_CFLAGS" ] || strip "$OUT" 2>/dev/null || true
case $OUT in /*) ;; *) OUT="$(pwd)/$OUT" ;; esac
echo "Built $OUT $VERSION"
