# Quest VNC Server for Linux

One program that shares your Linux desktop over VNC and also sends the PC's sound over the same
connection to the Quest VNC headset app. Normal VNC viewers (TigerVNC, RealVNC, TightVNC, noVNC)
work too; they just don't get sound.

It works with X11 desktop sessions. Wayland sessions are not supported for screen capture: if you
use GNOME or KDE on Wayland, log out and pick an "Xorg" session (for example "GNOME on Xorg" or
"Plasma (X11)") on the login screen.

## Install (recommended)

Unzip the download, open a terminal in the unzipped folder and run:

```
./install.sh
```

No root password is needed: everything goes into your own home folder. The installer

- copies the server to `~/.local/bin/questvnc-server`,
- asks for a password for viewers and saves it in the settings file
  `~/.config/questvnc/server.conf` (only you can read it),
- makes the server start by itself every time you sign in to your desktop,
- and starts it right away.

Then add this PC in the headset app with the address shown in the server's log (port 5900).
The installed server writes its messages to `~/.local/state/questvnc/server.log`; look there for the
PC's address, for viewers connecting and for updates.

Running `./install.sh` again (for example from a newer download) replaces the program and restarts
it, and keeps your settings file.

### Uninstall

```
./install.sh --uninstall
```

This stops the server, removes the program, the log and the sign-in entry, and asks whether to
delete the settings file too.

## Settings file

The installed server reads its options from `~/.config/questvnc/server.conf` (or
`$XDG_CONFIG_HOME/questvnc/server.conf` if you have set that variable). Write one option per line,
exactly like on the command line; lines starting with `#` are ignored:

```
# Quest VNC Server settings
--password mysecret
--fps 60
--no-audio
```

Changes apply the next time the server starts (sign out and in again, or run `./install.sh` again).
Options typed on the command line win over the file. A line the server doesn't understand is
reported in the log and skipped. Use `--config FILE` to read a different file.

## Updates

The installed server keeps itself up to date. A minute after it starts, and then every 12 hours, it
asks the Quest VNC release page whether there is a newer version (using `curl` or `wget`, one of
which nearly every Linux has). When there is, it downloads it, checks that the file is exactly the
published one (size and SHA-256 checksum, anything else is refused), and waits until no viewer is
connected, so nobody's session drops. Then it swaps in the new version and restarts itself with
the same settings. The log shows each step:

```
Update 0.3.0 available
Downloaded update 0.3.0
Installing update 0.3.0 now (no viewers connected)
Updated to 0.3.0
```

To turn updates off, add `--no-update` to the settings file. To see whether a new version exists
without installing anything, run `~/.local/bin/questvnc-server --check-update`.

## Portable mode (run without installing)

You can also run the server straight from the unzipped folder, as before:

```
./questvnc-server --password YOURPASS
```

A copy started like this never changes itself: when a new version is out it only says
"Update x.y.z is available" once in its output. It reads the settings file too, if there is one.

## Options

These work on the command line and in the settings file:

```
--port 5900            listen port (TCP, all interfaces)
--password SECRET      VNC password (only the first 8 characters count, per the VNC spec)
--fps 30               capture rate cap (1-60)
--monitor N            which monitor to share: 0 = primary (default), 1, 2, ... = monitor number
                       (the numbers are printed on start when there is more than one monitor)
--view-only            ignore keyboard and mouse from viewers
--no-audio             don't capture or offer sound
--test-tone            send a 440 Hz beep every second instead of the PC's sound (for setup checks)
--no-resize            don't let viewers change the screen resolution
--no-update            never check for or install updates
--update-url URL       where to look for updates (normally not needed)
--background           write messages to ~/.local/state/questvnc/server.log instead of the
                       terminal (the sign-in entry uses this)
```

Only on the command line:

```
--config FILE          read options from FILE instead of ~/.config/questvnc/server.conf
--check-update         check once for a new version, print the result and exit
                       (exit status 0 = up to date, 10 = update available, 1 = check failed)
--version              print the version and exit
```

Only one copy runs per port: if a Quest VNC Server is already running on that port, a second one
says so and exits.

You can also put the password in the `QUESTVNC_PASSWORD` environment variable instead of on the
command line. Without a password anyone on your network can see and control the PC, so always set one.

Sound is recorded from your default output with `parec` (package `pulseaudio-utils`), which works on
both PulseAudio and PipeWire desktops. If `parec` is missing, `pw-record` (PipeWire) is used instead.
If neither works, the VNC server still runs without sound.

### Resolution switching

The headset app can ask the PC to switch to another resolution (for example 1920x1080 or 2560x1440)
so the picture fits the headset better. The server picks one of your monitor's own display modes
with XRandR: the exact size if the monitor offers it, otherwise the closest smaller mode with the
same shape, otherwise the largest mode that fits. The change is temporary. Your original resolution
comes back when the viewer that asked for the change disconnects, and when the server stops
(Ctrl+C or a normal shutdown). If the server is killed hard or crashes, set the resolution back in
your display settings. Use `--no-resize` to keep viewers from changing the resolution
(`--view-only` also blocks it). Other VNC viewers that support resizing (TigerVNC, noVNC) can use
this too.

### Firewall

If your distribution has a firewall enabled, allow the VNC port:

```
sudo ufw allow 5900/tcp                                              # Ubuntu, Debian with ufw
sudo firewall-cmd --add-port=5900/tcp --permanent && sudo firewall-cmd --reload   # Fedora
```

## Build from source

Debian / Ubuntu:

```
sudo apt install gcc libx11-dev libxext-dev libxtst-dev libxfixes-dev libturbojpeg0-dev zlib1g-dev
./build.sh
```

Fedora:

```
sudo dnf install gcc libX11-devel libXext-devel libXtst-devel libXfixes-devel turbojpeg-devel zlib-devel
./build.sh
```

`build.sh` links libjpeg-turbo and zlib statically when their `.a` files are installed (on Ubuntu
they come with the packages above; on Fedora install `zlib-static` and `libjpeg-turbo-static` for a
static link, otherwise they are linked dynamically). The finished program only needs the X11
libraries at run time (libX11, libXext, libXtst, libXfixes), which every X11 desktop has.
For multi-monitor selection it also uses libXrandr when present (loaded at run time).

The prebuilt binary needs glibc 2.34 or newer (Ubuntu 22.04, Debian 12, Fedora 35, RHEL 9 or later).
On older systems, build from source.

## What is supported

- RFB 3.3, 3.7 and 3.8; VNC password authentication; several viewers at once.
- Encodings: Tight (solid fill, JPEG, zlib) and Raw, any true-colour pixel format.
- The mouse pointer is drawn into the picture.
- Keyboard: viewers' characters are typed as meant, even when your keyboard layout lacks them
  (a spare key code is mapped for the moment, like x11vnc and TigerVNC do).
- Clipboard in both directions (Latin-1, as the VNC protocol defines).
- Screen size changes are sent to viewers that support it, and viewers can change the
  resolution (ExtendedDesktopSize), see above.
- Sound over the VNC connection (QEMU audio extension), any sample rate from 8000 to 96000 Hz.

## Tests

`tests/run-tests.sh` runs the protocol, picture, sound, input and clipboard tests against an
invisible X server (Xvfb) with PulseAudio, then the settings file, install.sh and update tests
(with a local web server playing the release page and temporary home folders). See the comments
at the top of the script for the tools it needs and for the display numbers and ports it uses.
For a memory-checking build: `OUT=/tmp/qv-asan EXTRA_CFLAGS="-fsanitize=address -g" ./build.sh`, then
`BIN=/tmp/qv-asan ASAN_OPTIONS=detect_leaks=0 tests/run-tests.sh`.
