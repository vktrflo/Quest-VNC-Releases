#!/bin/sh
# Installs Quest VNC Server for the current user (no root needed):
#   ./install.sh               copy to ~/.local/bin, write the settings file, start at every sign-in
#   ./install.sh --uninstall   stop it and remove it again (asks before deleting the settings file)
# Without a terminal the password comes from QUESTVNC_PASSWORD (or the first line of input).
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
CONFIG_HOME=${XDG_CONFIG_HOME:-$HOME/.config}
STATE_HOME=${XDG_STATE_HOME:-$HOME/.local/state}
BIN_DIR="$HOME/.local/bin"
DEST="$BIN_DIR/questvnc-server"
CONF="$CONFIG_HOME/questvnc/server.conf"
AUTOSTART="$CONFIG_HOME/autostart/questvnc-server.desktop"
LOG="$STATE_HOME/questvnc/server.log"

# Stops every copy of the server running from the installed path (only this user's processes).
stop_running() {
    found=
    for d in /proc/[0-9]*; do
        exe=$(readlink "$d/exe" 2>/dev/null) || continue
        if [ "$exe" = "$DEST" ] || [ "$exe" = "$DEST (deleted)" ]; then
            kill "${d#/proc/}" 2>/dev/null && found="$found ${d#/proc/}"
        fi
    done
    for p in $found; do
        i=0
        while kill -0 "$p" 2>/dev/null && [ $i -lt 50 ]; do sleep 0.1; i=$((i + 1)); done
    done
    [ -z "$found" ] || echo "Stopped the running Quest VNC Server."
}

ask() {   # ask "question" -> reply in $REPLY ("" at end of input)
    printf '%s' "$1"
    REPLY=
    read -r REPLY || true
}

ask_password() {
    if [ -n "$QUESTVNC_PASSWORD" ]; then PW=$QUESTVNC_PASSWORD; return; fi
    while :; do
        if [ -t 0 ]; then
            printf 'Choose a password for viewers (only the first 8 characters count): '
            stty -echo; read -r PW || PW=; stty echo; echo
            [ -n "$PW" ] || { echo "Without a password anyone on your network can see and control this PC."; ask "Continue without a password? [y/N] "; case $REPLY in [yY]*) return ;; esac; continue; }
            printf 'Type it again: '
            stty -echo; read -r PW2 || PW2=; stty echo; echo
            [ "$PW" = "$PW2" ] && return
            echo "The two passwords differ, try again."
        else
            read -r PW || PW=
            return
        fi
    done
}

# Desktop entry Exec= quoting: wrap in double quotes, escape \ " ` $
desktop_quote() {
    printf '"%s"' "$(printf '%s' "$1" | sed -e 's/[\\"`$]/\\&/g')"
}

if [ "$1" = "--uninstall" ]; then
    stop_running
    rm -f "$DEST" "$BIN_DIR"/.questvnc-server.new.* "$AUTOSTART"
    rm -rf "$STATE_HOME/questvnc"
    echo "Removed $DEST and the autostart entry."
    if [ -f "$CONF" ]; then
        ask "Delete the settings file $CONF (it holds your password)? [y/N] "
        case $REPLY in
            [yY]*) rm -f "$CONF"; rmdir "$(dirname "$CONF")" 2>/dev/null || true; echo "Deleted the settings file." ;;
            *) echo "Kept the settings file $CONF." ;;
        esac
    fi
    echo "Quest VNC Server is uninstalled."
    exit 0
fi
if [ -n "$1" ]; then echo "Usage: $0 [--uninstall]"; exit 2; fi

SRC="$HERE/questvnc-server"
[ -x "$SRC" ] || { echo "$SRC is missing. Run ./build.sh first."; exit 1; }

stop_running
mkdir -p "$BIN_DIR"
# Copy next to the target and rename, so a running or busy old binary is replaced atomically.
cp "$SRC" "$DEST.tmp.$$"
chmod 755 "$DEST.tmp.$$"
mv -f "$DEST.tmp.$$" "$DEST"
echo "Installed $("$DEST" --version) to $DEST"

if [ -f "$CONF" ]; then
    echo "Keeping your settings file $CONF"
else
    ask_password
    mkdir -p "$(dirname "$CONF")"
    (
        umask 077
        {
            echo "# Quest VNC Server settings: one option per line, written like on the command line."
            echo "# Lines starting with # are ignored. Changes apply the next time the server starts."
            if [ -n "$PW" ]; then echo "--password $PW"; else echo "# --password YOURPASS"; fi
            echo "# --port 5900"
            echo "# --fps 30"
            echo "# --monitor 0"
            echo "# --no-audio"
            echo "# --view-only"
            echo "# --no-resize"
            echo "# --no-update"
        } > "$CONF"
    )
    chmod 600 "$CONF"
    echo "Wrote the settings file $CONF (only you can read it)"
fi

mkdir -p "$(dirname "$AUTOSTART")"
cat > "$AUTOSTART" <<EOF
[Desktop Entry]
Type=Application
Name=Quest VNC Server
Comment=Shares this desktop and its sound with the Quest VNC headset app
Exec=$(desktop_quote "$DEST") --background
Terminal=false
NoDisplay=true
X-GNOME-Autostart-enabled=true
EOF
echo "Added $AUTOSTART, so it starts every time you sign in."

if [ -n "$DISPLAY" ]; then
    nohup "$DEST" --background >/dev/null 2>&1 &
    echo "Started it now. Messages go to $LOG"
else
    echo "No desktop session here (DISPLAY is not set): it starts at your next sign-in."
fi
case ":$PATH:" in *":$BIN_DIR:"*) ;; *) echo "(You can run it by hand as $DEST.)" ;; esac
