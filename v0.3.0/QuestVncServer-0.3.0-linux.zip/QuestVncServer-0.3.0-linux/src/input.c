/* Keyboard and mouse injection with XTest. */
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/extensions/XTest.h>

static Display *dpy;
static pthread_mutex_t in_mu = PTHREAD_MUTEX_INITIALIZER;
static int ok;
static int kmin, kmax, kper;
static KeySym *kmap;
static int spare[16], nspare, spare_next;

static void refresh_map(void)
{
    if (kmap) XFree(kmap);
    kmap = XGetKeyboardMapping(dpy, (KeyCode)kmin, kmax - kmin + 1, &kper);
}

int input_init(void)
{
    dpy = XOpenDisplay(NULL);
    if (!dpy) return -1;
    int ev, er, maj, min;
    if (!XTestQueryExtension(dpy, &ev, &er, &maj, &min)) {
        fprintf(stderr, "The X server has no XTEST extension: keyboard and mouse control will not work.\n");
        return -1;
    }
    XTestGrabControl(dpy, True);
    XDisplayKeycodes(dpy, &kmin, &kmax);
    refresh_map();
    /* Keycodes with no symbols, used to type characters the current layout lacks. */
    for (int kc = kmax; kc >= kmin && nspare < 16; kc--) {
        int empty = 1;
        for (int l = 0; l < kper; l++) if (kmap[(kc - kmin) * kper + l] != NoSymbol) { empty = 0; break; }
        if (empty) spare[nspare++] = kc;
    }
    ok = 1;
    return 0;
}

void input_shutdown(void)
{
    if (!ok) return;
    pthread_mutex_lock(&in_mu);
    KeySym none[2] = {NoSymbol, NoSymbol};
    for (int i = 0; i < nspare; i++) XChangeKeyboardMapping(dpy, spare[i], 2, none, 1);
    XSync(dpy, False);
    pthread_mutex_unlock(&in_mu);
}

void input_pointer(client_t *c, int mask, int x, int y)
{
    if (!ok || g_opt.view_only) return;
    pthread_mutex_lock(&in_mu);
    if (x >= fb_w) x = fb_w - 1;
    if (y >= fb_h) y = fb_h - 1;
    XTestFakeMotionEvent(dpy, -1, mon_x + x, mon_y + y, CurrentTime);
    int old = c->buttons;
    static const int btn[3] = {1, 2, 3};
    for (int b = 0; b < 3; b++) {
        int was = (old >> b) & 1, now = (mask >> b) & 1;
        if (was != now) XTestFakeButtonEvent(dpy, btn[b], now, CurrentTime);
    }
    /* Wheel bits: one notch per press. */
    static const int wheel[4] = {4, 5, 6, 7};
    for (int b = 3; b < 7; b++) {
        if (((mask >> b) & 1) && !((old >> b) & 1)) {
            XTestFakeButtonEvent(dpy, wheel[b - 3], True, CurrentTime);
            XTestFakeButtonEvent(dpy, wheel[b - 3], False, CurrentTime);
        }
    }
    c->buttons = mask;
    XFlush(dpy);
    pthread_mutex_unlock(&in_mu);
}

static int keycode_down(const char *keys, int kc) { return kc > 0 && (keys[kc / 8] >> (kc % 8)) & 1; }

/* Finds keysym ks on the keymap: sets *level 0 (plain) or 1 (shifted). Returns keycode or 0. */
static int find_key(KeySym ks, int *level)
{
    for (int l = 0; l < 2 && l < kper; l++)
        for (int kc = kmin; kc <= kmax; kc++)
            if (kmap[(kc - kmin) * kper + l] == ks) { *level = l; return kc; }
    return 0;
}

static int map_spare(KeySym ks)
{
    if (!nspare) return 0;
    int kc = spare[spare_next];
    spare_next = (spare_next + 1) % nspare;
    KeySym syms[2] = {ks, ks};
    XChangeKeyboardMapping(dpy, kc, 2, syms, 1);
    XSync(dpy, False);
    refresh_map();
    usleep(10000);   /* give applications a moment to see the new mapping, as xdotool does */
    return kc;
}

static void press_with_shift(int kc, int need_shift)
{
    char keys[32];
    XQueryKeymap(dpy, keys);
    int sl = XKeysymToKeycode(dpy, XK_Shift_L), sr = XKeysymToKeycode(dpy, XK_Shift_R);
    int ldown = keycode_down(keys, sl), rdown = keycode_down(keys, sr);
    int shifted = ldown || rdown;
    if (need_shift && !shifted && sl) {
        XTestFakeKeyEvent(dpy, sl, True, CurrentTime);
        XTestFakeKeyEvent(dpy, kc, True, CurrentTime);
        XTestFakeKeyEvent(dpy, sl, False, CurrentTime);
    } else if (!need_shift && shifted) {
        if (ldown) XTestFakeKeyEvent(dpy, sl, False, CurrentTime);
        if (rdown) XTestFakeKeyEvent(dpy, sr, False, CurrentTime);
        XTestFakeKeyEvent(dpy, kc, True, CurrentTime);
        if (ldown) XTestFakeKeyEvent(dpy, sl, True, CurrentTime);
        if (rdown) XTestFakeKeyEvent(dpy, sr, True, CurrentTime);
    } else {
        XTestFakeKeyEvent(dpy, kc, True, CurrentTime);
    }
}

void input_key(client_t *c, int down, uint32_t ks)
{
    if (!ok || g_opt.view_only) return;
    pthread_mutex_lock(&in_mu);
    if (ks >= 0x01000000 && ks < 0x01000100) ks -= 0x01000000;   /* Unicode Latin-1 = legacy keysym */
    if (down) {
        int printable = ks < 0xfe00 || ks >= 0x01000000;
        int kc = 0, level = 0;
        refresh_map();
        if (printable) {
            kc = find_key(ks, &level);
            if (!kc) { kc = map_spare(ks); level = 0; printable = kc ? 2 : 1; }
        } else {
            kc = XKeysymToKeycode(dpy, ks);
            if (!kc) kc = map_spare(ks);
        }
        if (kc) {
            /* Only adjust Shift for characters whose shifted form differs. */
            if (printable == 1 && kper >= 2 && kmap[(kc - kmin) * kper] != kmap[(kc - kmin) * kper + 1])
                press_with_shift(kc, level);
            else
                XTestFakeKeyEvent(dpy, kc, True, CurrentTime);
            int i;
            for (i = 0; i < c->nkeys; i++) if (c->keys[i].ks == ks) break;
            if (i == c->nkeys && c->nkeys < MAX_KEYS) { c->keys[c->nkeys].ks = ks; c->keys[c->nkeys].kc = kc; c->nkeys++; }
        }
    } else {
        for (int i = 0; i < c->nkeys; i++) {
            if (c->keys[i].ks != ks) continue;
            XTestFakeKeyEvent(dpy, c->keys[i].kc, False, CurrentTime);
            c->keys[i] = c->keys[--c->nkeys];
            break;
        }
    }
    XFlush(dpy);
    pthread_mutex_unlock(&in_mu);
}

void input_release_all(client_t *c)
{
    if (!ok) return;
    pthread_mutex_lock(&in_mu);
    for (int i = 0; i < c->nkeys; i++) XTestFakeKeyEvent(dpy, c->keys[i].kc, False, CurrentTime);
    c->nkeys = 0;
    for (int b = 0; b < 3; b++)
        if ((c->buttons >> b) & 1) XTestFakeButtonEvent(dpy, b + 1, False, CurrentTime);
    c->buttons = 0;
    XFlush(dpy);
    pthread_mutex_unlock(&in_mu);
}
