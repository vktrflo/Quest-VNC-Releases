/* CopyRect detection: finds screen areas that are a shifted copy of the previous frame (a window
 * being dragged, a scrolled page or terminal) so viewers can be told "copy these pixels from there"
 * instead of receiving them again.
 *
 * Portable logic (no X11): works on two 0x00RRGGBB frames of the same size. Every copy reported is
 * verified pixel for pixel: new[dst] == old[dst - (dx, dy)]. Ported to C#/Swift as-is.
 *
 *   cr_verify_move()   a known candidate shift (from window-move events): keeps the row bands of the
 *                      window where the shift holds exactly.
 *   cr_detect_scroll() no candidate: votes on a vertical shift by matching row hashes inside the
 *                      changed area, then verifies it the same way.
 *   cr_residual()      the changed tiles still to send after the copies (tiles fully covered by a
 *                      copy need nothing more).
 */
#ifndef QVNC_COPYRECT_H
#define QVNC_COPYRECT_H

#include <stdint.h>

typedef struct { int x, y, w, h; int dx, dy; } copy_op;   /* dst rect; source is (x - dx, y - dy) */

#define CR_MAX_OPS 8
#define CR_MIN_BAND_ROWS 16        /* shorter matching bands are not worth a CopyRect */
#define CR_SCROLL_MIN_TILES 6      /* only look for scrolling when at least this many tiles changed */
#define CR_SCROLL_MIN_VOTES 24     /* rows that must agree on a scroll distance */

/* Bands of rect (x, y, w, h) (new frame coordinates) where new == old shifted by (dx, dy).
   Appends up to max - *n ops to out. tile = tile size of the changed map. */
void cr_verify_move(const uint32_t *nf, const uint32_t *of, int w, int h,
                    int rx, int ry, int rw, int rh, int dx, int dy, copy_op *out, int *n, int max);

/* Looks for vertical scrolling inside the bounding box of the changed tiles. */
void cr_detect_scroll(const uint32_t *nf, const uint32_t *of, int w, int h,
                      const uint8_t *changed, int tx, int ty, int tile, copy_op *out, int *n, int max);

/* residual = changed minus tiles completely inside one of the ops. */
void cr_residual(const copy_op *ops, int n, const uint8_t *changed, uint8_t *residual, int tx, int ty, int tile, int w, int h);

/* Orders ops so that applying them one after another never reads pixels an earlier op wrote. */
void cr_order(copy_op *ops, int n);

#endif
