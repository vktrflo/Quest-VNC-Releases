/* Rectangle encoders: Raw (any true-colour format) and Tight (fill, palette, JPEG, full colour).
   Which Tight method each area gets is decided in tight_policy.c. */
#include "common.h"
#include <stdlib.h>
#include <string.h>
#include <turbojpeg.h>
#include "tight_policy.h"


void buf_reserve(buf_t *b, size_t extra)
{
    if (b->len + extra <= b->cap) return;
    size_t n = b->cap ? b->cap : 4096;
    while (n < b->len + extra) n *= 2;
    b->p = realloc(b->p, n);
    b->cap = n;
}
void buf_put(buf_t *b, const void *d, size_t n) { buf_reserve(b, n); memcpy(b->p + b->len, d, n); b->len += n; }
void buf_u8(buf_t *b, uint8_t v) { buf_put(b, &v, 1); }
void buf_u16(buf_t *b, uint16_t v) { uint8_t t[2] = {(uint8_t)(v >> 8), (uint8_t)v}; buf_put(b, t, 2); }
void buf_u32(buf_t *b, uint32_t v) { uint8_t t[4] = {(uint8_t)(v >> 24), (uint8_t)(v >> 16), (uint8_t)(v >> 8), (uint8_t)v}; buf_put(b, t, 4); }
void buf_free(buf_t *b) { free(b->p); b->p = NULL; b->len = b->cap = 0; }

static int tight_ok(const client_t *c)
{
    return c->e_tight && c->epf.bpp == 32 && c->epf.rmax == 255 && c->epf.gmax == 255 && c->epf.bmax == 255;
}

/* Copies the rect out of the framebuffer (black where it lies outside it). */
static uint32_t *grab_rect(client_t *c, rect_t r)
{
    uint32_t *p = malloc((size_t)r.w * r.h * 4 + 4);
    pthread_rwlock_rdlock(&fb_lock);
    if (fb_gen > c->grab_gen) c->grab_gen = fb_gen;
    for (int j = 0; j < r.h; j++) {
        int y = r.y + j;
        uint32_t *d = p + (size_t)j * r.w;
        if (y >= fb_h || r.x >= fb_w) { memset(d, 0, (size_t)r.w * 4); continue; }
        int n = r.x + r.w > fb_w ? fb_w - r.x : r.w;
        memcpy(d, fb_pixels + (size_t)y * fb_w + r.x, (size_t)n * 4);
        if (n < r.w) memset(d + n, 0, (size_t)(r.w - n) * 4);
    }
    pthread_rwlock_unlock(&fb_lock);
    return p;
}

static void put_compact_len(buf_t *o, size_t len)
{
    buf_u8(o, (uint8_t)((len & 0x7f) | (len > 0x7f ? 0x80 : 0)));
    if (len > 0x7f) {
        buf_u8(o, (uint8_t)(((len >> 7) & 0x7f) | (len > 0x3fff ? 0x80 : 0)));
        if (len > 0x3fff) buf_u8(o, (uint8_t)(len >> 14));
    }
}

static void encode_raw(client_t *c, buf_t *o, const uint32_t *px, int n)
{
    const pixfmt_t *f = &c->epf;
    if (f->bpp == 32 && !f->big_endian && f->rshift == 16 && f->gshift == 8 && f->bshift == 0 &&
        f->rmax == 255 && f->gmax == 255 && f->bmax == 255) {
        buf_put(o, px, (size_t)n * 4);
        return;
    }
    int bytes = f->bpp / 8;
    buf_reserve(o, (size_t)n * bytes);
    uint8_t *d = o->p + o->len;
    for (int i = 0; i < n; i++) {
        uint32_t p = px[i];
        uint32_t r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        uint32_t v = ((r * f->rmax + 127) / 255) << f->rshift | ((g * f->gmax + 127) / 255) << f->gshift |
                     ((b * f->bmax + 127) / 255) << f->bshift;
        for (int k = 0; k < bytes; k++)
            d[k] = (uint8_t)(f->big_endian ? v >> (8 * (bytes - 1 - k)) : v >> (8 * k));
        d += bytes;
    }
    o->len += (size_t)n * bytes;
}


/* ---------------------------------------------------------------- Tight */

/* Deflates data on one of the client's Tight zlib streams (sync flush) and appends
   compact length + data; data shorter than 12 bytes goes uncompressed, as Tight requires. */
static void put_zlib(client_t *c, buf_t *o, int stream, const uint8_t *data, size_t len)
{
    if (len < 12) { buf_put(o, data, len); return; }
    z_stream *zs = &c->zs[stream];
    int level = tp_zlib_level(stream, c->e_compress);
    buf_t *z = &c->zbuf;
    z->len = 0;
    buf_reserve(z, len + len / 100 + 1024);
    if (!c->zs_init[stream]) {
        memset(zs, 0, sizeof *zs);
        deflateInit2(zs, level, Z_DEFLATED, 15, 9, Z_DEFAULT_STRATEGY);
        c->zs_init[stream] = 1; c->zs_level[stream] = level;
    } else if (c->zs_level[stream] != level) {
        /* Any bytes deflateParams emits belong to this rect's stream data. */
        zs->next_in = (Bytef *)data; zs->avail_in = 0;
        zs->next_out = z->p; zs->avail_out = (uInt)z->cap;
        deflateParams(zs, level, Z_DEFAULT_STRATEGY);
        z->len = z->cap - zs->avail_out;
        c->zs_level[stream] = level;
    }
    zs->next_in = (Bytef *)data; zs->avail_in = (uInt)len;
    do {
        buf_reserve(z, 65536);
        zs->next_out = z->p + z->len; zs->avail_out = (uInt)(z->cap - z->len);
        deflate(zs, Z_SYNC_FLUSH);
        z->len = z->cap - zs->avail_out;
    } while (zs->avail_out == 0);
    put_compact_len(o, z->len);
    buf_put(o, z->p, z->len);
}

static void rect_header(buf_t *o, int x, int y, int w, int h, int32_t enc)
{
    buf_u16(o, (uint16_t)x); buf_u16(o, (uint16_t)y); buf_u16(o, (uint16_t)w); buf_u16(o, (uint16_t)h);
    buf_u32(o, (uint32_t)enc);
}

/* A run of merged blocks in one band. */
typedef struct {
    int x, w;
    tp_kind kind;
    int npal;
    uint32_t pal[TP_MAX_PALETTE + 1];
    uint32_t hslot[1024]; uint8_t hused[1024];   /* palette lookup: colour -> slot */
    uint8_t hidx[1024];
} run_t;

static int run_find(const run_t *r, uint32_t c)
{
    uint32_t h = (c * 2654435761u) >> 22;
    while (r->hused[h]) { if (r->hslot[h] == c) return r->hidx[h]; h = (h + 1) & 1023; }
    return -1;
}

static int run_add(run_t *r, uint32_t c)
{
    uint32_t h = (c * 2654435761u) >> 22;
    while (r->hused[h]) { if (r->hslot[h] == c) return r->hidx[h]; h = (h + 1) & 1023; }
    r->hused[h] = 1; r->hslot[h] = c; r->hidx[h] = (uint8_t)r->npal;
    r->pal[r->npal] = c;
    return r->npal++;
}

static int is_palette_kind(tp_kind k) { return k == TP_SOLID || k == TP_MONO || k == TP_INDEXED; }

static void run_start(run_t *r, int x, int w, tp_kind kind, const uint32_t *pal, int npal)
{
    r->x = x; r->w = w; r->kind = kind; r->npal = 0;
    memset(r->hused, 0, sizeof r->hused);
    if (is_palette_kind(kind)) for (int i = 0; i < npal; i++) run_add(r, pal[i]);
}

/* Tries to extend the run with the next block; returns 0 if they don't belong together. */
static int run_merge(run_t *r, int w, tp_kind kind, const uint32_t *pal, int npal, int limit)
{
    if (r->w + w > TP_MAX_WIDTH) return 0;
    if (is_palette_kind(r->kind) && is_palette_kind(kind)) {
        int extra = 0;
        for (int i = 0; i < npal; i++) if (run_find(r, pal[i]) < 0) extra++;
        if (r->npal + extra > limit) return 0;
        /* Keep big single-colour areas as fills, and keep fills from swallowing detail. */
        if ((r->kind == TP_SOLID) != (kind == TP_SOLID) || (r->kind == TP_SOLID && extra)) return 0;
        for (int i = 0; i < npal; i++) run_add(r, pal[i]);
        r->w += w;
        r->kind = r->npal == 1 ? TP_SOLID : r->npal == 2 ? TP_MONO : TP_INDEXED;
        return 1;
    }
    if (r->kind == kind && (kind == TP_JPEG || kind == TP_FULLCOLOR)) { r->w += w; return 1; }
    return 0;
}

static void emit_run(client_t *c, buf_t *o, const run_t *r, const uint32_t *px, int stride, int y, int h)
{
    rect_header(o, r->x, y, r->w, h, 7);
    int w = r->w;
    switch (r->kind) {
    case TP_SOLID: {
        uint32_t p = r->pal[0];
        uint8_t t[4] = {0x80, (uint8_t)(p >> 16), (uint8_t)(p >> 8), (uint8_t)p};
        buf_put(o, t, 4);
        return;
    }
    case TP_MONO:
    case TP_INDEXED: {
        int stream = r->kind == TP_MONO ? TP_STREAM_MONO : TP_STREAM_INDEXED;
        buf_u8(o, (uint8_t)(0x40 | (stream << 4)));   /* explicit filter */
        buf_u8(o, 1);                                 /* palette filter */
        buf_u8(o, (uint8_t)(r->npal - 1));
        for (int i = 0; i < r->npal; i++) {
            uint8_t t[3] = {(uint8_t)(r->pal[i] >> 16), (uint8_t)(r->pal[i] >> 8), (uint8_t)r->pal[i]};
            buf_put(o, t, 3);
        }
        buf_t *d = &c->tmp; d->len = 0;
        if (r->kind == TP_MONO) {
            int rb = (w + 7) / 8;
            buf_reserve(d, (size_t)rb * h);
            memset(d->p, 0, (size_t)rb * h);
            uint32_t fg = r->pal[1];
            for (int j = 0; j < h; j++) {
                const uint32_t *row = px + (size_t)j * stride;
                uint8_t *dr = d->p + (size_t)j * rb;
                int i = 0;
                for (; i + 8 <= w; i += 8) {
                    unsigned v = 0;
                    for (int k = 0; k < 8; k++) v = (v << 1) | ((row[i + k] & 0xffffff) == fg);
                    dr[i >> 3] = (uint8_t)v;
                }
                for (; i < w; i++)
                    if ((row[i] & 0xffffff) == fg) dr[i >> 3] |= (uint8_t)(0x80 >> (i & 7));
            }
            d->len = (size_t)rb * h;
        } else {
            buf_reserve(d, (size_t)w * h);
            uint8_t *dp = d->p;
            for (int j = 0; j < h; j++) {
                const uint32_t *row = px + (size_t)j * stride;
                uint32_t last = 0xffffffffu; int li = 0;
                for (int i = 0; i < w; i++) {
                    uint32_t p = row[i] & 0xffffff;
                    if (p != last) { last = p; li = run_find(r, p); if (li < 0) li = 0; }
                    *dp++ = (uint8_t)li;
                }
            }
            d->len = (size_t)w * h;
        }
        put_zlib(c, o, stream, d->p, d->len);
        return;
    }
    case TP_JPEG: {
        if (!c->tj) c->tj = tjInitCompress();
        int q = tp_jpeg_quality(c->e_quality);
        int samp = q >= 90 ? TJSAMP_444 : (q >= 75 ? TJSAMP_422 : TJSAMP_420);
        unsigned char *jbuf = NULL; unsigned long jlen = 0;
        if (c->tj && tjCompress2(c->tj, (const unsigned char *)px, w, stride * 4, h, TJPF_BGRX, &jbuf, &jlen, samp, q, TJFLAG_FASTDCT) == 0) {
            buf_u8(o, 0x90);
            put_compact_len(o, jlen);
            buf_put(o, jbuf, jlen);
            tjFree(jbuf);
            return;
        }
        if (jbuf) tjFree(jbuf);
    }
    /* fall through: lossless on a JPEG error */
    /* FALLTHROUGH */
    case TP_FULLCOLOR: {
        buf_u8(o, (uint8_t)(TP_STREAM_FULLCOLOR << 4));   /* no filter byte = copy filter */
        buf_t *d = &c->tmp; d->len = 0;
        buf_reserve(d, (size_t)w * h * 3);
        uint8_t *dp = d->p;
        for (int j = 0; j < h; j++) {
            const uint32_t *row = px + (size_t)j * stride;
            for (int i = 0; i < w; i++) { uint32_t p = row[i]; *dp++ = (uint8_t)(p >> 16); *dp++ = (uint8_t)(p >> 8); *dp++ = (uint8_t)p; }
        }
        put_zlib(c, o, TP_STREAM_FULLCOLOR, d->p, (size_t)w * h * 3);
        return;
    }
    }
}

static int encode_tight_area(client_t *c, buf_t *o, rect_t r, const uint32_t *px)
{
    int jpeg = c->e_quality >= 0;
    int limit = tp_palette_limit(jpeg);
    uint32_t pal[TP_MAX_PALETTE + 1];
    static __thread run_t run_tls;
    run_t *run = &run_tls;
    int count = 0;
    for (int y = r.y; y < r.y + r.h;) {
        int bh = TP_BLOCK - (y % TP_BLOCK);
        if (y + bh > r.y + r.h) bh = r.y + r.h - y;
        const uint32_t *band = px + (size_t)(y - r.y) * r.w;
        int have = 0;
        for (int x = r.x; x < r.x + r.w;) {
            int bw = TP_BLOCK - (x % TP_BLOCK);
            if (x + bw > r.x + r.w) bw = r.x + r.w - x;
            const uint32_t *blk = band + (x - r.x);
            int n = tp_count_colors(blk, bw, bh, r.w, limit, pal);
            tp_kind k = tp_choose(n, jpeg);
            if (!have) { run_start(run, x, bw, k, pal, n); have = 1; }
            else if (!run_merge(run, bw, k, pal, n, limit)) {
                emit_run(c, o, run, band + (run->x - r.x), r.w, y, bh); count++;
                run_start(run, x, bw, k, pal, n);
            }
            x += bw;
        }
        if (have) { emit_run(c, o, run, band + (run->x - r.x), r.w, y, bh); count++; }
        y += bh;
    }
    return count;
}

int encode_area(client_t *c, buf_t *out, rect_t r)
{
    uint32_t *px = grab_rect(c, r);
    int n;
    if (tight_ok(c)) {
        n = encode_tight_area(c, out, r, px);
    } else {
        rect_header(out, r.x, r.y, r.w, r.h, 0);
        encode_raw(c, out, px, r.w * r.h);
        n = 1;
    }
    free(px);
    return n;
}

void encode_free(client_t *c)
{
    for (int i = 0; i < 4; i++) if (c->zs_init[i]) deflateEnd(&c->zs[i]);
    if (c->tj) tjDestroy(c->tj);
    memset(c->zs_init, 0, sizeof c->zs_init);
    c->tj = NULL;
    buf_free(&c->zbuf); buf_free(&c->tmp);
}
