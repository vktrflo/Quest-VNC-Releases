/* In-place updates for installed copies (see "Install, autostart and in-place updates" in SPEC.md).
   A background thread reads the release feed (latest.json) with curl or wget, downloads a newer
   binary next to the installed one and checks its size and SHA-256. The main loop then waits until
   no viewer is connected, renames the new binary over the installed one and execv()s it with the
   original arguments. Portable copies (not running from ~/.local/bin) only log that an update exists. */
#define _GNU_SOURCE
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <time.h>
#include <dirent.h>
#include <limits.h>
#include <pwd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <sys/syscall.h>

#define DEFAULT_FEED "https://raw.githubusercontent.com/vktrflo/Quest-VNC-Releases/main/latest.json"
#define PLATFORM_KEY "linux-x86_64"
#define FEED_TIMEOUT 30
#define PAYLOAD_TIMEOUT 600
#define FEED_MAX (256 * 1024)
#define PAYLOAD_MAX (256L * 1024 * 1024)

/* ------------------------------------------------------------------ SHA-256 (FIPS 180-4) */

typedef struct { uint32_t h[8]; uint64_t len; uint8_t buf[64]; size_t n; } sha256_t;

static const uint32_t K256[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};

#define ROR(x, n) ((x) >> (n) | (x) << (32 - (n)))

static void sha256_block(sha256_t *s, const uint8_t *p)
{
    uint32_t w[64], a, b, c, d, e, f, g, h;
    for (int i = 0; i < 16; i++) w[i] = (uint32_t)p[4 * i] << 24 | (uint32_t)p[4 * i + 1] << 16 | (uint32_t)p[4 * i + 2] << 8 | p[4 * i + 3];
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = ROR(w[i - 15], 7) ^ ROR(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = ROR(w[i - 2], 17) ^ ROR(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    a = s->h[0]; b = s->h[1]; c = s->h[2]; d = s->h[3]; e = s->h[4]; f = s->h[5]; g = s->h[6]; h = s->h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t t1 = h + (ROR(e, 6) ^ ROR(e, 11) ^ ROR(e, 25)) + ((e & f) ^ (~e & g)) + K256[i] + w[i];
        uint32_t t2 = (ROR(a, 2) ^ ROR(a, 13) ^ ROR(a, 22)) + ((a & b) ^ (a & c) ^ (b & c));
        h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    s->h[0] += a; s->h[1] += b; s->h[2] += c; s->h[3] += d; s->h[4] += e; s->h[5] += f; s->h[6] += g; s->h[7] += h;
}

static void sha256_init(sha256_t *s)
{
    static const uint32_t iv[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    memcpy(s->h, iv, sizeof iv); s->len = 0; s->n = 0;
}

static void sha256_update(sha256_t *s, const uint8_t *p, size_t n)
{
    s->len += n;
    while (n) {
        size_t k = 64 - s->n < n ? 64 - s->n : n;
        memcpy(s->buf + s->n, p, k); s->n += k; p += k; n -= k;
        if (s->n == 64) { sha256_block(s, s->buf); s->n = 0; }
    }
}

static void sha256_hex(sha256_t *s, char out[65])
{
    uint64_t bits = s->len * 8;
    uint8_t pad = 0x80, z = 0, l[8];
    sha256_update(s, &pad, 1);
    while (s->n != 56) sha256_update(s, &z, 1);
    for (int i = 0; i < 8; i++) l[i] = (uint8_t)(bits >> (56 - 8 * i));
    sha256_update(s, l, 8);
    for (int i = 0; i < 8; i++) snprintf(out + 8 * i, 9, "%08x", s->h[i]);
}

/* ------------------------------------------------------------------ minimal JSON reader */

static const char *ws(const char *p) { while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++; return p; }

/* Returns the position just after the JSON value at p, or NULL if it is malformed. */
static const char *skip_value(const char *p, int depth)
{
    p = ws(p);
    if (depth > 32) return NULL;
    if (*p == '"') {
        for (p++; *p && *p != '"'; p++) if (*p == '\\' && !*++p) return NULL;
        return *p == '"' ? p + 1 : NULL;
    }
    if (*p == '{' || *p == '[') {
        char close = *p == '{' ? '}' : ']';
        p = ws(p + 1);
        if (*p == close) return p + 1;
        for (;;) {
            if (close == '}') {
                if (*p != '"' || !(p = skip_value(p, depth + 1))) return NULL;
                p = ws(p);
                if (*p++ != ':') return NULL;
            }
            if (!(p = skip_value(p, depth + 1))) return NULL;
            p = ws(p);
            if (*p == ',') { p = ws(p + 1); continue; }
            return *p == close ? p + 1 : NULL;
        }
    }
    const char *s = p;
    while (*p && !strchr(",}] \t\r\n", *p)) p++;
    return p > s ? p : NULL;
}

/* Copies a JSON string at p into out (simple escapes decoded, \u escapes become '?'). */
static int json_string(const char *p, char *out, size_t cap)
{
    p = ws(p);
    if (*p++ != '"') return -1;
    size_t n = 0;
    for (; *p && *p != '"'; p++) {
        char ch = *p;
        if (ch == '\\') {
            ch = *++p;
            if (ch == 'n' || ch == 'r' || ch == 't') ch = ' ';
            else if (ch == 'u') { for (int i = 0; i < 4 && p[1]; i++) p++; ch = '?'; }
            else if (!ch) return -1;
        }
        if (n + 1 < cap) out[n++] = ch;
    }
    out[n] = 0;
    return *p == '"' ? 0 : -1;
}

/* Finds key in the object starting at obj (which must point at '{'); returns its value or NULL. */
static const char *json_get(const char *obj, const char *key)
{
    if (!obj || *(obj = ws(obj)) != '{') return NULL;
    const char *p = ws(obj + 1);
    char k[64];
    while (*p == '"') {
        if (json_string(p, k, sizeof k) < 0 || !(p = skip_value(p, 0))) return NULL;
        p = ws(p);
        if (*p++ != ':') return NULL;
        p = ws(p);
        if (!strcmp(k, key)) return p;
        if (!(p = skip_value(p, 0))) return NULL;
        p = ws(p);
        if (*p == ',') p = ws(p + 1);
    }
    return NULL;
}

static long long json_number(const char *p)
{
    if (!p || *(p = ws(p)) < '0' || *p > '9') return -1;
    long long v = 0;
    for (; *p >= '0' && *p <= '9' && v < (1LL << 50); p++) v = v * 10 + (*p - '0');
    return v;
}

typedef struct { char version[32], notes[300], url[1024], sha256[65]; long long size; } release_t;

/* Parses latest.json; returns 0 when it has a version and a linux-x86_64 entry with url and sha256. */
static int parse_feed(const char *json, release_t *r)
{
    memset(r, 0, sizeof *r); r->size = -1;
    const char *root = ws(json);
    if (!skip_value(root, 0)) return -1;
    if (json_string(json_get(root, "version"), r->version, sizeof r->version) < 0) return -1;
    json_string(json_get(root, "notes"), r->notes, sizeof r->notes);
    const char *plat = json_get(json_get(root, "platforms"), PLATFORM_KEY);
    if (!plat) return -2;
    if (json_string(json_get(plat, "url"), r->url, sizeof r->url) < 0 || !r->url[0]) return -2;
    if (json_string(json_get(plat, "sha256"), r->sha256, sizeof r->sha256) < 0 || strlen(r->sha256) != 64) return -2;
    for (char *c = r->sha256; *c; c++) if (*c >= 'A' && *c <= 'F') *c = (char)(*c + 32);
    r->size = json_number(json_get(plat, "size"));
    return 0;
}

/* ------------------------------------------------------------------ versions */

static int parse_version(const char *s, int v[3])
{
    if (*s == 'v' || *s == 'V') s++;
    for (int i = 0; i < 3; i++) {
        if (*s < '0' || *s > '9') return -1;
        v[i] = 0;
        while (*s >= '0' && *s <= '9') { if (v[i] < 100000000) v[i] = v[i] * 10 + (*s - '0'); s++; }
        if (i < 2 && *s++ != '.') return -1;
    }
    return *s == 0 || *s == '-' || *s == '+' ? 0 : -1;
}

/* 1 if a is strictly newer than b, 0 if not, -1 if either isn't a dotted triple. */
static int version_newer(const char *a, const char *b)
{
    int x[3], y[3];
    if (parse_version(a, x) < 0 || parse_version(b, y) < 0) return -1;
    for (int i = 0; i < 3; i++) if (x[i] != y[i]) return x[i] > y[i];
    return 0;
}

/* ------------------------------------------------------------------ downloading with curl / wget */

static int have_prog(const char *name)
{
    const char *path = getenv("PATH");
    if (!path || !*path) path = "/usr/local/bin:/usr/bin:/bin";
    char buf[PATH_MAX];
    while (*path) {
        const char *e = strchr(path, ':');
        size_t n = e ? (size_t)(e - path) : strlen(path);
        if (n && n + strlen(name) + 2 < sizeof buf) {
            memcpy(buf, path, n); buf[n] = '/'; strcpy(buf + n + 1, name);
            if (access(buf, X_OK) == 0) return 1;
        }
        path += n; if (*path) path++;
    }
    return 0;
}

static void close_from(int lo)
{
#ifdef SYS_close_range
    if (syscall(SYS_close_range, (unsigned)lo, ~0U, 0) == 0) return;
#endif
    for (int fd = lo; fd < 4096; fd++) close(fd);
}

typedef int (*sink_fn)(void *ctx, const uint8_t *d, size_t n);   /* returns -1 to abort */

/* Downloads url, handing the bytes to sink. Returns 0 ok, -1 failed, -2 no curl or wget. */
static int fetch(const char *url, int timeout_s, sink_fn sink, void *ctx)
{
    char tmo[16]; snprintf(tmo, sizeof tmo, "%d", timeout_s);
    char *curl[] = {"curl", "-fsSL", "--max-time", tmo, "--url", (char *)url, NULL};
    char *wget[] = {"wget", "-qO-", "-T", tmo, "--", (char *)url, NULL};
    char **argv = have_prog("curl") ? curl : have_prog("wget") ? wget : NULL;
    if (!argv) return -2;
    int p[2];
    if (pipe2(p, O_CLOEXEC) < 0) return -1;
    pid_t pid = fork();
    if (pid < 0) { close(p[0]); close(p[1]); return -1; }
    if (pid == 0) {
        prctl(PR_SET_PDEATHSIG, SIGTERM);
        dup2(p[1], 1);
        int dn = open("/dev/null", O_RDWR);
        if (dn >= 0) { dup2(dn, 0); dup2(dn, 2); }
        close_from(3);
        execvp(argv[0], argv);
        _exit(127);
    }
    close(p[1]);
    struct timespec t0; clock_gettime(CLOCK_MONOTONIC, &t0);
    int rc = 0;
    uint8_t buf[65536];
    for (;;) {
        struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t);
        long left = (long)(timeout_s + 5 - (t.tv_sec - t0.tv_sec)) * 1000;
        if (left <= 0) { rc = -1; break; }
        struct pollfd pfd = {p[0], POLLIN, 0};
        int r = poll(&pfd, 1, (int)(left > 1000 ? 1000 : left));
        if (r < 0 && errno == EINTR) continue;
        if (r == 0) continue;
        ssize_t n = read(p[0], buf, sizeof buf);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) break;
        if (sink(ctx, buf, (size_t)n) < 0) { rc = -1; break; }
    }
    close(p[0]);
    if (rc < 0) kill(pid, SIGTERM);
    int st = 0;
    while (waitpid(pid, &st, 0) < 0 && errno == EINTR) { }
    if (rc == 0 && !(WIFEXITED(st) && WEXITSTATUS(st) == 0)) rc = -1;
    return rc;
}

typedef struct { char *p; size_t len; } mem_t;

static int mem_sink(void *ctx, const uint8_t *d, size_t n)
{
    mem_t *m = ctx;
    if (m->len + n > FEED_MAX) return -1;
    memcpy(m->p + m->len, d, n); m->len += n; m->p[m->len] = 0;
    return 0;
}

typedef struct { int fd; sha256_t sha; long long got, max; } file_sink_t;

static int file_sink(void *ctx, const uint8_t *d, size_t n)
{
    file_sink_t *f = ctx;
    f->got += (long long)n;
    if (f->got > f->max) return -1;
    sha256_update(&f->sha, d, n);
    while (n) {
        ssize_t w = write(f->fd, d, n);
        if (w < 0 && errno == EINTR) continue;
        if (w <= 0) return -1;
        d += w; n -= (size_t)w;
    }
    return 0;
}

static const char *feed_url(void)
{
    if (g_opt.update_url && *g_opt.update_url) return g_opt.update_url;
    const char *e = getenv("QUESTVNC_UPDATE_URL");
    return e && *e ? e : DEFAULT_FEED;
}

/* Returns 0 and fills r, -1 on a download or format error, -2 when there is no curl or wget. */
static int read_feed(release_t *r, char *why, size_t whylen)
{
    mem_t m = {malloc(FEED_MAX + 1), 0};
    if (!m.p) return -1;
    m.p[0] = 0;
    int rc = fetch(feed_url(), FEED_TIMEOUT, mem_sink, &m);
    if (rc == -2) snprintf(why, whylen, "neither curl nor wget is installed");
    else if (rc < 0) snprintf(why, whylen, "could not download %s", feed_url());
    else if ((rc = parse_feed(m.p, r)) == -2) snprintf(why, whylen, "the release feed has no %s download", PLATFORM_KEY);
    else if (rc < 0) snprintf(why, whylen, "the release feed is not valid");
    free(m.p);
    return rc == 0 ? 0 : rc == -2 && strstr(why, "curl") ? -2 : -1;
}

/* ------------------------------------------------------------------ install location */

static char inst_path[PATH_MAX + 32], inst_dir[PATH_MAX];
static int installed;

static void find_install_path(void)
{
    const char *home = getenv("HOME");
    if (!home || !*home) { struct passwd *pw = getpwuid(getuid()); home = pw ? pw->pw_dir : "/"; }
    snprintf(inst_dir, sizeof inst_dir, "%s/.local/bin", home);
    snprintf(inst_path, sizeof inst_path, "%s/questvnc-server", inst_dir);
    char self[PATH_MAX], target[PATH_MAX];
    installed = realpath("/proc/self/exe", self) && realpath(inst_path, target) && !strcmp(self, target);
}

int update_is_installed(void) { if (!inst_path[0]) find_install_path(); return installed; }

/* ------------------------------------------------------------------ --check-update */

int update_check_once(void)
{
    release_t r; char why[1200] = "";
    int rc = read_feed(&r, why, sizeof why);
    if (rc < 0) { fprintf(stderr, "Update check failed: %s.\n", why); return 1; }
    int newer = version_newer(r.version, QVNC_VERSION_STR);
    if (newer < 0) {
        fprintf(stderr, "Update check failed: cannot compare versions \"%s\" and \"%s\".\n", r.version, QVNC_VERSION_STR);
        return 1;
    }
    if (newer) {
        printf("Update %s available (this is %s)%s%s\n", r.version, QVNC_VERSION_STR, r.notes[0] ? ": " : "", r.notes);
        return 10;
    }
    printf("Up to date (%s; latest release %s)\n", QVNC_VERSION_STR, r.version);
    return 0;
}

/* ------------------------------------------------------------------ background checker */

static pthread_mutex_t upd_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t upd_cv = PTHREAD_COND_INITIALIZER;
static char ready_file[PATH_MAX + 32], ready_version[32];   /* downloaded and verified, waiting to install */
static int ready, waiting_logged;
static time_t next_try;
static char **saved_argv;
static int delay_first = 60, interval = 12 * 3600, retry = 30;

static int env_secs(const char *name, int def)
{
    const char *s = getenv(name);
    if (!s || *s < '0' || *s > '9') return def;
    int v = 0;
    for (; *s >= '0' && *s <= '9' && v < 100000000; s++) v = v * 10 + (*s - '0');
    return v;
}

/* Downloads and verifies one release into the install directory; returns 0 when ready. */
static int download(const release_t *r)
{
    char tmp[PATH_MAX + 32];
    snprintf(tmp, sizeof tmp, "%s/.questvnc-server.new.XXXXXX", inst_dir);
    int fd = mkostemp(tmp, O_CLOEXEC);
    if (fd < 0) { logmsg("Update %s: cannot write to %s (%s)", r->version, inst_dir, strerror(errno)); return -1; }
    file_sink_t f = {fd, {{0}}, 0, r->size >= 0 ? r->size : PAYLOAD_MAX};
    sha256_init(&f.sha);
    int rc = fetch(r->url, PAYLOAD_TIMEOUT, file_sink, &f);
    if (close(fd) < 0) rc = -1;
    char hex[65]; sha256_hex(&f.sha, hex);
    const char *bad = NULL;
    if (rc < 0) bad = f.got > f.max ? "the download is larger than the release feed says" : "the download failed";
    else if (r->size >= 0 && f.got != r->size) bad = "the download has the wrong size";
    else if (strcmp(hex, r->sha256)) bad = "the SHA-256 checksum does not match";
    if (bad) {
        logmsg("Update %s refused: %s; will try again at the next check", r->version, bad);
        unlink(tmp);
        return -1;
    }
    chmod(tmp, 0755);
    pthread_mutex_lock(&upd_mu);
    snprintf(ready_file, sizeof ready_file, "%s", tmp);
    snprintf(ready_version, sizeof ready_version, "%s", r->version);
    ready = 1; waiting_logged = 0; next_try = 0;
    pthread_mutex_unlock(&upd_mu);
    logmsg("Downloaded update %s", r->version);
    return 0;
}

static void *update_thread(void *arg)
{
    (void)arg;
    char told[32] = "";
    struct timespec until; clock_gettime(CLOCK_REALTIME, &until);
    until.tv_sec += delay_first;
    for (;;) {
        pthread_mutex_lock(&upd_mu);
        while (pthread_cond_timedwait(&upd_cv, &upd_mu, &until) != ETIMEDOUT) { }
        int busy = ready;
        pthread_mutex_unlock(&upd_mu);
        clock_gettime(CLOCK_REALTIME, &until);
        until.tv_sec += interval;
        if (busy) continue;   /* a downloaded update is waiting for the viewers to leave */

        release_t r; char why[1200];
        int rc = read_feed(&r, why, sizeof why);
        if (rc == -2) continue;   /* no curl or wget: skip quietly */
        if (rc < 0) { logmsg("Update check failed: %s", why); continue; }
        if (version_newer(r.version, QVNC_VERSION_STR) != 1) continue;
        if (!installed) {
            if (strcmp(told, r.version))
                logmsg("Update %s is available%s%s (this copy is not installed, so it does not update itself)",
                       r.version, r.notes[0] ? ": " : "", r.notes);
            snprintf(told, sizeof told, "%s", r.version);
            continue;
        }
        logmsg("Update %s available%s%s", r.version, r.notes[0] ? ": " : "", r.notes);
        download(&r);
    }
    return NULL;
}

void update_start(char **argv)
{
    saved_argv = argv;
    if (!inst_path[0]) find_install_path();
    delay_first = env_secs("QUESTVNC_UPDATE_DELAY", delay_first);   /* test hooks; defaults per SPEC */
    interval = env_secs("QUESTVNC_UPDATE_INTERVAL", interval);
    retry = env_secs("QUESTVNC_UPDATE_RETRY", retry);
    if (interval < 1) interval = 1;
    if (installed) {   /* leftovers of an interrupted download */
        DIR *d = opendir(inst_dir);
        struct dirent *e;
        while (d && (e = readdir(d)))
            if (!strncmp(e->d_name, ".questvnc-server.new.", 21)) {
                char p[PATH_MAX + 256]; snprintf(p, sizeof p, "%s/%s", inst_dir, e->d_name);
                struct stat st;
                if (stat(p, &st) == 0 && time(NULL) - st.st_mtime > 3600) unlink(p);
            }
        if (d) closedir(d);
    }
    pthread_t t;
    if (pthread_create(&t, NULL, update_thread, NULL) == 0) pthread_detach(t);
}

void update_startup_note(void)
{
    const char *from = getenv("QUESTVNC_UPDATED_FROM");
    if (from && *from) logmsg("Updated to %s (from %s)", QVNC_VERSION_STR, from);
    unsetenv("QUESTVNC_UPDATED_FROM");
}

/* Marks every inherited descriptor above stderr close-on-exec, so nothing leaks into the new copy. */
static void cloexec_all(void)
{
    DIR *d = opendir("/proc/self/fd");
    if (!d) { for (int fd = 3; fd < 4096; fd++) { int fl = fcntl(fd, F_GETFD); if (fl >= 0) fcntl(fd, F_SETFD, fl | FD_CLOEXEC); } return; }
    int dfd = dirfd(d);
    struct dirent *e;
    while ((e = readdir(d))) {
        int fd = 0;
        const char *s = e->d_name;
        if (*s < '0' || *s > '9') continue;
        for (; *s >= '0' && *s <= '9'; s++) fd = fd * 10 + (*s - '0');
        if (fd <= 2 || fd == dfd) continue;
        int fl = fcntl(fd, F_GETFD);
        if (fl >= 0) fcntl(fd, F_SETFD, fl | FD_CLOEXEC);
    }
    closedir(d);
}

/* Called by the main loop about twice a second. When an update is downloaded and no viewer is
   connected, it closes the listening socket, swaps the binary and execs it. If that fails, *lfd is
   reopened and the old copy keeps running. */
void update_main_tick(int *lfd)
{
    pthread_mutex_lock(&upd_mu);
    int due = ready && time(NULL) >= next_try;
    char file[PATH_MAX + 32], ver[32];
    snprintf(file, sizeof file, "%s", ready_file);
    snprintf(ver, sizeof ver, "%s", ready_version);
    pthread_mutex_unlock(&upd_mu);
    if (!due) return;

    pthread_mutex_lock(&clients_mu);
    if (nclients > 0) {
        int n = nclients;
        pthread_mutex_unlock(&clients_mu);
        pthread_mutex_lock(&upd_mu);
        next_try = time(NULL) + retry;
        int say = !waiting_logged; waiting_logged = 1;
        pthread_mutex_unlock(&upd_mu);
        if (say) logmsg("Update %s will be installed when no viewer is connected (%d connected)", ver, n);
        return;
    }
    /* clients_mu stays locked from here on, so no viewer can register while we swap */
    logmsg("Installing update %s now (no viewers connected)", ver);
    close(*lfd); *lfd = -1;
    if (rename(file, inst_path) < 0) {
        logmsg("Update %s failed: cannot replace %s (%s)", ver, inst_path, strerror(errno));
        unlink(file);
    } else {
        audio_stop();
        cloexec_all();
        setenv("QUESTVNC_UPDATED_FROM", QVNC_VERSION_STR, 1);
        fflush(stdout); fflush(stderr);
        execv(inst_path, saved_argv);
        logmsg("Update %s failed: cannot start %s (%s)", ver, inst_path, strerror(errno));
        unsetenv("QUESTVNC_UPDATED_FROM");
    }
    pthread_mutex_unlock(&clients_mu);
    pthread_mutex_lock(&upd_mu);
    ready = 0;
    pthread_mutex_unlock(&upd_mu);
    *lfd = listener_open(0);
    if (*lfd < 0) { logmsg("Cannot listen on port %d again, stopping", g_opt.port); exit(1); }
}
