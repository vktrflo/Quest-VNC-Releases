/* Quest VNC Server for Linux: shared declarations. */
#ifndef QVNC_COMMON_H
#define QVNC_COMMON_H

#include <stdint.h>
#include <stddef.h>
#include <pthread.h>
#include <zlib.h>
#include "copyrect.h"

#ifndef QVNC_VERSION
#define QVNC_VERSION "dev"   /* build.sh passes the release number from the VERSION file */
#endif
#define QVNC_VERSION_STR QVNC_VERSION

#define TILE 64
#define AUDIO_RATE 48000
#define AUDIO_CH 2

typedef struct { int x, y, w, h; } rect_t;

/* ---- options ---- */
typedef struct {
    int port;
    char password[9];   /* first 8 characters, NUL terminated */
    int has_password;
    int fps;
    int monitor;
    int view_only;
    int no_audio;
    int no_resize;
    int test_tone;
    int no_update;
    int background;
    int check_update;
    char *update_url;   /* NULL: QUESTVNC_UPDATE_URL or the default feed */
} options_t;
extern options_t g_opt;

/* ---- growable byte buffer ---- */
typedef struct { uint8_t *p; size_t len, cap; } buf_t;
void buf_reserve(buf_t *b, size_t extra);
void buf_put(buf_t *b, const void *d, size_t n);
void buf_u8(buf_t *b, uint8_t v);
void buf_u16(buf_t *b, uint16_t v);   /* big-endian */
void buf_u32(buf_t *b, uint32_t v);   /* big-endian */
void buf_free(buf_t *b);

/* ---- framebuffer (written by the capture thread) ---- */
extern pthread_rwlock_t fb_lock;
extern uint32_t *fb_pixels;   /* 0x00RRGGBB, fb_w * fb_h, row-major */
extern int fb_w, fb_h;
extern unsigned long fb_gen;  /* bumped on every framebuffer change (under fb_lock) */

/* ---- pixel format ---- */
typedef struct {
    int bpp, depth, big_endian, true_colour;
    int rmax, gmax, bmax, rshift, gshift, bshift;
} pixfmt_t;

/* ---- client ---- */
#define MAX_KEYS 64
typedef struct client {
    struct client *next;
    unsigned id;
    int fd;
    char addr[64];
    pthread_t reader, writer;
    pthread_mutex_t mu;
    pthread_cond_t cv;
    volatile int alive;

    pixfmt_t pf;
    int use_tight, quality, compress, has_desktopsize, wants_audio_enc, has_copyrect;
    /* snapshot used by the writer while it encodes one update */
    pixfmt_t epf;
    int e_tight, e_quality, e_compress;

    int cw, ch;                /* size the viewer knows */
    int req_pending;
    rect_t req;                /* union of requested areas */
    int force_set;
    rect_t force;              /* union of non-incremental areas */
    uint8_t *dirty;            /* per-tile dirty flags */
    int tiles_x, tiles_y;
    int need_desktopsize;
    copy_op copies[CR_MAX_OPS]; int ncopies;   /* accepted CopyRects not sent yet */
    int inflight;              /* the writer is encoding / sending an update */
    unsigned long last_grab_gen, grab_gen;     /* newest framebuffer generation sent */
    int send_ack;
    int xds;                   /* listed ExtendedDesktopSize (-308) */
    struct { int reason, status, w, h; } xq[8];   /* queued ExtendedDesktopSize rects */
    int nxq;

    /* audio */
    int audio_on, audio_begin, audio_end;
    int afmt, achan, arate;
    double rs_pos;
    int16_t rs_prev[2];
    buf_t aq;                  /* queued converted PCM */
    int aframe_bytes;

    /* clipboard to send */
    char *cut; size_t cutlen; int cut_pending;

    /* input state */
    int buttons;
    struct { uint32_t ks; int kc; } keys[MAX_KEYS];
    int nkeys;

    /* encoder state */
    z_stream zs[4]; int zs_init[4], zs_level[4];
    void *tj;
    buf_t zbuf, tmp;           /* encoder scratch */
} client_t;

/* client list (main.c) */
extern pthread_mutex_t clients_mu;
extern client_t *clients;
extern int nclients;
extern pthread_cond_t clients_cv;  /* signalled when a viewer connects */

/* main.c helpers */
void clients_frame(const uint8_t *changed, const uint8_t *residual, const copy_op *ops, int nops, int tx, int ty);
void clients_resized(int w, int h, unsigned requester);
void clients_xds_reply(unsigned requester, int status);
void clients_cut_text(const char *latin1, size_t len, client_t *except);
void clients_audio(const int16_t *pcm, int frames);              /* 48 kHz stereo */
void logmsg(const char *fmt, ...);
int listener_open(int first);  /* opens the listening socket; first = 1 at start-up (prints errors) */

/* capture.c */
int capture_init(void);        /* returns 0 on success */
void *capture_thread(void *);
extern int mon_x, mon_y;       /* top-left of the shared monitor on the X screen */
void capture_geometry_now(unsigned requester);   /* re-check the screen size at once */
void capture_wake(void);

/* resize.c */
int resize_init(void);
int resize_request(client_t *c, int w, int h, int *out_w, int *out_h);   /* returns RFB status 0-3 */
int resize_client_gone(client_t *c);   /* 1 if the original mode was restored */
void resize_restore_on_exit(void);

/* input.c */
int input_init(void);
void input_pointer(client_t *c, int mask, int x, int y);
void input_key(client_t *c, int down, uint32_t ks);
void input_release_all(client_t *c);
void input_shutdown(void);

/* clipboard.c */
int clipboard_init(void);
void clipboard_set_from_viewer(const char *latin1, size_t len);

/* audio.c */
extern int audio_ok;
extern const char *audio_source;
int audio_init(void);          /* starts capture or test tone; returns 1 if sound available */
void audio_stop(void);         /* stops the parec / pw-record child (before an update restarts us) */

/* update.c */
int update_check_once(void);   /* --check-update: prints the result, returns 0 / 10 / 1 */
int update_is_installed(void); /* running from ~/.local/bin/questvnc-server */
void update_start(char **argv);
void update_startup_note(void);/* logs "Updated to x.y.z" when an update restarted us */
void update_main_tick(int *lfd);

/* encode.c */
/* Appends the RFB rectangles (header + data) for update area r; returns how many it wrote. */
int encode_area(client_t *c, buf_t *out, rect_t r);
void encode_free(client_t *c);

/* des.c */
void des_encrypt_ecb(const uint8_t key[8], const uint8_t *in, uint8_t *out, size_t len);

#endif
