/* Tight encoder decisions; see tight_policy.h for the rules. */
#include "tight_policy.h"
#include <string.h>

int tp_palette_limit(int jpeg)
{
    return jpeg ? TP_PALETTE_MAX_JPEG : TP_PALETTE_MAX_LOSSLESS;
}

int tp_count_colors(const uint32_t *px, int w, int h, int stride, int limit, uint32_t *palette)
{
    /* Small open-addressing set; 1024 slots for up to 257 colours keeps it sparse. */
    uint32_t slot[1024];
    uint8_t used[1024];
    memset(used, 0, sizeof used);
    int n = 0;
    uint32_t last = 0xffffffffu, prev = 0xffffffffu;
    for (int y = 0; y < h; y++) {
        const uint32_t *row = px + (size_t)y * stride;
        for (int x = 0; x < w; x++) {
            uint32_t c = row[x] & 0xffffff;
            /* runs of one colour, and text switching between two colours, are the common cases */
            if (c == last) continue;
            if (c == prev) { prev = last; last = c; continue; }
            prev = last; last = c;
            uint32_t hsh = (c * 2654435761u) >> 22;
            for (;;) {
                if (!used[hsh]) {
                    used[hsh] = 1; slot[hsh] = c;
                    palette[n++] = c;
                    if (n > limit) return n;
                    break;
                }
                if (slot[hsh] == c) break;
                hsh = (hsh + 1) & 1023;
            }
        }
    }
    return n;
}

tp_kind tp_choose(int ncolors, int jpeg)
{
    if (ncolors <= 1) return TP_SOLID;
    if (ncolors == 2) return TP_MONO;
    if (ncolors <= tp_palette_limit(jpeg)) return TP_INDEXED;
    return jpeg ? TP_JPEG : TP_FULLCOLOR;
}

int tp_zlib_level(int stream, int compress_level)
{
    /* zlib level per viewer compression level 0-9. Measured on full-screen text scrolling at
       1920x1080 (bench/): palette data at zlib 1 costs half the CPU of zlib 7 for about 20% more
       bytes, and full-colour data is big, so both use low levels unless the viewer asks for 7-9. */
    static const int palette[10] = {0, 1, 1, 1, 1, 2, 2, 3, 6, 9};
    static const int fullcolor[10] = {0, 1, 1, 1, 1, 1, 1, 2, 4, 9};
    if (compress_level < 0) compress_level = 0;
    if (compress_level > 9) compress_level = 9;
    return stream == TP_STREAM_FULLCOLOR ? fullcolor[compress_level] : palette[compress_level];
}

int tp_jpeg_quality(int level)
{
    static const int q[10] = {15, 25, 35, 45, 55, 65, 75, 85, 90, 95};
    if (level < 0) level = 0;
    if (level > 9) level = 9;
    return q[level];
}
