/* CopyRect detection; see copyrect.h. */
#include "copyrect.h"
#include <stdlib.h>
#include <string.h>

static int row_equal(const uint32_t *a, const uint32_t *b, int n)
{
    return memcmp(a, b, (size_t)n * 4) == 0;
}

void cr_verify_move(const uint32_t *nf, const uint32_t *of, int w, int h,
                    int rx, int ry, int rw, int rh, int dx, int dy, copy_op *out, int *n, int max)
{
    if (dx == 0 && dy == 0) return;
    /* Clip so both the destination and the source lie on the screen. */
    int x0 = rx, y0 = ry, x1 = rx + rw, y1 = ry + rh;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > w) x1 = w;
    if (y1 > h) y1 = h;
    if (x0 - dx < 0) x0 = dx;
    if (y0 - dy < 0) y0 = dy;
    if (x1 - dx > w) x1 = w + dx;
    if (y1 - dy > h) y1 = h + dy;
    if (x1 - x0 < 16 || y1 - y0 < CR_MIN_BAND_ROWS) return;
    int band = -1;
    for (int y = y0; y <= y1; y++) {
        int ok = y < y1 && row_equal(nf + (size_t)y * w + x0, of + (size_t)(y - dy) * w + (x0 - dx), x1 - x0);
        if (ok && band < 0) band = y;
        if (!ok && band >= 0) {
            if (y - band >= CR_MIN_BAND_ROWS && *n < max)
                out[(*n)++] = (copy_op){x0, band, x1 - x0, y - band, dx, dy};
            band = -1;
        }
    }
}

/* Hash of a row segment, two pixels per step (only used to find candidates; copies are verified). */
static uint64_t seg_hash(const uint32_t *p, int n)
{
    uint64_t h = 1469598103934665603ull, h2 = 0x9E3779B97F4A7C15ull;
    int x = 0;
    for (; x + 4 <= n; x += 4) {
        uint64_t a, b;
        memcpy(&a, p + x, 8); memcpy(&b, p + x + 2, 8);
        h = (h ^ a) * 0xff51afd7ed558ccdull;
        h2 = (h2 ^ b) * 0xc4ceb9fe1a85ec53ull;
    }
    for (; x < n; x++) h = (h ^ p[x]) * 1099511628211ull;
    h ^= h2 + (h >> 31);
    return h * 0x9E3779B97F4A7C15ull;
}

void cr_detect_scroll(const uint32_t *nf, const uint32_t *of, int w, int h,
                      const uint8_t *changed, int tx, int ty, int tile, copy_op *out, int *n, int max)
{
    int c = 0, i0 = tx, i1 = -1, j0 = ty, j1 = -1;
    for (int j = 0; j < ty; j++)
        for (int i = 0; i < tx; i++)
            if (changed[j * tx + i]) {
                c++;
                if (i < i0) i0 = i;
                if (i > i1) i1 = i;
                if (j < j0) j0 = j;
                if (j > j1) j1 = j;
            }
    if (c < CR_SCROLL_MIN_TILES || j1 - j0 < 2) return;
    int y0 = j0 * tile, y1 = (j1 + 1) * tile > h ? h : (j1 + 1) * tile;
    int rows = y1 - y0, segs = i1 - i0 + 1;
    /* Hash each row in tile-wide segments once; column ranges combine segment hashes. */
    uint64_t *os = malloc(sizeof(uint64_t) * rows * segs), *ns = malloc(sizeof(uint64_t) * rows * segs);
    for (int y = 0; y < rows; y++)
        for (int s = 0; s < segs; s++) {
            int x0 = (i0 + s) * tile, x1 = x0 + tile > w ? w : x0 + tile;
            const uint32_t *po = of + (size_t)(y0 + y) * w + x0, *pn = nf + (size_t)(y0 + y) * w + x0;
            os[y * segs + s] = seg_hash(po, x1 - x0); ns[y * segs + s] = seg_hash(pn, x1 - x0);
        }
    int hsize = 1;
    while (hsize < rows * 2) hsize <<= 1;
    int *slot = malloc(sizeof(int) * hsize);
    uint64_t *oh = malloc(sizeof(uint64_t) * rows), *nh = malloc(sizeof(uint64_t) * rows);
    uint8_t *ou = malloc(rows), *nu = malloc(rows);
    int *votes = malloc(sizeof(int) * ((size_t)rows * 2 + 1));
    /* Try the full column range, then without the edge tiles (a sidebar or scrollbar that does not move). */
    for (int trim = 0; trim < 4; trim++) {
        int a = trim & 1, b = segs - 1 - (trim >> 1);
        if (b < a || (trim && segs < 3)) continue;
        int x0 = (i0 + a) * tile, x1 = (i0 + b + 1) * tile > w ? w : (i0 + b + 1) * tile;
        for (int y = 0; y < rows; y++) {
            uint64_t ho = 7, hn = 7;
            int uo = 1, un = 1;
            for (int s = a; s <= b; s++) {
                ho = (ho ^ os[y * segs + s]) * 0x9E3779B97F4A7C15ull; hn = (hn ^ ns[y * segs + s]) * 0x9E3779B97F4A7C15ull;
                if (s > a) { uo &= os[y * segs + s] == os[y * segs + a]; un &= ns[y * segs + s] == ns[y * segs + a]; }
            }
            /* "uniform" here = all segments identical (blank lines and the like): useless for voting */
            oh[y] = ho; nh[y] = hn; ou[y] = (uint8_t)uo; nu[y] = (uint8_t)un;
        }
        for (int k = 0; k < hsize; k++) slot[k] = -1;
        for (int y = 0; y < rows; y++) {
            if (ou[y]) continue;
            unsigned k = (unsigned)(oh[y] ^ (oh[y] >> 29)) & (unsigned)(hsize - 1);
            while (slot[k] >= 0 && oh[slot[k]] != oh[y]) k = (k + 1) & (unsigned)(hsize - 1);
            if (slot[k] < 0) slot[k] = y;
        }
        memset(votes, 0, sizeof(int) * ((size_t)rows * 2 + 1));
        for (int y = 0; y < rows; y++) {
            if (nu[y] || nh[y] == oh[y]) continue;
            unsigned k = (unsigned)(nh[y] ^ (nh[y] >> 29)) & (unsigned)(hsize - 1);
            while (slot[k] >= 0 && oh[slot[k]] != nh[y]) k = (k + 1) & (unsigned)(hsize - 1);
            if (slot[k] >= 0) votes[y - slot[k] + rows]++;
        }
        int best = 0, bestv = 0;
        for (int d = 0; d <= rows * 2; d++)
            if (d != rows && votes[d] > bestv) { bestv = votes[d]; best = d - rows; }
        if (bestv >= CR_SCROLL_MIN_VOTES) {
            int before = *n;
            cr_verify_move(nf, of, w, h, x0, y0, x1 - x0, rows, 0, best, out, n, max);
            if (*n > before) break;
        }
    }
    free(os); free(ns); free(slot); free(oh); free(nh); free(ou); free(nu); free(votes);
}

void cr_residual(const copy_op *ops, int n, const uint8_t *changed, uint8_t *residual, int tx, int ty, int tile, int w, int h)
{
    memcpy(residual, changed, (size_t)tx * ty);
    for (int k = 0; k < n; k++) {
        const copy_op *o = &ops[k];
        for (int j = 0; j < ty; j++)
            for (int i = 0; i < tx; i++) {
                int x0 = i * tile, y0 = j * tile;
                int x1 = x0 + tile > w ? w : x0 + tile, y1 = y0 + tile > h ? h : y0 + tile;
                if (x0 >= o->x && y0 >= o->y && x1 <= o->x + o->w && y1 <= o->y + o->h) residual[j * tx + i] = 0;
            }
    }
}

static int cmp_down(const void *a, const void *b) { return ((const copy_op *)b)->y - ((const copy_op *)a)->y; }
static int cmp_up(const void *a, const void *b) { return ((const copy_op *)a)->y - ((const copy_op *)b)->y; }

void cr_order(copy_op *ops, int n)
{
    /* All ops of one frame share the shift: moving down, do the lowest band first, and so on. */
    if (n > 1) qsort(ops, (size_t)n, sizeof *ops, ops[0].dy > 0 ? cmp_down : cmp_up);
}
