/* Tight encoder decisions: which compression each part of the screen gets.
 *
 * This file and tight_policy.c hold only the analysis and the thresholds, with no I/O, so the same
 * rules can be ported to the Windows (C#) and macOS (Swift) servers. encode.c does the byte work.
 *
 * How an update rectangle is encoded (Tight, 32 bpp / depth 24 viewer):
 *   1. It is cut into horizontal bands TP_BLOCK pixels high, and each band into TP_BLOCK x TP_BLOCK
 *      blocks (the screen tiles).
 *   2. Each block's distinct colours are counted, stopping at tp_palette_limit() + 1.
 *   3. tp_choose() picks the method from the colour count:
 *        1 colour                      -> SOLID     (Tight fill, 4 bytes)
 *        2 colours                     -> MONO      (palette filter, 1 bit per pixel, zlib stream 1)
 *        3 .. palette limit            -> INDEXED   (palette filter, 1 byte per pixel, zlib stream 2)
 *        more, and JPEG allowed        -> JPEG      (quality from the viewer's quality level)
 *        more, lossless                -> FULLCOLOR (copy filter, 3 bytes per pixel, zlib stream 0)
 *      The palette limit is TP_PALETTE_MAX_JPEG (64) when the viewer asked for JPEG, so text, UI
 *      and flat graphics stay sharp and only photo-like blocks become JPEG, and
 *      TP_PALETTE_MAX_LOSSLESS (256) otherwise.
 *   4. Neighbouring blocks in a band are merged into one rectangle while they agree: SOLID blocks of
 *      the same colour; MONO/INDEXED blocks while the combined palette stays within the limit;
 *      JPEG with JPEG; FULLCOLOR with FULLCOLOR. A merged rectangle is at most TP_MAX_WIDTH wide.
 *   5. zlib levels per stream come from tp_zlib_level() and the viewer's compression level (0-9).
 */
#ifndef QVNC_TIGHT_POLICY_H
#define QVNC_TIGHT_POLICY_H

#include <stdint.h>

#define TP_BLOCK 64                  /* analysis block = screen tile size */
#define TP_MAX_WIDTH 2048            /* Tight limit on rectangle width */
#define TP_PALETTE_MAX_JPEG 64       /* more colours than this in a block counts as photo-like */
#define TP_PALETTE_MAX_LOSSLESS 256  /* Tight palettes hold at most 256 colours */
#define TP_MAX_PALETTE 256

/* Tight zlib stream numbers (the viewer keeps one inflater per stream). */
#define TP_STREAM_FULLCOLOR 0
#define TP_STREAM_MONO 1
#define TP_STREAM_INDEXED 2

typedef enum { TP_SOLID, TP_MONO, TP_INDEXED, TP_JPEG, TP_FULLCOLOR } tp_kind;

/* Highest colour count that still uses a palette. jpeg = viewer asked for JPEG (quality level set). */
int tp_palette_limit(int jpeg);

/* Counts distinct colours (0x00RRGGBB, low 24 bits) of a w x h block with the given row stride in
   pixels. Stops early and returns limit + 1 once there are more than 'limit'. Fills palette[] with
   the colours found (palette must hold limit + 1 entries). */
int tp_count_colors(const uint32_t *px, int w, int h, int stride, int limit, uint32_t *palette);

/* The method for a block with this many colours (as returned by tp_count_colors). */
tp_kind tp_choose(int ncolors, int jpeg);

/* zlib level for a stream at the viewer's compression level (0-9). */
int tp_zlib_level(int stream, int compress_level);

/* JPEG quality (1-100) for the viewer's quality level 0-9 (SPEC.md map). */
int tp_jpeg_quality(int level);

#endif
