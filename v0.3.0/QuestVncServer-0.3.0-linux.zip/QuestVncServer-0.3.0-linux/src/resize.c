/* Viewer-requested resolution changes (ExtendedDesktopSize / SetDesktopSize) with XRandR.
   libXrandr is loaded at run time, so the declarations below mirror <X11/extensions/Xrandr.h>. */
#define _GNU_SOURCE
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <dlfcn.h>
#include <X11/Xlib.h>

typedef XID RROutput, RRCrtc, RRMode;
typedef unsigned short Rotation;
typedef struct {
    RRMode id; unsigned int width, height; unsigned long dotClock;
    unsigned int hSyncStart, hSyncEnd, hTotal, hSkew, vSyncStart, vSyncEnd, vTotal;
    char *name; unsigned int nameLength; unsigned long modeFlags;
} RRModeInfo;
typedef struct {
    Time timestamp, configTimestamp; int ncrtc; RRCrtc *crtcs; int noutput; RROutput *outputs;
    int nmode; RRModeInfo *modes;
} RRScreenResources;
typedef struct {
    Time timestamp; RRCrtc crtc; char *name; int nameLen; unsigned long mm_width, mm_height;
    unsigned short connection, subpixel_order; int ncrtc; RRCrtc *crtcs; int nclone; RROutput *clones;
    int nmode, npreferred; RRMode *modes;
} RROutputInfo;
typedef struct {
    Time timestamp; int x, y; unsigned int width, height; RRMode mode; Rotation rotation;
    int noutput; RROutput *outputs; Rotation rotations; int npossible; RROutput *possible;
} RRCrtcInfo;

static RRScreenResources *(*p_GetRes)(Display *, Window);
static void (*p_FreeRes)(RRScreenResources *);
static RROutputInfo *(*p_GetOutput)(Display *, RRScreenResources *, RROutput);
static void (*p_FreeOutput)(RROutputInfo *);
static RRCrtcInfo *(*p_GetCrtc)(Display *, RRScreenResources *, RRCrtc);
static void (*p_FreeCrtc)(RRCrtcInfo *);
static Status (*p_SetCrtc)(Display *, RRScreenResources *, RRCrtc, Time, int, int, RRMode, Rotation, RROutput *, int);
static void (*p_SetScreenSize)(Display *, Window, int, int, int, int);
static Status (*p_GetSizeRange)(Display *, Window, int *, int *, int *, int *);

static Display *dpy;
static Window root;
static int ok;
static pthread_mutex_t rs_mu = PTHREAD_MUTEX_INITIALIZER;

/* Saved original state (valid when saved = 1). */
static int saved;
static RRCrtc s_crtc; static RRMode s_mode; static int s_x, s_y; static Rotation s_rot;
static RROutput *s_outputs; static int s_noutputs;
static int s_sw, s_sh, s_mmw, s_mmh;
static unsigned owner_id;   /* viewer whose request is in effect */

#define RR_Rotate_90 2
#define RR_Rotate_270 8
#define RR_Interlace 0x10

int resize_init(void)
{
    void *h = dlopen("libXrandr.so.2", RTLD_NOW | RTLD_LOCAL);
    if (!h) return -1;
    p_GetRes = dlsym(h, "XRRGetScreenResourcesCurrent");
    if (!p_GetRes) p_GetRes = dlsym(h, "XRRGetScreenResources");
    p_FreeRes = dlsym(h, "XRRFreeScreenResources");
    p_GetOutput = dlsym(h, "XRRGetOutputInfo");
    p_FreeOutput = dlsym(h, "XRRFreeOutputInfo");
    p_GetCrtc = dlsym(h, "XRRGetCrtcInfo");
    p_FreeCrtc = dlsym(h, "XRRFreeCrtcInfo");
    p_SetCrtc = dlsym(h, "XRRSetCrtcConfig");
    p_SetScreenSize = dlsym(h, "XRRSetScreenSize");
    p_GetSizeRange = dlsym(h, "XRRGetScreenSizeRange");
    if (!p_GetRes || !p_FreeRes || !p_GetOutput || !p_FreeOutput || !p_GetCrtc || !p_FreeCrtc ||
        !p_SetCrtc || !p_SetScreenSize || !p_GetSizeRange) return -1;
    dpy = XOpenDisplay(NULL);
    if (!dpy) return -1;
    int eb, erb;
    if (!XQueryExtension(dpy, "RANDR", &erb, &eb, &erb)) { XCloseDisplay(dpy); dpy = NULL; return -1; }
    root = DefaultRootWindow(dpy);
    ok = 1;
    return 0;
}

/* Current screen size from the server (Xlib's DisplayWidth/Height are cached and go stale). */
static void root_size(int *w, int *h)
{
    XWindowAttributes wa;
    XGetWindowAttributes(dpy, root, &wa);
    *w = wa.width; *h = wa.height;
}

static RRModeInfo *mode_info(RRScreenResources *res, RRMode id)
{
    for (int i = 0; i < res->nmode; i++) if (res->modes[i].id == id) return &res->modes[i];
    return NULL;
}

static double refresh(const RRModeInfo *m)
{
    return m->hTotal && m->vTotal ? (double)m->dotClock / ((double)m->hTotal * m->vTotal) : 0;
}

/* The CRTC showing the shared area (mon_x, mon_y, fb_w x fb_h). */
static RRCrtcInfo *find_crtc(RRScreenResources *res, RRCrtc *id)
{
    RRCrtcInfo *best = NULL; int best_score = -1;
    for (int i = 0; i < res->ncrtc; i++) {
        RRCrtcInfo *ci = p_GetCrtc(dpy, res, res->crtcs[i]);
        if (!ci) continue;
        int score = -1;
        if (ci->mode && ci->noutput > 0) {
            score = 0;
            if (mon_x >= ci->x && mon_x < ci->x + (int)ci->width && mon_y >= ci->y && mon_y < ci->y + (int)ci->height) score = 1;
            if (ci->x == mon_x && ci->y == mon_y && (int)ci->width == fb_w && (int)ci->height == fb_h) score = 2;
        }
        if (score > best_score) { if (best) p_FreeCrtc(best); best = ci; best_score = score; *id = res->crtcs[i]; }
        else p_FreeCrtc(ci);
    }
    if (best && best_score < 0) { p_FreeCrtc(best); best = NULL; }
    return best;
}

/* Bounding box of all active CRTCs with crtc 'id' given size w x h. */
static void bbox(RRScreenResources *res, RRCrtc id, int x, int y, int w, int h, int *bw, int *bh)
{
    *bw = x + w; *bh = y + h;
    for (int i = 0; i < res->ncrtc; i++) {
        if (res->crtcs[i] == id) continue;
        RRCrtcInfo *ci = p_GetCrtc(dpy, res, res->crtcs[i]);
        if (!ci) continue;
        if (ci->mode) {
            if (ci->x + (int)ci->width > *bw) *bw = ci->x + (int)ci->width;
            if (ci->y + (int)ci->height > *bh) *bh = ci->y + (int)ci->height;
        }
        p_FreeCrtc(ci);
    }
}

static int apply(RRScreenResources *res, RRCrtc crtc, int x, int y, RRMode mode, Rotation rot,
                 RROutput *outs, int nouts, int w, int h, int force_sw, int force_sh)
{
    int sw, sh;
    root_size(&sw, &sh);
    /* Only the ratio matters here (keeps the DPI); Xlib's cached values are consistent with each other. */
    int dw = DisplayWidth(dpy, DefaultScreen(dpy)), dh = DisplayHeight(dpy, DefaultScreen(dpy));
    int mmw = DisplayWidthMM(dpy, DefaultScreen(dpy)), mmh = DisplayHeightMM(dpy, DefaultScreen(dpy));
    int nw, nh;
    bbox(res, crtc, x, y, w, h, &nw, &nh);
    if (force_sw > 0) { nw = force_sw; nh = force_sh; }
    int minw, minh, maxw, maxh;
    if (p_GetSizeRange(dpy, root, &minw, &minh, &maxw, &maxh)) {
        if (nw > maxw || nh > maxh) return -1;
        if (nw < minw) nw = minw;
        if (nh < minh) nh = minh;
    }
    double dpmm_x = mmw > 0 ? (double)dw / mmw : 96 / 25.4, dpmm_y = mmh > 0 ? (double)dh / mmh : 96 / 25.4;
    /* Grow the screen first so the CRTC fits, set the CRTC, then shrink to the final size. */
    int gw = nw > sw ? nw : sw, gh = nh > sh ? nh : sh;
    if (gw != sw || gh != sh) p_SetScreenSize(dpy, root, gw, gh, (int)lround(gw / dpmm_x), (int)lround(gh / dpmm_y));
    Status st = p_SetCrtc(dpy, res, crtc, CurrentTime, x, y, mode, rot, outs, nouts);
    if (st != 0) {   /* RRSetConfigSuccess = 0 */
        if (gw != sw || gh != sh) p_SetScreenSize(dpy, root, sw, sh, (int)lround(sw / dpmm_x), (int)lround(sh / dpmm_y));
        XSync(dpy, False);
        return -1;
    }
    if (nw != gw || nh != gh) p_SetScreenSize(dpy, root, nw, nh, (int)lround(nw / dpmm_x), (int)lround(nh / dpmm_y));
    XSync(dpy, False);
    return 0;
}

int resize_request(client_t *c, int rw, int rh, int *out_w, int *out_h)
{
    if (!ok) return 2;
    pthread_mutex_lock(&rs_mu);
    int status = 2;
    RRScreenResources *res = p_GetRes(dpy, root);
    RRCrtc crtc = 0;
    RRCrtcInfo *ci = res ? find_crtc(res, &crtc) : NULL;
    RROutputInfo *oi = ci ? p_GetOutput(dpy, res, ci->outputs[0]) : NULL;
    if (oi) {
        int swap = (ci->rotation & (RR_Rotate_90 | RR_Rotate_270)) != 0;
        RRModeInfo *cur = mode_info(res, ci->mode);
        double cur_hz = cur ? refresh(cur) : 60;
        int maxw = 1 << 30, maxh = 1 << 30, d1, d2;
        p_GetSizeRange(dpy, root, &d1, &d2, &maxw, &maxh);
        RRModeInfo *exact = NULL, *aspect = NULL, *inside = NULL;
        double want_ar = (double)rw / rh;
        for (int i = 0; i < oi->nmode; i++) {
            RRModeInfo *m = mode_info(res, oi->modes[i]);
            if (!m || (m->modeFlags & RR_Interlace)) continue;
            int mw = swap ? (int)m->height : (int)m->width, mh = swap ? (int)m->width : (int)m->height;
            int bw, bh;
            bbox(res, crtc, ci->x, ci->y, mw, mh, &bw, &bh);
            if (bw > maxw || bh > maxh) continue;
            if (mw == rw && mh == rh) {
                if (!exact || fabs(refresh(m) - cur_hz) < fabs(refresh(exact) - cur_hz)) exact = m;
                continue;
            }
            if (mw > rw || mh > rh) continue;
            long area = (long)mw * mh;
            int sw_ = swap ? 1 : 0; (void)sw_;
            if (fabs((double)mw / mh - want_ar) / want_ar <= 0.02) {
                long a2 = aspect ? (long)(swap ? aspect->height : aspect->width) * (swap ? aspect->width : aspect->height) : -1;
                if (area > a2) aspect = m;
            }
            long a3 = inside ? (long)(swap ? inside->height : inside->width) * (swap ? inside->width : inside->height) : -1;
            if (area > a3) inside = m;
        }
        RRModeInfo *pick = exact ? exact : aspect ? aspect : inside;
        if (!pick) {
            status = 3;
        } else {
            int pw = swap ? (int)pick->height : (int)pick->width, ph = swap ? (int)pick->width : (int)pick->height;
            if (!saved) {
                saved = 1;
                s_crtc = crtc; s_mode = ci->mode; s_x = ci->x; s_y = ci->y; s_rot = ci->rotation;
                s_noutputs = ci->noutput;
                s_outputs = malloc(sizeof(RROutput) * (size_t)ci->noutput);
                memcpy(s_outputs, ci->outputs, sizeof(RROutput) * (size_t)ci->noutput);
                root_size(&s_sw, &s_sh);
                s_mmw = DisplayWidthMM(dpy, DefaultScreen(dpy)); s_mmh = DisplayHeightMM(dpy, DefaultScreen(dpy));
            }
            if (pick->id == ci->mode) {
                status = 0;
            } else if (apply(res, crtc, ci->x, ci->y, pick->id, ci->rotation, ci->outputs, ci->noutput, pw, ph, 0, 0) == 0) {
                status = 0;
            }
            if (status == 0) {
                owner_id = c->id;
                *out_w = pw; *out_h = ph;
            }
        }
    }
    if (oi) p_FreeOutput(oi);
    if (ci) p_FreeCrtc(ci);
    if (res) p_FreeRes(res);
    pthread_mutex_unlock(&rs_mu);
    return status;
}

/* Puts the original mode back. Returns 1 if something was changed. */
static int restore_locked(void)
{
    if (!saved) return 0;
    int changed = 0;
    RRScreenResources *res = p_GetRes(dpy, root);
    if (res) {
        RRCrtcInfo *ci = p_GetCrtc(dpy, res, s_crtc);
        if (ci) {
            int sw, sh;
            root_size(&sw, &sh);
            if (ci->mode != s_mode || ci->x != s_x || ci->y != s_y || sw != s_sw || sh != s_sh) {
                RRModeInfo *m = mode_info(res, s_mode);
                if (m) {
                    int swap = (s_rot & (RR_Rotate_90 | RR_Rotate_270)) != 0;
                    int w = swap ? (int)m->height : (int)m->width, h = swap ? (int)m->width : (int)m->height;
                    if (apply(res, s_crtc, s_x, s_y, s_mode, s_rot, s_outputs, s_noutputs, w, h, s_sw, s_sh) == 0) changed = 1;
                }
            }
            p_FreeCrtc(ci);
        }
        p_FreeRes(res);
    }
    saved = 0; owner_id = 0;
    free(s_outputs); s_outputs = NULL;
    return changed;
}

int resize_client_gone(client_t *c)
{
    if (!ok) return 0;
    pthread_mutex_lock(&rs_mu);
    int r = 0;
    if (saved && owner_id == c->id) {
        r = restore_locked();
        if (r) logmsg("Resolution restored to %dx%d (%s disconnected)", s_sw, s_sh, c->addr);
    }
    pthread_mutex_unlock(&rs_mu);
    return r;
}

void resize_restore_on_exit(void)
{
    if (!ok) return;
    pthread_mutex_lock(&rs_mu);
    if (restore_locked()) printf("Resolution restored to %dx%d.\n", s_sw, s_sh);
    pthread_mutex_unlock(&rs_mu);
}
