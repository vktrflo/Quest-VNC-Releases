/* Sound capture: parec (PulseAudio / PipeWire-pulse) or pw-record on the default output's monitor,
   48 kHz stereo s16le, or a test tone. Hands 10 ms chunks to clients_audio(). */
#define _GNU_SOURCE
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <poll.h>
#include <math.h>
#include <time.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/prctl.h>

int audio_ok;
const char *audio_source = "none";

#define CHUNK_FRAMES (AUDIO_RATE / 100)
#define CHUNK_BYTES (CHUNK_FRAMES * AUDIO_CH * 2)

static char *const parec_cmd[] = {"parec", "--device=@DEFAULT_MONITOR@", "--format=s16le", "--rate=48000",
                                  "--channels=2", "--latency-msec=20", "--raw", NULL};
static char *const pwrec_cmd[] = {"pw-record", "-P", "{ stream.capture.sink=true }", "--format=s16",
                                  "--rate=48000", "--channels=2", "-", NULL};
static char *const *cmd;
static pid_t child = -1;
static int child_fd = -1;

static int spawn(char *const *argv)
{
    int p[2];
    if (pipe2(p, O_CLOEXEC) < 0) return -1;
    pid_t pid = fork();
    if (pid < 0) { close(p[0]); close(p[1]); return -1; }
    if (pid == 0) {
        prctl(PR_SET_PDEATHSIG, SIGTERM);
        dup2(p[1], 1);
        int dn = open("/dev/null", O_RDWR);
        if (dn >= 0) { dup2(dn, 0); dup2(dn, 2); }
        close(p[0]); close(p[1]);
        execvp(argv[0], argv);
        _exit(127);
    }
    close(p[1]);
    child = pid; child_fd = p[0];
    return 0;
}

static void reap(void)
{
    if (child > 0) { kill(child, SIGTERM); waitpid(child, NULL, 0); }
    if (child_fd >= 0) close(child_fd);
    child = -1; child_fd = -1;
}

void audio_stop(void)
{
    pid_t pid = child;
    if (pid > 0) { kill(pid, SIGTERM); waitpid(pid, NULL, 0); }
}

/* Starts argv and checks it is still running (or produced data) after 1.5 s. */
static int probe(char *const *argv)
{
    if (spawn(argv) < 0) return 0;
    for (int i = 0; i < 15; i++) {
        struct pollfd pfd = {child_fd, POLLIN, 0};
        if (poll(&pfd, 1, 100) > 0) {
            if (pfd.revents & POLLIN) return 1;
            /* POLLHUP without data: the program exited */
            reap(); return 0;
        }
        if (waitpid(child, NULL, WNOHANG) == child) { child = -1; reap(); return 0; }
    }
    return 1;
}

static int read_full(int fd, uint8_t *b, int n)
{
    int got = 0;
    while (got < n) {
        ssize_t r = read(fd, b + got, (size_t)(n - got));
        if (r < 0 && errno == EINTR) continue;
        if (r <= 0) return got;
        got += (int)r;
    }
    return got;
}

static void *capture_loop(void *arg)
{
    (void)arg;
    uint8_t buf[CHUNK_BYTES];
    int16_t pcm[CHUNK_FRAMES * AUDIO_CH];
    for (;;) {
        if (child_fd < 0 && spawn(cmd) < 0) { sleep(2); continue; }
        for (;;) {
            int n = read_full(child_fd, buf, CHUNK_BYTES);
            if (n < CHUNK_BYTES) break;
            for (int i = 0; i < CHUNK_FRAMES * AUDIO_CH; i++) pcm[i] = (int16_t)(buf[2 * i] | (buf[2 * i + 1] << 8));
            clients_audio(pcm, CHUNK_FRAMES);
        }
        reap();
        logmsg("Sound capture (%s) stopped, restarting in 2 s", cmd[0]);
        sleep(2);
    }
    return NULL;
}

static void *tone_loop(void *arg)
{
    (void)arg;
    int16_t pcm[CHUNK_FRAMES * AUDIO_CH];
    long frame = 0;
    struct timespec next;
    clock_gettime(CLOCK_MONOTONIC, &next);
    for (;;) {
        for (int i = 0; i < CHUNK_FRAMES; i++, frame++) {
            int16_t v = 0;
            if (frame % AUDIO_RATE < AUDIO_RATE / 4) v = (int16_t)(sin(2 * M_PI * 440.0 * frame / AUDIO_RATE) * 6000);
            pcm[2 * i] = pcm[2 * i + 1] = v;
        }
        clients_audio(pcm, CHUNK_FRAMES);
        next.tv_nsec += 10000000;
        if (next.tv_nsec >= 1000000000) { next.tv_nsec -= 1000000000; next.tv_sec++; }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);
    }
    return NULL;
}

int audio_init(void)
{
    pthread_t t;
    if (g_opt.no_audio) return 0;
    if (g_opt.test_tone) {
        audio_ok = 1; audio_source = "test tone (440 Hz beep every second)";
        pthread_create(&t, NULL, tone_loop, NULL);
        pthread_detach(t);
        return 1;
    }
    if (probe(parec_cmd)) { cmd = parec_cmd; audio_source = "parec (default output monitor)"; }
    else if (probe(pwrec_cmd)) { cmd = pwrec_cmd; audio_source = "pw-record (default output monitor)"; }
    else return 0;
    audio_ok = 1;
    pthread_create(&t, NULL, capture_loop, NULL);
    pthread_detach(t);
    return 1;
}
