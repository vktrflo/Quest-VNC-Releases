/* Clipboard: CLIPBOARD selection <-> RFB cut text (Latin-1). Uses XFixes selection notification,
   or polls once a second without it. */
#define _GNU_SOURCE
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/select.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/extensions/Xfixes.h>

static Display *dpy;
static Window win;
static Atom A_CLIPBOARD, A_UTF8, A_TARGETS, A_TEXT, A_PROP, A_INCR;
static int wake_pipe[2] = {-1, -1};
static int fixes_ev, have_fixes;

static pthread_mutex_t clip_mu = PTHREAD_MUTEX_INITIALIZER;
static char *pending; static size_t pending_len; static int pending_set;   /* viewer -> PC */
static char *owned_utf8; static size_t owned_len;                          /* what we serve */
static char *last_seen; static size_t last_seen_len;                       /* last PC text */

static char *latin1_to_utf8(const char *s, size_t n, size_t *outlen)
{
    char *o = malloc(n * 2 + 1); size_t k = 0;
    for (size_t i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c < 0x80) o[k++] = (char)c;
        else { o[k++] = (char)(0xc0 | (c >> 6)); o[k++] = (char)(0x80 | (c & 0x3f)); }
    }
    o[k] = 0; *outlen = k; return o;
}

static char *utf8_to_latin1(const unsigned char *s, size_t n, size_t *outlen)
{
    char *o = malloc(n + 1); size_t k = 0;
    for (size_t i = 0; i < n;) {
        unsigned c = s[i], cp, len;
        if (c < 0x80) { cp = c; len = 1; }
        else if ((c & 0xe0) == 0xc0) { cp = c & 0x1f; len = 2; }
        else if ((c & 0xf0) == 0xe0) { cp = c & 0x0f; len = 3; }
        else if ((c & 0xf8) == 0xf0) { cp = c & 0x07; len = 4; }
        else { o[k++] = '?'; i++; continue; }
        if (i + len > n) { o[k++] = '?'; break; }
        for (unsigned j = 1; j < len; j++) cp = (cp << 6) | (s[i + j] & 0x3f);
        o[k++] = cp <= 0xff ? (char)cp : '?';
        i += len;
    }
    o[k] = 0; *outlen = k; return o;
}

void clipboard_set_from_viewer(const char *latin1, size_t len)
{
    if (wake_pipe[1] < 0) return;
    pthread_mutex_lock(&clip_mu);
    free(pending);
    pending = malloc(len + 1); memcpy(pending, latin1, len); pending[len] = 0;
    pending_len = len; pending_set = 1;
    pthread_mutex_unlock(&clip_mu);
    char b = 1;
    if (write(wake_pipe[1], &b, 1) < 0) { /* pipe full: a wake-up is already queued */ }
}

static void got_pc_text(const unsigned char *data, size_t n, int utf8)
{
    size_t len;
    char *l1;
    if (utf8) l1 = utf8_to_latin1(data, n, &len);
    else { l1 = malloc(n + 1); memcpy(l1, data, n); l1[n] = 0; len = n; }
    if (last_seen && last_seen_len == len && memcmp(last_seen, l1, len) == 0) { free(l1); return; }
    free(last_seen); last_seen = l1; last_seen_len = len;
    clients_cut_text(l1, len, NULL);
}

static void request_text(Atom target)
{
    XConvertSelection(dpy, A_CLIPBOARD, target, A_PROP, win, CurrentTime);
}

static void handle_request(XSelectionRequestEvent *rq)
{
    XSelectionEvent ev;
    memset(&ev, 0, sizeof ev);
    ev.type = SelectionNotify; ev.display = rq->display; ev.requestor = rq->requestor;
    ev.selection = rq->selection; ev.target = rq->target; ev.time = rq->time;
    Atom prop = rq->property != None ? rq->property : rq->target;
    ev.property = None;
    if (owned_utf8) {
        if (rq->target == A_TARGETS) {
            Atom t[4] = {A_TARGETS, A_UTF8, XA_STRING, A_TEXT};
            XChangeProperty(dpy, rq->requestor, prop, XA_ATOM, 32, PropModeReplace, (unsigned char *)t, 4);
            ev.property = prop;
        } else if (rq->target == A_UTF8 || rq->target == A_TEXT) {
            XChangeProperty(dpy, rq->requestor, prop, A_UTF8, 8, PropModeReplace, (unsigned char *)owned_utf8, (int)owned_len);
            ev.property = prop;
        } else if (rq->target == XA_STRING) {
            size_t n; char *l1 = utf8_to_latin1((unsigned char *)owned_utf8, owned_len, &n);
            XChangeProperty(dpy, rq->requestor, prop, XA_STRING, 8, PropModeReplace, (unsigned char *)l1, (int)n);
            free(l1);
            ev.property = prop;
        }
    }
    XSendEvent(dpy, rq->requestor, False, 0, (XEvent *)&ev);
}

static void *clip_thread(void *arg)
{
    (void)arg;
    int xfd = ConnectionNumber(dpy);
    Window last_owner = None;
    for (;;) {
        while (XPending(dpy)) {
            XEvent e;
            XNextEvent(dpy, &e);
            if (have_fixes && e.type == fixes_ev + XFixesSelectionNotify) {
                XFixesSelectionNotifyEvent *se = (XFixesSelectionNotifyEvent *)&e;
                if (se->owner != None && se->owner != win) request_text(A_UTF8);
            } else if (e.type == SelectionNotify) {
                XSelectionEvent *se = &e.xselection;
                if (se->property == None) {
                    if (se->target == A_UTF8) request_text(XA_STRING);
                    continue;
                }
                Atom type; int fmt; unsigned long n, after; unsigned char *data = NULL;
                if (XGetWindowProperty(dpy, win, A_PROP, 0, 1 << 22, True, AnyPropertyType, &type, &fmt, &n, &after, &data) == Success) {
                    if (type != A_INCR && fmt == 8 && data) got_pc_text(data, n, type == A_UTF8);
                    if (data) XFree(data);
                }
            } else if (e.type == SelectionRequest) {
                handle_request(&e.xselectionrequest);
            } else if (e.type == SelectionClear) {
                /* Someone else owns it now; the XFixes notification fetches the new text. */
            }
        }
        XFlush(dpy);
        fd_set fds; FD_ZERO(&fds); FD_SET(xfd, &fds); FD_SET(wake_pipe[0], &fds);
        struct timeval tv = {1, 0};
        int r = select((xfd > wake_pipe[0] ? xfd : wake_pipe[0]) + 1, &fds, NULL, NULL, &tv);
        if (r > 0 && FD_ISSET(wake_pipe[0], &fds)) {
            char b[64];
            while (read(wake_pipe[0], b, sizeof b) > 0) { }
            pthread_mutex_lock(&clip_mu);
            if (pending_set) {
                free(owned_utf8);
                owned_utf8 = latin1_to_utf8(pending, pending_len, &owned_len);
                /* Remember it so the change notification does not echo it back. */
                free(last_seen); last_seen = pending; last_seen_len = pending_len;
                pending = NULL; pending_set = 0;
                XSetSelectionOwner(dpy, A_CLIPBOARD, win, CurrentTime);
                XSetSelectionOwner(dpy, XA_PRIMARY, win, CurrentTime);
                XFlush(dpy);
            }
            pthread_mutex_unlock(&clip_mu);
        }
        if (!have_fixes && r == 0) {
            /* Poll: ask the owner once a second; unchanged text is filtered in got_pc_text. */
            Window o = XGetSelectionOwner(dpy, A_CLIPBOARD);
            if (o != None && o != win) request_text(A_UTF8);
            last_owner = o;
        }
    }
    (void)last_owner;
    return NULL;
}

int clipboard_init(void)
{
    dpy = XOpenDisplay(NULL);
    if (!dpy) return -1;
    win = XCreateSimpleWindow(dpy, DefaultRootWindow(dpy), 0, 0, 1, 1, 0, 0, 0);
    A_CLIPBOARD = XInternAtom(dpy, "CLIPBOARD", False);
    A_UTF8 = XInternAtom(dpy, "UTF8_STRING", False);
    A_TARGETS = XInternAtom(dpy, "TARGETS", False);
    A_TEXT = XInternAtom(dpy, "TEXT", False);
    A_PROP = XInternAtom(dpy, "QUESTVNC_CLIP", False);
    A_INCR = XInternAtom(dpy, "INCR", False);
    int err;
    if (XFixesQueryExtension(dpy, &fixes_ev, &err)) {
        have_fixes = 1;
        XFixesSelectSelectionInput(dpy, win, A_CLIPBOARD, XFixesSetSelectionOwnerNotifyMask);
    }
    if (pipe2(wake_pipe, O_CLOEXEC) < 0) return -1;
    fcntl(wake_pipe[0], F_SETFL, O_NONBLOCK);
    fcntl(wake_pipe[1], F_SETFL, O_NONBLOCK);
    XFlush(dpy);
    pthread_t t;
    pthread_create(&t, NULL, clip_thread, NULL);
    pthread_detach(t);
    return 0;
}
