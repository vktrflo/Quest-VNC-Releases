/* Screen capture of the shared monitor.
   - XDamage says which areas changed; only those are fetched with XShmGetImage (into 'raw', the
     screen without the pointer). Without XDamage, or when it proves unreliable (some compositors),
     the whole monitor is fetched every tick instead.
   - A slow sweep re-reads one band of tiles per tick as a safety net for missed damage.
   - The pointer (XFixes cursor image) is drawn over 'raw' into 'staging'; 64x64 tiles of staging
     are compared with the framebuffer and only real changes are passed on to the viewers.
   - Capture runs as soon as damage arrives, at most --fps times a second. */
#define _GNU_SOURCE
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <dlfcn.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/extensions/XShm.h>
#include <X11/extensions/Xfixes.h>
#include <X11/extensions/Xdamage.h>
#include <poll.h>
#include <fcntl.h>

pthread_rwlock_t fb_lock = PTHREAD_RWLOCK_INITIALIZER;
uint32_t *fb_pixels;
int fb_w, fb_h;
unsigned long fb_gen = 1;
int mon_x, mon_y;

static Display *dpy;
static Window root;
static int use_shm, have_xfixes;
static XImage *img;           /* full-size shm image; sub-rects are fetched into the same segment */
static XShmSegmentInfo shminfo;
static uint32_t *raw;         /* screen without the pointer, cap_w x cap_h */
static uint32_t *staging;     /* raw + pointer, for the tiles being checked */
static uint32_t *prev_raw;    /* raw as of the previous frame: CopyRect detection compares without the pointer */
static int cap_w, cap_h;
static int have_damage, damage_ev;
static Damage damage;
static XserverRegion dregion;
static int fixes_ev;
static int wake_pipe[2] = {-1, -1};
/* top-level windows, for CopyRect on window moves */
typedef struct { Window id; int x, y, w, h, cx, cy, cw, ch, mapped; } wtrack;
static wtrack *wins; static int nwins, wcap;
/* pointer image */
static uint32_t *cur_px; static int cur_w, cur_h, cur_xhot, cur_yhot, cur_x, cur_y, cur_valid;
static volatile int geom_now;
static volatile unsigned geom_requester;

void capture_geometry_now(unsigned requester)
{
    pthread_mutex_lock(&clients_mu);
    geom_requester = requester;
    geom_now = 1;
    pthread_cond_broadcast(&clients_cv);
    pthread_mutex_unlock(&clients_mu);
    char b = 1;
    if (wake_pipe[1] >= 0 && write(wake_pipe[1], &b, 1) < 0) { }
}

void capture_wake(void)
{
    char b = 1;
    if (wake_pipe[1] >= 0 && write(wake_pipe[1], &b, 1) < 0) { }
}

/* --- XRandR monitors, loaded at run time so the binary does not need libXrandr --- */
typedef struct {
    Atom name; Bool primary; Bool automatic; int noutput;
    int x, y, width, height, mwidth, mheight; void *outputs;
} RRMonitor;
static RRMonitor *(*p_XRRGetMonitors)(Display *, Window, Bool, int *);
static void (*p_XRRFreeMonitors)(RRMonitor *);

static void load_randr(void)
{
    void *h = dlopen("libXrandr.so.2", RTLD_NOW | RTLD_LOCAL);
    if (!h) return;
    p_XRRGetMonitors = (RRMonitor *(*)(Display *, Window, Bool, int *))dlsym(h, "XRRGetMonitors");
    p_XRRFreeMonitors = (void (*)(RRMonitor *))dlsym(h, "XRRFreeMonitors");
    if (!p_XRRGetMonitors || !p_XRRFreeMonitors) p_XRRGetMonitors = NULL;
}

/* Area of the chosen monitor. Returns 0 on success. */
static int monitor_area(int *x, int *y, int *w, int *h, int verbose)
{
    XWindowAttributes wa;
    XGetWindowAttributes(dpy, root, &wa);
    *x = 0; *y = 0; *w = wa.width; *h = wa.height;
    int n = 0;
    RRMonitor *m = p_XRRGetMonitors ? p_XRRGetMonitors(dpy, root, True, &n) : NULL;
    if (verbose && m && n > 1) {
        for (int i = 0; i < n; i++)
            printf("  monitor %d: %dx%d at %d,%d%s\n", i + 1, m[i].width, m[i].height, m[i].x, m[i].y,
                   m[i].primary ? " (primary)" : "");
    }
    int pick = -1;
    if (m && n > 0) {
        if (g_opt.monitor == 0) {
            pick = 0;
            for (int i = 0; i < n; i++) if (m[i].primary) { pick = i; break; }
        } else if (g_opt.monitor <= n) {
            pick = g_opt.monitor - 1;
        }
    }
    if (g_opt.monitor > 0 && pick < 0) {
        if (m) p_XRRFreeMonitors(m);
        if (verbose) fprintf(stderr, "Monitor %d not found (%d monitor(s) present).\n", g_opt.monitor, n);
        return -1;
    }
    if (pick >= 0) {
        int mx = m[pick].x, my = m[pick].y, mw = m[pick].width, mh = m[pick].height;
        if (mx < 0) { mw += mx; mx = 0; }
        if (my < 0) { mh += my; my = 0; }
        if (mx + mw > wa.width) mw = wa.width - mx;
        if (my + mh > wa.height) mh = wa.height - my;
        if (mw > 0 && mh > 0) { *x = mx; *y = my; *w = mw; *h = mh; }
    }
    if (m) p_XRRFreeMonitors(m);
    return 0;
}

static int x_error(Display *d, XErrorEvent *e) { (void)d; (void)e; return 0; }
static int x_io_error(Display *d)
{
    (void)d;
    fprintf(stderr, "Lost the connection to the X server. Exiting.\n");
    _exit(1);
}

static void free_image(void)
{
    if (img) {
        if (use_shm) {
            XShmDetach(dpy, &shminfo);
            XSync(dpy, False);
            XDestroyImage(img);
            shmdt(shminfo.shmaddr);
        } else {
            XDestroyImage(img);
        }
        img = NULL;
    }
    free(raw); raw = NULL;
    free(staging); staging = NULL;
    free(prev_raw); prev_raw = NULL;
}

static int alloc_image(int w, int h)
{
    Visual *vis = DefaultVisual(dpy, DefaultScreen(dpy));
    int depth = DefaultDepth(dpy, DefaultScreen(dpy));
    if (use_shm) {
        img = XShmCreateImage(dpy, vis, depth, ZPixmap, NULL, &shminfo, w, h);
        if (img) {
            shminfo.shmid = shmget(IPC_PRIVATE, (size_t)img->bytes_per_line * img->height, IPC_CREAT | 0600);
            if (shminfo.shmid >= 0) {
                shminfo.shmaddr = img->data = shmat(shminfo.shmid, NULL, 0);
                shminfo.readOnly = False;
                if (shminfo.shmaddr != (char *)-1 && XShmAttach(dpy, &shminfo)) {
                    XSync(dpy, False);
                    shmctl(shminfo.shmid, IPC_RMID, NULL);
                } else {
                    shmctl(shminfo.shmid, IPC_RMID, NULL);
                    XDestroyImage(img); img = NULL;
                }
            } else {
                XDestroyImage(img); img = NULL;
            }
        }
        if (!img) { use_shm = 0; fprintf(stderr, "MIT-SHM not usable, using slower XGetImage.\n"); }
    }
    cap_w = w; cap_h = h;
    raw = malloc((size_t)w * h * 4);
    staging = malloc((size_t)w * h * 4);
    prev_raw = calloc((size_t)w * h, 4);
    return raw && staging && prev_raw ? 0 : -1;
}

/* Copies an X image (any true-colour layout) into raw at (dx, dy). */
static void image_to_raw(XImage *im, int dx, int dy, int w, int h)
{
    if (im->bits_per_pixel == 32 && im->red_mask == 0xff0000 && im->green_mask == 0xff00 &&
        im->blue_mask == 0xff && im->byte_order == LSBFirst) {
        for (int y = 0; y < h; y++)
            memcpy(raw + (size_t)(dy + y) * cap_w + dx, im->data + (size_t)y * im->bytes_per_line, (size_t)w * 4);
        return;
    }
    unsigned long rm = im->red_mask, gm = im->green_mask, bm = im->blue_mask;
    int rs = __builtin_ctzl(rm), gs = __builtin_ctzl(gm), bs = __builtin_ctzl(bm);
    unsigned long rmax = rm >> rs, gmax = gm >> gs, bmax = bm >> bs;
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            unsigned long p = XGetPixel(im, x, y);
            uint32_t r = (uint32_t)(((p & rm) >> rs) * 255 / rmax);
            uint32_t g = (uint32_t)(((p & gm) >> gs) * 255 / gmax);
            uint32_t b = (uint32_t)(((p & bm) >> bs) * 255 / bmax);
            raw[(size_t)(dy + y) * cap_w + dx + x] = (r << 16) | (g << 8) | b;
        }
}

/* Fetches a rect of the shared monitor (monitor coordinates) into raw. */
static int grab_rect(int x, int y, int w, int h)
{
    if (w <= 0 || h <= 0) return 0;
    if (use_shm) {
        XImage *sub = XShmCreateImage(dpy, DefaultVisual(dpy, DefaultScreen(dpy)), DefaultDepth(dpy, DefaultScreen(dpy)),
                                      ZPixmap, shminfo.shmaddr, &shminfo, w, h);
        if (!sub) return -1;
        int ok = XShmGetImage(dpy, root, sub, mon_x + x, mon_y + y, AllPlanes);
        if (ok) image_to_raw(sub, x, y, w, h);
        XDestroyImage(sub);
        return ok ? 0 : -1;
    }
    XImage *im = XGetImage(dpy, root, mon_x + x, mon_y + y, w, h, AllPlanes, ZPixmap);
    if (!im) return -1;
    image_to_raw(im, x, y, w, h);
    XDestroyImage(im);
    return 0;
}

static wtrack *win_find(Window id, int add)
{
    for (int i = 0; i < nwins; i++) if (wins[i].id == id) return &wins[i];
    if (!add) return NULL;
    if (nwins == wcap) { wcap = wcap ? wcap * 2 : 256; wins = realloc(wins, sizeof *wins * (size_t)wcap); }
    wtrack *w = &wins[nwins++];
    memset(w, 0, sizeof *w);
    w->id = id;
    return w;
}

static void win_remove(Window id)
{
    for (int i = 0; i < nwins; i++) if (wins[i].id == id) { wins[i] = wins[--nwins]; return; }
}

static void windows_init(void)
{
    XSelectInput(dpy, root, SubstructureNotifyMask);
    Window r, p, *kids = NULL; unsigned n = 0;
    if (!XQueryTree(dpy, root, &r, &p, &kids, &n)) return;
    for (unsigned i = 0; i < n; i++) {
        XWindowAttributes wa;
        if (!XGetWindowAttributes(dpy, kids[i], &wa)) continue;
        wtrack *w = win_find(kids[i], 1);
        w->x = w->cx = wa.x; w->y = w->cy = wa.y; w->w = w->cw = wa.width; w->h = w->ch = wa.height;
        w->mapped = wa.map_state == IsViewable;
    }
    if (kids) XFree(kids);
}

static void window_event(XEvent *e)
{
    wtrack *w;
    switch (e->type) {
    case CreateNotify:
        w = win_find(e->xcreatewindow.window, 1);
        w->x = w->cx = e->xcreatewindow.x; w->y = w->cy = e->xcreatewindow.y;
        w->w = w->cw = e->xcreatewindow.width; w->h = w->ch = e->xcreatewindow.height;
        break;
    case DestroyNotify: win_remove(e->xdestroywindow.window); break;
    case MapNotify: if ((w = win_find(e->xmap.window, 0))) w->mapped = 1; break;
    case UnmapNotify: if ((w = win_find(e->xunmap.window, 0))) w->mapped = 0; break;
    case ConfigureNotify:
        if (e->xconfigure.window == root) break;
        w = win_find(e->xconfigure.window, 1);
        w->x = e->xconfigure.x; w->y = e->xconfigure.y; w->w = e->xconfigure.width; w->h = e->xconfigure.height;
        break;
    }
}

static void fetch_cursor_image(void)
{
    if (!have_xfixes) return;
    XFixesCursorImage *ci = XFixesGetCursorImage(dpy);
    if (!ci) return;
    free(cur_px);
    cur_w = ci->width; cur_h = ci->height; cur_xhot = ci->xhot; cur_yhot = ci->yhot;
    cur_px = malloc((size_t)cur_w * cur_h * 4 + 4);
    for (int i = 0; i < cur_w * cur_h; i++) cur_px[i] = (uint32_t)ci->pixels[i];
    cur_x = ci->x; cur_y = ci->y;
    cur_valid = 1;
    XFree(ci);
}

/* Pointer rectangle in monitor coordinates. */
static rect_t cursor_rect(void)
{
    if (!cur_valid) return (rect_t){0, 0, 0, 0};
    return (rect_t){cur_x - cur_xhot - mon_x, cur_y - cur_yhot - mon_y, cur_w, cur_h};
}

/* Composes raw + pointer into staging for one tile. */
static void compose_tile(int x0, int y0, int x1, int y1)
{
    for (int y = y0; y < y1; y++)
        memcpy(staging + (size_t)y * cap_w + x0, raw + (size_t)y * cap_w + x0, (size_t)(x1 - x0) * 4);
    rect_t cr = cursor_rect();
    int cx0 = cr.x > x0 ? cr.x : x0, cy0 = cr.y > y0 ? cr.y : y0;
    int cx1 = cr.x + cr.w < x1 ? cr.x + cr.w : x1, cy1 = cr.y + cr.h < y1 ? cr.y + cr.h : y1;
    for (int y = cy0; y < cy1; y++)
        for (int x = cx0; x < cx1; x++) {
            uint32_t s = cur_px[(y - cr.y) * cur_w + (x - cr.x)];   /* premultiplied ARGB */
            uint32_t a = s >> 24;
            if (!a) continue;
            uint32_t *d = &staging[(size_t)y * cap_w + x];
            if (a == 255) { *d = s & 0xffffff; continue; }
            uint32_t r = ((s >> 16) & 255) + ((*d >> 16) & 255) * (255 - a) / 255;
            uint32_t g = ((s >> 8) & 255) + ((*d >> 8) & 255) * (255 - a) / 255;
            uint32_t b = (s & 255) + (*d & 255) * (255 - a) / 255;
            *d = (r > 255 ? 255 : r) << 16 | (g > 255 ? 255 : g) << 8 | (b > 255 ? 255 : b);
        }
}

int capture_init(void)
{
    dpy = XOpenDisplay(NULL);
    if (!dpy) {
        fprintf(stderr, "Cannot open the X display (DISPLAY=%s). Run this inside your desktop session.\n",
                getenv("DISPLAY") ? getenv("DISPLAY") : "(not set)");
        return -1;
    }
    XSetErrorHandler(x_error);
    XSetIOErrorHandler(x_io_error);
    root = DefaultRootWindow(dpy);
    load_randr();
    int maj, min; Bool pix;
    use_shm = XShmQueryVersion(dpy, &maj, &min, &pix) ? 1 : 0;
    int erb;
    have_xfixes = XFixesQueryExtension(dpy, &fixes_ev, &erb) ? 1 : 0;
    if (have_xfixes) XFixesSelectCursorInput(dpy, root, XFixesDisplayCursorNotifyMask);
    int dev, der;
    if (have_xfixes && XDamageQueryExtension(dpy, &dev, &der)) {
        damage_ev = dev;
        damage = XDamageCreate(dpy, root, XDamageReportNonEmpty);
        dregion = XFixesCreateRegion(dpy, NULL, 0);
        have_damage = damage != 0;
    }
    windows_init();
    if (pipe2(wake_pipe, O_CLOEXEC) == 0) {
        fcntl(wake_pipe[0], F_SETFL, O_NONBLOCK);
        fcntl(wake_pipe[1], F_SETFL, O_NONBLOCK);
    }
    int w, h;
    if (monitor_area(&mon_x, &mon_y, &w, &h, 1) < 0) return -1;
    if (alloc_image(w, h) < 0) return -1;
    if (grab_rect(0, 0, w, h) < 0) { fprintf(stderr, "Screen capture failed.\n"); return -1; }
    memcpy(prev_raw, raw, (size_t)w * h * 4);
    fetch_cursor_image();
    compose_tile(0, 0, w, h);
    fb_pixels = malloc((size_t)w * h * 4);
    memcpy(fb_pixels, staging, (size_t)w * h * 4);
    fb_w = w; fb_h = h;
    if (!have_xfixes) fprintf(stderr, "XFixes missing: the mouse pointer will not be drawn.\n");
    if (!have_damage) fprintf(stderr, "XDamage missing: checking the whole screen every frame (more CPU).\n");
    return 0;
}

static double now_s(void)
{
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

static void sleep_s(double d)
{
    if (d <= 0) return;
    struct timespec ts = { (time_t)d, (long)((d - (time_t)d) * 1e9) };
    nanosleep(&ts, NULL);
}

static void mark_rect(uint8_t *sel, int tx, int ty, int x, int y, int w, int h)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > cap_w) w = cap_w - x;
    if (y + h > cap_h) h = cap_h - y;
    if (w <= 0 || h <= 0) return;
    for (int j = y / TILE; j <= (y + h - 1) / TILE && j < ty; j++)
        for (int i = x / TILE; i <= (x + w - 1) / TILE && i < tx; i++) sel[j * tx + i] = 1;
}

/* Re-reads the screen and reallocates everything after a size or monitor change. */
static void resize_capture(int x, int y, int w, int h, unsigned req)
{
    free_image();
    mon_x = x; mon_y = y;
    if (alloc_image(w, h) < 0) { fprintf(stderr, "Out of memory\n"); exit(1); }
    if (grab_rect(0, 0, w, h) < 0) memset(raw, 0, (size_t)w * h * 4);
    memcpy(prev_raw, raw, (size_t)w * h * 4);
    compose_tile(0, 0, w, h);
    pthread_rwlock_wrlock(&fb_lock);
    free(fb_pixels);
    fb_pixels = malloc((size_t)w * h * 4);
    memcpy(fb_pixels, staging, (size_t)w * h * 4);
    fb_w = w; fb_h = h;
    pthread_rwlock_unlock(&fb_lock);
    logmsg("Screen size changed to %dx%d", w, h);
    clients_resized(w, h, req);
}

void *capture_thread(void *arg)
{
    (void)arg;
    double last_cap = 0, last_geom = now_s(), last_sweep = 0, distrust_until = 0;
    int sweep_row = 0, missed = 0;
    double missed_since = 0;
    int tx = 0, ty = 0;
    uint8_t *sel = NULL, *changed = NULL, *damaged = NULL;
    rect_t last_cursor = {0, 0, 0, 0};
    uint8_t *residual = NULL;
    double last_damage = 0;
    int force_full = 1;
    for (;;) {
        pthread_mutex_lock(&clients_mu);
        while (nclients == 0 && !geom_now) { pthread_cond_wait(&clients_cv, &clients_mu); force_full = 1; }
        pthread_mutex_unlock(&clients_mu);

        double interval = 1.0 / g_opt.fps;
        double t = now_s();
        if (t - last_cap < interval) sleep_s(interval - (t - last_cap));

        /* Wait for damage, a pointer change or a wake-up; poll the pointer and sweep at the frame rate. */
        int damage_pending = 0, cursor_changed = 0;
        int polling = !have_damage || now_s() < distrust_until;
        if (!polling && !force_full && !XPending(dpy)) {
            struct pollfd pfd[2] = {{ConnectionNumber(dpy), POLLIN, 0}, {wake_pipe[0], POLLIN, 0}};
            poll(pfd, wake_pipe[0] >= 0 ? 2 : 1, (int)(interval * 1000) + 1);
            if (pfd[1].revents & POLLIN) { char b[64]; while (read(wake_pipe[0], b, sizeof b) > 0) { } }
        }
        while (XPending(dpy)) {
            XEvent e;
            XNextEvent(dpy, &e);
            if (have_damage && e.type == damage_ev + XDamageNotify) damage_pending = 1;
            else if (have_xfixes && e.type == fixes_ev + XFixesCursorNotify) cursor_changed = 1;
            else window_event(&e);
        }
        t = now_s();
        last_cap = t;

        if (geom_now || t - last_geom > 2.0) {
            last_geom = t;
            unsigned req = 0;
            if (geom_now) {
                pthread_mutex_lock(&clients_mu);
                req = geom_requester; geom_now = 0; geom_requester = 0;
                pthread_mutex_unlock(&clients_mu);
            }
            int x, y, w, h;
            if (monitor_area(&x, &y, &w, &h, 0) == 0 && (w != cap_w || h != cap_h || x != mon_x || y != mon_y)) {
                resize_capture(x, y, w, h, req);
                force_full = 1;
                continue;
            }
            if (req) clients_xds_reply(req, 0);   /* size did not change: still answer the viewer */
        }

        int ntx = (cap_w + TILE - 1) / TILE, nty = (cap_h + TILE - 1) / TILE;
        if (ntx != tx || nty != ty) {
            free(sel); free(changed); free(damaged); free(residual);
            tx = ntx; ty = nty;
            sel = malloc((size_t)tx * ty); changed = malloc((size_t)tx * ty); damaged = malloc((size_t)tx * ty);
            residual = malloc((size_t)tx * ty);
            sweep_row = 0;   /* the old row may be past the end of a smaller grid */
            force_full = 1;
        }
        memset(sel, 0, (size_t)tx * ty);
        memset(damaged, 0, (size_t)tx * ty);

        /* Which areas to fetch from the X server. */
        if (force_full || polling) {
            memset(sel, 1, (size_t)tx * ty);
            if (have_damage) XDamageSubtract(dpy, damage, None, None);
        } else {
            if (damage_pending) {
                last_damage = t;
                XDamageSubtract(dpy, damage, None, dregion);
                int n = 0;
                XRectangle *rs = XFixesFetchRegion(dpy, dregion, &n);
                for (int i = 0; i < n; i++) mark_rect(damaged, tx, ty, rs[i].x - mon_x, rs[i].y - mon_y, rs[i].width, rs[i].height);
                if (rs) XFree(rs);
                memcpy(sel, damaged, (size_t)tx * ty);
            }
            /* Safety net: re-read one band of tiles every 50 ms. */
            if (t - last_sweep > 0.05) {
                last_sweep = t;
                for (int i = 0; i < tx; i++) sel[sweep_row * tx + i] = 1;
                sweep_row = (sweep_row + 1) % ty;
            }
        }
        /* Pointer: redraw where it was and where it is. */
        rect_t ptr_old = last_cursor;   /* where the viewers' picture has the pointer */
        if (have_xfixes) {
            if (cursor_changed) fetch_cursor_image();
            else if (cur_valid) {
                Window rr, cr; int rx, ry, wx, wy; unsigned mask;
                if (XQueryPointer(dpy, root, &rr, &cr, &rx, &ry, &wx, &wy, &mask)) { cur_x = rx; cur_y = ry; }
            }
            rect_t now_r = cursor_rect();
            if (cursor_changed || now_r.x != last_cursor.x || now_r.y != last_cursor.y || force_full) {
                mark_rect(sel, tx, ty, last_cursor.x, last_cursor.y, last_cursor.w, last_cursor.h);
                mark_rect(sel, tx, ty, now_r.x, now_r.y, now_r.w, now_r.h);
                /* the pointer's own tiles need no fetch, only re-composing; fetching them is cheap */
            }
            last_cursor = now_r;
        }
        int full_grab = force_full || polling;
        force_full = 0;

        /* Mostly-changed screens are fetched as one rectangle: one X request is one consistent picture,
           while many requests can catch an application halfway through a redraw (a scroll torn in
           two cannot be sent as a CopyRect). */
        int nsel = 0, bi0 = tx, bi1 = -1, bj0 = ty, bj1 = -1;
        for (int j = 0; j < ty; j++)
            for (int i = 0; i < tx; i++)
                if (sel[j * tx + i]) {
                    nsel++;
                    if (i < bi0) bi0 = i;
                    if (i > bi1) bi1 = i;
                    if (j < bj0) bj0 = j;
                    if (j > bj1) bj1 = j;
                }
        if (!nsel) continue;
        if (nsel * 2 >= (bi1 - bi0 + 1) * (bj1 - bj0 + 1))
            for (int j = bj0; j <= bj1; j++) memset(sel + j * tx + bi0, 1, (size_t)(bi1 - bi0 + 1));
        /* Fetch the selected tiles: horizontal runs, merged with the rows below that have the same run. */
        memcpy(residual, sel, (size_t)tx * ty);   /* scratch: tiles not fetched yet */
        for (int j = 0; j < ty; j++)
            for (int i = 0; i < tx; i++) {
                if (!residual[j * tx + i]) continue;
                int i1 = i;
                while (i1 + 1 < tx && residual[j * tx + i1 + 1]) i1++;
                int j1 = j;
                while (j1 + 1 < ty) {
                    const uint8_t *r = residual + (j1 + 1) * tx;
                    int same = (i == 0 || !r[i - 1]) && (i1 + 1 >= tx || !r[i1 + 1]);
                    for (int k = i; k <= i1 && same; k++) same = r[k];
                    if (!same) break;
                    j1++;
                }
                for (int jj = j; jj <= j1; jj++) memset(residual + jj * tx + i, 0, (size_t)(i1 - i + 1));
                int x0 = i * TILE, y0 = j * TILE;
                int x1 = (i1 + 1) * TILE > cap_w ? cap_w : (i1 + 1) * TILE, y1 = (j1 + 1) * TILE > cap_h ? cap_h : (j1 + 1) * TILE;
                grab_rect(x0, y0, x1 - x0, y1 - y0);
                i = i1;
            }

        /* Compose, compare with what the viewers have, and keep only real changes. */
        int nchanged = 0;
        memset(changed, 0, (size_t)tx * ty);
        for (int j = 0; j < ty; j++) {
            int y0 = j * TILE, y1 = y0 + TILE > cap_h ? cap_h : y0 + TILE;
            for (int i = 0; i < tx; i++) {
                if (!sel[j * tx + i]) continue;
                int x0 = i * TILE, x1 = x0 + TILE > cap_w ? cap_w : x0 + TILE;
                compose_tile(x0, y0, x1, y1);
                int diff = 0;
                for (int y = y0; y < y1 && !diff; y++)
                    diff = memcmp(staging + (size_t)y * cap_w + x0, fb_pixels + (size_t)y * cap_w + x0, (size_t)(x1 - x0) * 4) != 0;
                if (diff) {
                    changed[j * tx + i] = 1; nchanged++;
                    /* A change nobody reported (not damage, not the pointer) means damage is unreliable here. */
                    if (have_damage && !full_grab && !damaged[j * tx + i] && t - last_damage > 0.25 && t >= distrust_until) {
                        rect_t cr = cursor_rect(), tr = {x0, y0, x1 - x0, y1 - y0};
                        int near_cursor = !(cr.x + cr.w + TILE <= tr.x || tr.x + tr.w + TILE <= cr.x || cr.y + cr.h + TILE <= tr.y || tr.y + tr.h + TILE <= cr.y);
                        if (!near_cursor) {
                            if (t - missed_since > 10) { missed = 0; missed_since = t; }
                            if (++missed >= 3) {
                                logmsg("Screen damage reports look incomplete; checking the whole screen for a while");
                                distrust_until = t + 30; missed = 0;
                            }
                        }
                    }
                }
            }
        }
        /* Window positions as of this frame; a moved window is a CopyRect candidate. */
        copy_op ops[CR_MAX_OPS];
        int nops = 0;
        for (int k = 0; k < nwins; k++) {
            wtrack *w = &wins[k];
            if (nchanged && w->mapped && (w->x != w->cx || w->y != w->cy) && w->w == w->cw && w->h == w->ch &&
                (nops == 0 || (ops[0].dx == w->x - w->cx && ops[0].dy == w->y - w->cy)))
                cr_verify_move(raw, prev_raw, cap_w, cap_h, w->x - mon_x, w->y - mon_y, w->w, w->h,
                               w->x - w->cx, w->y - w->cy, ops, &nops, CR_MAX_OPS);
            w->cx = w->x; w->cy = w->y; w->cw = w->w; w->ch = w->h;
        }
        if (nchanged && nops == 0) cr_detect_scroll(raw, prev_raw, cap_w, cap_h, changed, tx, ty, TILE, ops, &nops, CR_MAX_OPS);
        /* raw only changed in the fetched tiles: bring prev_raw up to date for the next frame. */
        for (int j = 0; j < ty; j++) {
            int y0 = j * TILE, y1 = y0 + TILE > cap_h ? cap_h : y0 + TILE;
            for (int i = 0; i < tx; i++) {
                if (!sel[j * tx + i]) continue;
                int i1 = i;
                while (i1 + 1 < tx && sel[j * tx + i1 + 1]) i1++;
                int x0 = i * TILE, x1 = (i1 + 1) * TILE > cap_w ? cap_w : (i1 + 1) * TILE;
                for (int y = y0; y < y1; y++)
                    memcpy(prev_raw + (size_t)y * cap_w + x0, raw + (size_t)y * cap_w + x0, (size_t)(x1 - x0) * 4);
                i = i1;
            }
        }
        if (!nchanged) continue;
        cr_order(ops, nops);
        cr_residual(ops, nops, changed, residual, tx, ty, TILE, cap_w, cap_h);
        /* The copies were checked without the pointer. A viewer's copy also moves the old pointer image
           (to old position + shift) and lands under the new pointer: resend those tiles. */
        for (int k = 0; k < nops; k++) {
            mark_rect(residual, tx, ty, ptr_old.x + ops[k].dx, ptr_old.y + ops[k].dy, ptr_old.w, ptr_old.h);
            mark_rect(residual, tx, ty, last_cursor.x, last_cursor.y, last_cursor.w, last_cursor.h);
        }
        pthread_rwlock_wrlock(&fb_lock);
        for (int j = 0; j < ty; j++) {
            int y0 = j * TILE, y1 = y0 + TILE > cap_h ? cap_h : y0 + TILE;
            for (int i = 0; i < tx; i++) {
                if (!changed[j * tx + i]) continue;
                int x0 = i * TILE, x1 = x0 + TILE > cap_w ? cap_w : x0 + TILE;
                for (int y = y0; y < y1; y++)
                    memcpy(fb_pixels + (size_t)y * cap_w + x0, staging + (size_t)y * cap_w + x0, (size_t)(x1 - x0) * 4);
            }
        }
        fb_gen++;
        pthread_rwlock_unlock(&fb_lock);
        clients_frame(changed, residual, ops, nops, tx, ty);
    }
    return NULL;
}
