/* Quest VNC Server for Linux: RFB server with sound over the QEMU audio extension.
   See ../../SPEC.md for the protocol details shared with the Windows and macOS versions. */
#define _GNU_SOURCE
#include "common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <poll.h>
#include <ifaddrs.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <limits.h>
#include <pwd.h>
#include <sys/random.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <X11/Xlib.h>

#define VERSION QVNC_VERSION_STR

options_t g_opt = { .port = 5900, .fps = 30 };
pthread_mutex_t clients_mu = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t clients_cv = PTHREAD_COND_INITIALIZER;
client_t *clients;
int nclients;
static char desktop_name[300];
static volatile sig_atomic_t quit_flag;
static unsigned next_client_id = 1;
static int log_to_file;   /* --background: stdout is the log file, kept under LOG_MAX */

#define LOG_MAX (1024 * 1024)

#define AUDIO_MAX_MS 250

void logmsg(const char *fmt, ...)
{
    char ts[32]; time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
    strftime(ts, sizeof ts, "%H:%M:%S", &tm);
    va_list ap; va_start(ap, fmt);
    flockfile(stdout);
    printf("[%s] ", ts); vprintf(fmt, ap); printf("\n"); fflush(stdout);
    struct stat st;
    if (log_to_file && fstat(1, &st) == 0 && st.st_size > LOG_MAX && ftruncate(1, 0) == 0)
        printf("[%s] (log truncated at 1 MB)\n", ts);
    funlockfile(stdout);
    va_end(ap);
}

/* ------------------------------------------------------------------ socket helpers */

static int read_full(int fd, void *b, size_t n)
{
    size_t got = 0;
    while (got < n) {
        ssize_t r = recv(fd, (char *)b + got, n - got, 0);
        if (r < 0 && errno == EINTR) continue;
        if (r <= 0) return -1;
        got += (size_t)r;
    }
    return 0;
}

static int write_full(int fd, const void *b, size_t n)
{
    size_t done = 0;
    while (done < n) {
        ssize_t r = send(fd, (const char *)b + done, n - done, MSG_NOSIGNAL);
        if (r < 0 && errno == EINTR) continue;
        if (r <= 0) return -1;
        done += (size_t)r;
    }
    return 0;
}

/* Own number parsing: glibc 2.38 headers would otherwise bind atoi/sscanf to new symbol versions. */
static int parse_int(const char *s, int len)
{
    int v = 0, neg = 0, i = 0, any = 0;
    while (i < len && s[i] == ' ') i++;
    if (i < len && (s[i] == '-' || s[i] == '+')) neg = s[i++] == '-';
    for (; i < len && s[i] >= '0' && s[i] <= '9'; i++) { v = v * 10 + (s[i] - '0'); any = 1; if (v > 1000000) break; }
    return any ? (neg ? -v : v) : -1;
}
static int arg_int(const char *s) { return parse_int(s, (int)strlen(s)); }

static uint16_t rd16(const uint8_t *p) { return (uint16_t)(p[0] << 8 | p[1]); }
static uint32_t rd32(const uint8_t *p) { return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3]; }

/* ------------------------------------------------------------------ rect helpers */

static rect_t rect_union(rect_t a, rect_t b)
{
    if (a.w <= 0 || a.h <= 0) return b;
    if (b.w <= 0 || b.h <= 0) return a;
    int x0 = a.x < b.x ? a.x : b.x, y0 = a.y < b.y ? a.y : b.y;
    int x1 = a.x + a.w > b.x + b.w ? a.x + a.w : b.x + b.w;
    int y1 = a.y + a.h > b.y + b.h ? a.y + a.h : b.y + b.h;
    return (rect_t){x0, y0, x1 - x0, y1 - y0};
}

static rect_t rect_clip(rect_t a, rect_t b)
{
    int x0 = a.x > b.x ? a.x : b.x, y0 = a.y > b.y ? a.y : b.y;
    int x1 = a.x + a.w < b.x + b.w ? a.x + a.w : b.x + b.w;
    int y1 = a.y + a.h < b.y + b.h ? a.y + a.h : b.y + b.h;
    if (x1 <= x0 || y1 <= y0) return (rect_t){0, 0, 0, 0};
    return (rect_t){x0, y0, x1 - x0, y1 - y0};
}

/* ------------------------------------------------------------------ hooks from capture/audio/clipboard */

static void client_alloc_dirty(client_t *c, int w, int h, int all)
{
    int tx = (w + TILE - 1) / TILE, ty = (h + TILE - 1) / TILE;
    if (tx != c->tiles_x || ty != c->tiles_y || !c->dirty) {
        free(c->dirty);
        c->dirty = calloc((size_t)tx * ty, 1);
        c->tiles_x = tx; c->tiles_y = ty;
        all = 1;
    }
    if (all) { memset(c->dirty, 1, (size_t)tx * ty); c->ncopies = 0; }
}

/* Can this viewer take the frame's CopyRects? They are queued after any copies it has not been sent
   yet and applied to its picture in that order. Refused while an update is being written (its tiles
   may hold this frame or the previous one) or when a sent update already held this frame. */
static int client_accepts_copies(client_t *c, const copy_op *ops, int nops)
{
    if (!nops || !c->has_copyrect || c->inflight || c->last_grab_gen >= fb_gen || c->ncopies + nops > CR_MAX_OPS) return 0;
    for (int k = 0; k < nops; k++) {
        const copy_op *o = &ops[k];
        int sx = o->x - o->dx, sy = o->y - o->dy;
        if (o->x + o->w > c->cw || o->y + o->h > c->ch || sx < 0 || sy < 0 || sx + o->w > c->cw || sy + o->h > c->ch) return 0;
    }
    return 1;
}

/* A copy whose source touches a tile the viewer has not been sent yet copies stale pixels:
   that destination tile is sent again after the copies. */
static void mark_stale_copies(client_t *c, const copy_op *ops, int nops)
{
    int tx = c->tiles_x, ty = c->tiles_y;
    for (int k = 0; k < nops; k++) {
        const copy_op *o = &ops[k];
        for (int j = o->y / TILE; j <= (o->y + o->h - 1) / TILE && j < ty; j++)
            for (int i = o->x / TILE; i <= (o->x + o->w - 1) / TILE && i < tx; i++) {
                if (c->dirty[j * tx + i]) continue;
                /* the part of tile (i, j) this copy writes, moved back to where it comes from */
                int x0 = i * TILE > o->x ? i * TILE : o->x, y0 = j * TILE > o->y ? j * TILE : o->y;
                int x1 = (i + 1) * TILE < o->x + o->w ? (i + 1) * TILE : o->x + o->w;
                int y1 = (j + 1) * TILE < o->y + o->h ? (j + 1) * TILE : o->y + o->h;
                x0 -= o->dx; x1 -= o->dx; y0 -= o->dy; y1 -= o->dy;
                int stale = 0;
                for (int sj = y0 / TILE; sj <= (y1 - 1) / TILE && sj < ty && !stale; sj++)
                    for (int si = x0 / TILE; si <= (x1 - 1) / TILE && si < tx && !stale; si++)
                        stale = c->dirty[sj * tx + si] == 1;
                if (stale) c->dirty[j * tx + i] = 2;   /* 2: marked here, not a source of staleness itself */
            }
    }
    for (int i = 0; i < tx * ty; i++) if (c->dirty[i]) c->dirty[i] = 1;
}

void clients_frame(const uint8_t *changed, const uint8_t *residual, const copy_op *ops, int nops, int tx, int ty)
{
    pthread_mutex_lock(&clients_mu);
    for (client_t *c = clients; c; c = c->next) {
        pthread_mutex_lock(&c->mu);
        if (c->dirty && tx == c->tiles_x && ty == c->tiles_y) {
            const uint8_t *mark = changed;
            if (client_accepts_copies(c, ops, nops)) {
                mark_stale_copies(c, ops, nops);
                memcpy(c->copies + c->ncopies, ops, sizeof *ops * (size_t)nops);
                c->ncopies += nops;
                mark = residual;
            }
            for (int i = 0; i < tx * ty; i++) c->dirty[i] |= mark[i];
        } else {
            client_alloc_dirty(c, fb_w, fb_h, 1);
        }
        pthread_cond_signal(&c->cv);
        pthread_mutex_unlock(&c->mu);
    }
    pthread_mutex_unlock(&clients_mu);
}

static void queue_xds(client_t *c, int reason, int status, int w, int h)
{
    if (c->nxq == 8) { memmove(c->xq, c->xq + 1, sizeof c->xq[0] * 7); c->nxq--; }
    c->xq[c->nxq].reason = reason; c->xq[c->nxq].status = status;
    c->xq[c->nxq].w = w; c->xq[c->nxq].h = h;
    c->nxq++;
    pthread_cond_signal(&c->cv);
}

void clients_resized(int w, int h, unsigned requester)
{
    pthread_mutex_lock(&clients_mu);
    for (client_t *c = clients; c; c = c->next) {
        pthread_mutex_lock(&c->mu);
        client_alloc_dirty(c, w, h, 1);
        if (c->xds) queue_xds(c, requester ? (c->id == requester ? 1 : 2) : 0, 0, w, h);
        else if (c->has_desktopsize) c->need_desktopsize = 1;
        pthread_cond_signal(&c->cv);
        pthread_mutex_unlock(&c->mu);
    }
    pthread_mutex_unlock(&clients_mu);
}

void clients_xds_reply(unsigned requester, int status)
{
    pthread_mutex_lock(&clients_mu);
    for (client_t *c = clients; c; c = c->next) {
        if (c->id != requester) continue;
        pthread_mutex_lock(&c->mu);
        queue_xds(c, 1, status, fb_w, fb_h);
        pthread_mutex_unlock(&c->mu);
    }
    pthread_mutex_unlock(&clients_mu);
}

void clients_cut_text(const char *latin1, size_t len, client_t *except)
{
    pthread_mutex_lock(&clients_mu);
    for (client_t *c = clients; c; c = c->next) {
        if (c == except) continue;
        pthread_mutex_lock(&c->mu);
        free(c->cut);
        c->cut = malloc(len + 1); memcpy(c->cut, latin1, len); c->cutlen = len; c->cut_pending = 1;
        pthread_cond_signal(&c->cv);
        pthread_mutex_unlock(&c->mu);
    }
    pthread_mutex_unlock(&clients_mu);
}

static int sample_bytes(int fmt) { return fmt <= 1 ? 1 : fmt <= 3 ? 2 : 4; }

static void put_sample(uint8_t *d, int fmt, int v)
{
    switch (fmt) {
    case 0: d[0] = (uint8_t)((v >> 8) + 128); break;
    case 1: d[0] = (uint8_t)(int8_t)(v >> 8); break;
    case 2: { uint16_t u = (uint16_t)(v + 32768); d[0] = (uint8_t)u; d[1] = (uint8_t)(u >> 8); break; }
    case 3: d[0] = (uint8_t)v; d[1] = (uint8_t)((uint16_t)v >> 8); break;
    case 4: { uint32_t u = (uint32_t)(v + 32768) << 16; d[0] = 0; d[1] = 0; d[2] = (uint8_t)(u >> 16); d[3] = (uint8_t)(u >> 24); break; }
    default: { uint32_t u = (uint32_t)v << 16; d[0] = 0; d[1] = 0; d[2] = (uint8_t)(u >> 16); d[3] = (uint8_t)(u >> 24); break; }
    }
}

/* Linear-interpolation resampling and format conversion into the client's audio queue. Caller holds c->mu. */
static void client_push_audio(client_t *c, const int16_t *pcm, int frames)
{
    double step = (double)AUDIO_RATE / c->arate;
    int sb = sample_bytes(c->afmt), fb = sb * c->achan;
    int maxout = (int)(frames / step) + 4;
    buf_reserve(&c->aq, (size_t)maxout * fb);
    uint8_t *d = c->aq.p + c->aq.len;
    int out = 0;
    double pos = c->rs_pos;
    while (pos <= frames - 1 && out < maxout) {
        int i = (int)(pos < 0 ? -1 : pos);
        double f = pos - i;
        int s[2];
        for (int ch = 0; ch < 2; ch++) {
            int a = i < 0 ? c->rs_prev[ch] : pcm[i * 2 + ch];
            int b = (i + 1 <= frames - 1) ? pcm[(i + 1) * 2 + ch] : a;
            s[ch] = (int)(a + (b - a) * f);
        }
        for (int ch = 0; ch < c->achan; ch++) {
            int v = c->achan == 1 ? (s[0] + s[1]) / 2 : s[ch & 1];
            put_sample(d, c->afmt, v);
            d += sb;
        }
        out++;
        pos += step;
    }
    c->rs_pos = pos - frames;
    c->rs_prev[0] = pcm[(frames - 1) * 2]; c->rs_prev[1] = pcm[(frames - 1) * 2 + 1];
    c->aq.len += (size_t)out * fb;
    /* Too far behind: drop the oldest audio. */
    size_t limit = (size_t)c->arate * fb * AUDIO_MAX_MS / 1000;
    if (c->aq.len > limit) {
        size_t drop = c->aq.len - limit;
        drop -= drop % fb;
        memmove(c->aq.p, c->aq.p + drop, c->aq.len - drop);
        c->aq.len -= drop;
    }
}

void clients_audio(const int16_t *pcm, int frames)
{
    pthread_mutex_lock(&clients_mu);
    for (client_t *c = clients; c; c = c->next) {
        pthread_mutex_lock(&c->mu);
        if (c->audio_on) { client_push_audio(c, pcm, frames); pthread_cond_signal(&c->cv); }
        pthread_mutex_unlock(&c->mu);
    }
    pthread_mutex_unlock(&clients_mu);
}

/* ------------------------------------------------------------------ writer thread */

/* Builds the rects to send for the pending request. Caller holds c->mu. Returns count. */
static int collect_rects(client_t *c, rect_t *out, int max)
{
    rect_t screen = {0, 0, c->cw < fb_w ? c->cw : fb_w, c->ch < fb_h ? c->ch : fb_h};
    rect_t req = rect_clip(c->req, screen);
    int n = 0;
    if (req.w <= 0) return 0;
    int tx = c->tiles_x, ty = c->tiles_y;
    uint8_t *sel = calloc((size_t)tx * ty, 1);
    for (int j = 0; j < ty; j++)
        for (int i = 0; i < tx; i++) {
            rect_t t = {i * TILE, j * TILE, TILE, TILE};
            int forced = c->force_set && rect_clip(t, c->force).w > 0;
            if ((c->dirty[j * tx + i] || forced) && rect_clip(t, req).w > 0) {
                sel[j * tx + i] = 1;
                /* Clear the dirty flag only when the request covers the whole tile. */
                rect_t inside = rect_clip(rect_clip(t, screen), req);
                rect_t full = rect_clip(t, screen);
                if (inside.w == full.w && inside.h == full.h) c->dirty[j * tx + i] = 0;
            }
        }
    /* Horizontal runs per tile row, merged with identical runs in the rows below. */
    for (int j = 0; j < ty; j++)
        for (int i = 0; i < tx; i++) {
            if (sel[j * tx + i] != 1) continue;
            int i1 = i;
            while (i1 + 1 < tx && sel[j * tx + i1 + 1] == 1) i1++;
            int j1 = j;
            for (;;) {
                if (j1 + 1 >= ty) break;
                int okrow = (i == 0 || sel[(j1 + 1) * tx + i - 1] != 1) && (i1 + 1 >= tx || sel[(j1 + 1) * tx + i1 + 1] != 1);
                for (int k = i; k <= i1 && okrow; k++) okrow = sel[(j1 + 1) * tx + k] == 1;
                if (!okrow) break;
                j1++;
            }
            for (int jj = j; jj <= j1; jj++) for (int k = i; k <= i1; k++) sel[jj * tx + k] = 2;
            rect_t r = rect_clip((rect_t){i * TILE, j * TILE, (i1 - i + 1) * TILE, (j1 - j + 1) * TILE}, req);
            if (r.w > 0 && n < max) out[n++] = r;
            i = i1;
        }
    free(sel);
    c->force_set = 0;
    c->req_pending = 0;
    c->req = (rect_t){0, 0, 0, 0};
    return n;
}

static int frame_ready(client_t *c)
{
    if (!c->req_pending) return 0;
    if (c->need_desktopsize || c->force_set || c->ncopies) return 1;
    rect_t req = c->req;
    for (int j = 0; j < c->tiles_y; j++)
        for (int i = 0; i < c->tiles_x; i++)
            if (c->dirty[j * c->tiles_x + i] && rect_clip((rect_t){i * TILE, j * TILE, TILE, TILE}, req).w > 0 &&
                i * TILE < c->cw && j * TILE < c->ch)
                return 1;
    return 0;
}

static void *writer_thread(void *arg)
{
    client_t *c = arg;
    buf_t o = {0};
    int max_rects = 4096;
    rect_t *rects = malloc(sizeof(rect_t) * max_rects);
    pthread_mutex_lock(&c->mu);
    while (c->alive) {
        o.len = 0;
        if (c->send_ack) {
            c->send_ack = 0;
            buf_u8(&o, 0); buf_u8(&o, 0); buf_u16(&o, 1);
            buf_u16(&o, 0); buf_u16(&o, 0); buf_u16(&o, 0); buf_u16(&o, 0); buf_u32(&o, (uint32_t)-259);
        }
        for (int i = 0; i < c->nxq; i++) {
            /* ExtendedDesktopSize: x = reason, y = status, one screen (id 0) covering the framebuffer */
            int w = c->xq[i].w, h = c->xq[i].h;
            buf_u8(&o, 0); buf_u8(&o, 0); buf_u16(&o, 1);
            buf_u16(&o, (uint16_t)c->xq[i].reason); buf_u16(&o, (uint16_t)c->xq[i].status);
            buf_u16(&o, (uint16_t)w); buf_u16(&o, (uint16_t)h); buf_u32(&o, (uint32_t)-308);
            buf_u8(&o, 1); buf_u8(&o, 0); buf_u16(&o, 0);
            buf_u32(&o, 0); buf_u16(&o, 0); buf_u16(&o, 0); buf_u16(&o, (uint16_t)w); buf_u16(&o, (uint16_t)h); buf_u32(&o, 0);
            if (w != c->cw || h != c->ch) {
                /* The viewer now uses this size: follow with a full update. */
                c->cw = w; c->ch = h;
                c->need_desktopsize = 0;
                client_alloc_dirty(c, fb_w, fb_h, 1);
                c->force = (rect_t){0, 0, w, h}; c->force_set = 1;
                if (c->req_pending) c->req = (rect_t){0, 0, w, h};
            }
        }
        c->nxq = 0;
        if (c->audio_end) {
            c->audio_end = 0;
            uint8_t m[4] = {255, 1, 0, 0}; buf_put(&o, m, 4);
        }
        if (c->audio_begin) {
            c->audio_begin = 0;
            uint8_t m[4] = {255, 1, 0, 1}; buf_put(&o, m, 4);
        }
        if (c->audio_on && c->aq.len) {
            /* data messages of at most 20 ms each */
            size_t fbytes = (size_t)sample_bytes(c->afmt) * c->achan;
            size_t chunk = (size_t)c->arate / 50 * fbytes;
            size_t off = 0;
            while (off < c->aq.len) {
                size_t n = c->aq.len - off < chunk ? c->aq.len - off : chunk;
                uint8_t m[4] = {255, 1, 0, 2}; buf_put(&o, m, 4);
                buf_u32(&o, (uint32_t)n);
                buf_put(&o, c->aq.p + off, n);
                off += n;
            }
            c->aq.len = 0;
        }
        if (c->cut_pending) {
            c->cut_pending = 0;
            buf_u8(&o, 3); buf_u8(&o, 0); buf_u16(&o, 0); buf_u32(&o, (uint32_t)c->cutlen);
            buf_put(&o, c->cut, c->cutlen);
        }
        if (o.len) {
            pthread_mutex_unlock(&c->mu);
            int r = write_full(c->fd, o.p, o.len);
            pthread_mutex_lock(&c->mu);
            if (r < 0) break;
            continue;
        }
        if (c->req_pending && c->need_desktopsize) {
            c->need_desktopsize = 0;
            c->req_pending = 0;
            c->req = (rect_t){0, 0, 0, 0};
            c->cw = fb_w; c->ch = fb_h;
            client_alloc_dirty(c, fb_w, fb_h, 1);
            buf_u8(&o, 0); buf_u8(&o, 0); buf_u16(&o, 1);
            buf_u16(&o, 0); buf_u16(&o, 0); buf_u16(&o, (uint16_t)c->cw); buf_u16(&o, (uint16_t)c->ch);
            buf_u32(&o, (uint32_t)-223);
            pthread_mutex_unlock(&c->mu);
            int r = write_full(c->fd, o.p, o.len);
            pthread_mutex_lock(&c->mu);
            if (r < 0) break;
            continue;
        }
        if (frame_ready(c)) {
            c->epf = c->pf; c->e_tight = c->use_tight; c->e_quality = c->quality; c->e_compress = c->compress;
            /* CopyRects go first; one that is not wanted now becomes an ordinary update. */
            copy_op cps[CR_MAX_OPS];
            int ncp = 0;
            rect_t req = c->req;
            for (int k = 0; k < c->ncopies; k++) {
                copy_op *op = &c->copies[k];
                if (c->has_copyrect && op->x >= req.x && op->y >= req.y && op->x + op->w <= req.x + req.w && op->y + op->h <= req.y + req.h) {
                    cps[ncp++] = *op;
                } else {
                    for (int j = op->y / TILE; j <= (op->y + op->h - 1) / TILE && j < c->tiles_y; j++)
                        for (int i = op->x / TILE; i <= (op->x + op->w - 1) / TILE && i < c->tiles_x; i++) c->dirty[j * c->tiles_x + i] = 1;
                }
            }
            if (ncp < c->ncopies) ncp = 0;   /* keep the set together: all or none (later ops may rely on earlier) */
            if (ncp == 0)
                for (int k = 0; k < c->ncopies; k++) {
                    copy_op *op = &c->copies[k];
                    for (int j = op->y / TILE; j <= (op->y + op->h - 1) / TILE && j < c->tiles_y; j++)
                        for (int i = op->x / TILE; i <= (op->x + op->w - 1) / TILE && i < c->tiles_x; i++) c->dirty[j * c->tiles_x + i] = 1;
                }
            c->ncopies = 0;
            int n = collect_rects(c, rects, max_rects);
            if (n == 0 && ncp == 0) continue;
            c->inflight = 1;
            c->grab_gen = 0;
            pthread_mutex_unlock(&c->mu);
            buf_u8(&o, 0); buf_u8(&o, 0); buf_u16(&o, 0);   /* rect count filled in below */
            int count = ncp;
            for (int k = 0; k < ncp; k++) {
                buf_u16(&o, (uint16_t)cps[k].x); buf_u16(&o, (uint16_t)cps[k].y);
                buf_u16(&o, (uint16_t)cps[k].w); buf_u16(&o, (uint16_t)cps[k].h); buf_u32(&o, 1);
                buf_u16(&o, (uint16_t)(cps[k].x - cps[k].dx)); buf_u16(&o, (uint16_t)(cps[k].y - cps[k].dy));
            }
            for (int i = 0; i < n; i++) count += encode_area(c, &o, rects[i]);
            o.p[2] = (uint8_t)(count >> 8); o.p[3] = (uint8_t)count;
            int r = write_full(c->fd, o.p, o.len);
            pthread_mutex_lock(&c->mu);
            if (c->grab_gen > c->last_grab_gen) c->last_grab_gen = c->grab_gen;
            c->inflight = 0;
            pthread_mutex_unlock(&c->mu);
            pthread_mutex_lock(&c->mu);
            if (r < 0) break;
            continue;
        }
        pthread_cond_wait(&c->cv, &c->mu);
    }
    c->alive = 0;
    pthread_mutex_unlock(&c->mu);
    shutdown(c->fd, SHUT_RDWR);
    buf_free(&o);
    free(rects);
    return NULL;
}

/* ------------------------------------------------------------------ handshake and reader */

static int handshake(client_t *c)
{
    const char *ver = "RFB 003.008\n";
    if (write_full(c->fd, ver, 12) < 0) return -1;
    char cv[13] = {0};
    if (read_full(c->fd, cv, 12) < 0) return -1;
    if (memcmp(cv, "RFB ", 4) != 0 || cv[7] != '.') { logmsg("%s: not a VNC viewer", c->addr); return -1; }
    int maj = parse_int(cv + 4, 3), min = parse_int(cv + 8, 3);
    if (maj < 0 || min < 0) { logmsg("%s: not a VNC viewer", c->addr); return -1; }
    int minor = (maj > 3 || min >= 8) ? 8 : (min == 7 ? 7 : 3);
    int sec = g_opt.has_password ? 2 : 1;
    if (minor == 3) {
        uint8_t t[4] = {0, 0, 0, (uint8_t)sec};
        if (write_full(c->fd, t, 4) < 0) return -1;
    } else {
        uint8_t t[2] = {1, (uint8_t)sec};
        if (write_full(c->fd, t, 2) < 0) return -1;
        uint8_t chosen;
        if (read_full(c->fd, &chosen, 1) < 0) return -1;
        if (chosen != sec) {
            if (minor == 8) {
                const char *why = "Security type not offered";
                uint8_t h[8] = {0, 0, 0, 1, 0, 0, 0, (uint8_t)strlen(why)};
                write_full(c->fd, h, 8); write_full(c->fd, why, strlen(why));
            }
            return -1;
        }
    }
    if (sec == 2) {
        uint8_t chal[16], resp[16], expect[16], key[8] = {0};
        if (getrandom(chal, 16, 0) != 16) {
            for (int i = 0; i < 16; i++) chal[i] = (uint8_t)(rand() ^ (time(NULL) >> (i & 7)));
        }
        for (int i = 0; i < 8 && g_opt.password[i]; i++) {
            uint8_t b = (uint8_t)g_opt.password[i], r = 0;
            for (int k = 0; k < 8; k++) if (b & (1 << k)) r |= (uint8_t)(0x80 >> k);
            key[i] = r;
        }
        des_encrypt_ecb(key, chal, expect, 16);
        if (write_full(c->fd, chal, 16) < 0) return -1;
        if (read_full(c->fd, resp, 16) < 0) return -1;
        int diff = 0;
        for (int i = 0; i < 16; i++) diff |= resp[i] ^ expect[i];
        if (diff) {
            logmsg("%s: wrong password", c->addr);
            uint8_t fail[4] = {0, 0, 0, 1};
            write_full(c->fd, fail, 4);
            if (minor == 8) {
                const char *why = "Authentication failed";
                uint8_t h[4] = {0, 0, 0, (uint8_t)strlen(why)};
                write_full(c->fd, h, 4); write_full(c->fd, why, strlen(why));
            }
            sleep(1);
            return -1;
        }
        uint8_t okr[4] = {0, 0, 0, 0};
        if (write_full(c->fd, okr, 4) < 0) return -1;
    } else if (minor == 8) {
        uint8_t okr[4] = {0, 0, 0, 0};
        if (write_full(c->fd, okr, 4) < 0) return -1;
    }
    uint8_t shared;
    if (read_full(c->fd, &shared, 1) < 0) return -1;   /* ignored: always shared */

    buf_t o = {0};
    pthread_rwlock_rdlock(&fb_lock);
    c->cw = fb_w; c->ch = fb_h;
    pthread_rwlock_unlock(&fb_lock);
    buf_u16(&o, (uint16_t)c->cw); buf_u16(&o, (uint16_t)c->ch);
    uint8_t pf[16] = {32, 24, 0, 1, 0, 255, 0, 255, 0, 255, 16, 8, 0, 0, 0, 0};
    buf_put(&o, pf, 16);
    buf_u32(&o, (uint32_t)strlen(desktop_name));
    buf_put(&o, desktop_name, strlen(desktop_name));
    int r = write_full(c->fd, o.p, o.len);
    buf_free(&o);
    return r;
}

static void client_free(client_t *c)
{
    free(c->dirty); free(c->cut); buf_free(&c->aq);
    encode_free(c);
    pthread_mutex_destroy(&c->mu); pthread_cond_destroy(&c->cv);
    close(c->fd);
    free(c);
}

static int handle_messages(client_t *c)
{
    uint8_t t;
    for (;;) {
        if (read_full(c->fd, &t, 1) < 0) return 0;
        switch (t) {
        case 0: {   /* SetPixelFormat */
            uint8_t m[19];
            if (read_full(c->fd, m, 19) < 0) return 0;
            pixfmt_t f = {m[3], m[4], m[5] != 0, m[6] != 0, rd16(m + 7), rd16(m + 9), rd16(m + 11), m[13], m[14], m[15]};
            if (!f.true_colour || (f.bpp != 8 && f.bpp != 16 && f.bpp != 32) || !f.rmax || !f.gmax || !f.bmax) {
                logmsg("%s: unsupported pixel format (%d bpp, true colour %d), closing", c->addr, f.bpp, f.true_colour);
                return -1;
            }
            pthread_mutex_lock(&c->mu);
            c->pf = f;
            pthread_mutex_unlock(&c->mu);
            break;
        }
        case 2: {   /* SetEncodings */
            uint8_t m[3];
            if (read_full(c->fd, m, 3) < 0) return 0;
            int n = rd16(m + 1);
            uint8_t *e = malloc((size_t)n * 4 + 1);
            if (read_full(c->fd, e, (size_t)n * 4) < 0) { free(e); return 0; }
            int tight = 0, q = -1, comp = 6, ds = 0, audio = 0, xds = 0, copyrect = 0;
            for (int i = 0; i < n; i++) {
                int32_t v = (int32_t)rd32(e + 4 * i);
                if (v == 7) tight = 1;
                else if (v == 1) copyrect = 1;
                else if (v >= -32 && v <= -23) q = v + 32;
                else if (v >= -256 && v <= -247) comp = v + 256;
                else if (v == -223) ds = 1;
                else if (v == -259) audio = 1;
                else if (v == -308) xds = 1;
            }
            free(e);
            pthread_mutex_lock(&c->mu);
            c->has_copyrect = copyrect;
            c->use_tight = tight; c->quality = q; c->compress = comp; c->has_desktopsize = ds;
            c->wants_audio_enc = audio;
            if (audio && audio_ok) { c->send_ack = 1; pthread_cond_signal(&c->cv); }
            c->xds = xds;
            if (xds) {
                pthread_rwlock_rdlock(&fb_lock);
                queue_xds(c, 0, 0, fb_w, fb_h);
                pthread_rwlock_unlock(&fb_lock);
            }
            pthread_mutex_unlock(&c->mu);
            break;
        }
        case 3: {   /* FramebufferUpdateRequest */
            uint8_t m[9];
            if (read_full(c->fd, m, 9) < 0) return 0;
            rect_t r = {rd16(m + 1), rd16(m + 3), rd16(m + 5), rd16(m + 7)};
            pthread_mutex_lock(&c->mu);
            r = rect_clip(r, (rect_t){0, 0, c->cw, c->ch});
            if (r.w > 0) {
                c->req = rect_union(c->req, r);
                c->req_pending = 1;
                if (!m[0]) { c->force = c->force_set ? rect_union(c->force, r) : r; c->force_set = 1; }
                pthread_cond_signal(&c->cv);
            }
            pthread_mutex_unlock(&c->mu);
            break;
        }
        case 4: {   /* KeyEvent */
            uint8_t m[7];
            if (read_full(c->fd, m, 7) < 0) return 0;
            input_key(c, m[0], rd32(m + 3));
            break;
        }
        case 5: {   /* PointerEvent */
            uint8_t m[5];
            if (read_full(c->fd, m, 5) < 0) return 0;
            input_pointer(c, m[0], rd16(m + 1), rd16(m + 3));
            break;
        }
        case 6: {   /* ClientCutText */
            uint8_t m[7];
            if (read_full(c->fd, m, 7) < 0) return 0;
            uint32_t len = rd32(m + 3);
            if (len & 0x80000000u) { logmsg("%s: extended clipboard not supported, closing", c->addr); return -1; }
            if (len > (64u << 20)) return -1;
            char *s = malloc(len + 1);
            if (read_full(c->fd, s, len) < 0) { free(s); return 0; }
            if (!g_opt.view_only) {
                clipboard_set_from_viewer(s, len);
                clients_cut_text(s, len, c);
            }
            free(s);
            break;
        }
        case 251: { /* SetDesktopSize */
            uint8_t m[7];
            if (read_full(c->fd, m, 7) < 0) return 0;
            int w = rd16(m + 1), h = rd16(m + 3), n = m[5];
            uint8_t scr[16];
            for (int i = 0; i < n; i++) if (read_full(c->fd, scr, 16) < 0) return 0;
            int status, nw = 0, nh = 0;
            if (g_opt.view_only || g_opt.no_resize) status = 1;
            else if (w < 1 || h < 1) status = 3;
            else status = resize_request(c, w, h, &nw, &nh);
            if (status == 0) {
                logmsg("Resolution %dx%d requested by %s; set to %dx%d", w, h, c->addr, nw, nh);
                capture_geometry_now(c->id);   /* answers the viewer (reason 1) and tells the others (reason 2) */
            } else {
                static const char *why[] = {"", "not allowed", "the change failed", "no suitable display mode"};
                logmsg("Resolution %dx%d requested by %s; refused (%s)", w, h, c->addr, why[status]);
                pthread_mutex_lock(&c->mu);
                pthread_rwlock_rdlock(&fb_lock);
                queue_xds(c, 1, status, fb_w, fb_h);
                pthread_rwlock_unlock(&fb_lock);
                pthread_mutex_unlock(&c->mu);
            }
            break;
        }
        case 255: { /* QEMU client message */
            uint8_t sub;
            if (read_full(c->fd, &sub, 1) < 0) return 0;
            if (sub == 1) {
                uint8_t m[2];
                if (read_full(c->fd, m, 2) < 0) return 0;
                int op = rd16(m);
                pthread_mutex_lock(&c->mu);
                if (op == 0) {
                    if (audio_ok && !c->audio_on) {
                        c->audio_on = 1; c->audio_begin = 1; c->aq.len = 0; c->rs_pos = 0;
                        c->rs_prev[0] = c->rs_prev[1] = 0;
                        logmsg("%s: sound on (%s, %d ch, %d Hz)", c->addr,
                               (const char *[]){"U8", "S8", "U16", "S16", "U32", "S32"}[c->afmt], c->achan, c->arate);
                    }
                } else if (op == 1) {
                    if (c->audio_on) { c->audio_on = 0; c->audio_end = 1; c->aq.len = 0; logmsg("%s: sound off", c->addr); }
                } else if (op == 2) {
                    uint8_t f[6];
                    pthread_mutex_unlock(&c->mu);
                    if (read_full(c->fd, f, 6) < 0) return 0;
                    pthread_mutex_lock(&c->mu);
                    int fmt = f[0], ch = f[1]; uint32_t hz = rd32(f + 2);
                    if (fmt > 5 || ch < 1 || ch > 8 || hz < 4000 || hz > 192000) {
                        logmsg("%s: unsupported sound format %d/%d ch/%u Hz, keeping %d ch %d Hz", c->addr, fmt, ch, hz, c->achan, c->arate);
                    } else {
                        c->afmt = fmt; c->achan = ch; c->arate = (int)hz;
                        c->aq.len = 0; c->rs_pos = 0;
                        if (c->audio_on) logmsg("%s: sound format %d ch %u Hz", c->addr, ch, hz);
                    }
                } else {
                    pthread_mutex_unlock(&c->mu);
                    logmsg("%s: unknown audio operation %d, closing", c->addr, op);
                    return -1;
                }
                pthread_cond_signal(&c->cv);
                pthread_mutex_unlock(&c->mu);
            } else if (sub == 0) {   /* QEMU extended key event: down u16, keysym u32, keycode u32 */
                uint8_t m[10];
                if (read_full(c->fd, m, 10) < 0) return 0;
                input_key(c, rd16(m) != 0, rd32(m + 2));
            } else {
                logmsg("%s: unknown QEMU message %d, closing", c->addr, sub);
                return -1;
            }
            break;
        }
        default:
            logmsg("%s: unknown message type %d, closing", c->addr, t);
            return -1;
        }
    }
}

static void *reader_thread(void *arg)
{
    client_t *c = arg;
    struct timeval tv = {30, 0};
    setsockopt(c->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    if (handshake(c) < 0) { client_free(c); return NULL; }
    tv.tv_sec = 0;
    setsockopt(c->fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);

    c->pf = (pixfmt_t){32, 24, 0, 1, 255, 255, 255, 16, 8, 0};
    c->compress = 6; c->quality = -1;
    c->afmt = 3; c->achan = 2; c->arate = 48000;
    c->alive = 1;
    pthread_mutex_lock(&clients_mu);
    pthread_mutex_lock(&c->mu);
    client_alloc_dirty(c, fb_w, fb_h, 0);
    pthread_mutex_unlock(&c->mu);
    c->id = next_client_id++;
    c->next = clients; clients = c; nclients++;
    int count = nclients;
    pthread_cond_broadcast(&clients_cv);
    pthread_mutex_unlock(&clients_mu);
    logmsg("%s: viewer connected (%d connected)", c->addr, count);

    pthread_create(&c->writer, NULL, writer_thread, c);
    handle_messages(c);

    pthread_mutex_lock(&c->mu);
    c->alive = 0;
    pthread_cond_signal(&c->cv);
    pthread_mutex_unlock(&c->mu);
    shutdown(c->fd, SHUT_RDWR);
    pthread_join(c->writer, NULL);
    input_release_all(c);
    if (resize_client_gone(c)) capture_geometry_now(0);

    pthread_mutex_lock(&clients_mu);
    for (client_t **pp = &clients; *pp; pp = &(*pp)->next)
        if (*pp == c) { *pp = c->next; break; }
    count = --nclients;
    pthread_mutex_unlock(&clients_mu);
    logmsg("%s: viewer disconnected (%d connected)", c->addr, count);
    client_free(c);
    return NULL;
}

/* ------------------------------------------------------------------ startup */

static void usage(void)
{
    printf("Quest VNC Server %s for Linux (X11)\n\n"
           "Usage: questvnc-server [options]\n"
           "  --port 5900         listen port (TCP, all interfaces)\n"
           "  --password SECRET   VNC password (only the first 8 characters count)\n"
           "  --fps 30            capture rate cap (1-60)\n"
           "  --monitor N         which monitor to share, 0 = primary (default), 1.. = monitor number\n"
           "  --view-only         ignore keyboard and mouse from viewers\n"
           "  --no-audio          don't capture or offer sound\n"
           "  --test-tone         send a 440 Hz beep every second instead of the PC's sound\n"
           "  --no-resize         don't let viewers change the screen resolution\n"
           "  --config FILE       read options from FILE instead of the settings file\n"
           "                      (default $XDG_CONFIG_HOME/questvnc/server.conf, ~/.config/questvnc/server.conf)\n"
           "  --no-update         never check for or install updates\n"
           "  --update-url URL    release feed to check for updates (also QUESTVNC_UPDATE_URL)\n"
           "  --check-update      check for an update once, print the result and exit\n"
           "                      (exit status 0 = up to date, 10 = update available, 1 = check failed)\n"
           "  --background        write messages to ~/.local/state/questvnc/server.log (used by autostart)\n"
           "  --version           print the version and exit\n"
           "The password can also be given in the QUESTVNC_PASSWORD environment variable.\n", VERSION);
}
static void on_signal(int s) { (void)s; quit_flag = 1; }

static void print_addresses(void)
{
    struct ifaddrs *ifa, *i;
    if (getifaddrs(&ifa) < 0) return;
    int any = 0;
    for (i = ifa; i; i = i->ifa_next) {
        if (!i->ifa_addr || i->ifa_addr->sa_family != AF_INET) continue;
        char ip[64];
        inet_ntop(AF_INET, &((struct sockaddr_in *)i->ifa_addr)->sin_addr, ip, sizeof ip);
        if (strncmp(ip, "127.", 4) == 0) continue;
        printf("  Address:   %s:%d  (%s)\n", ip, g_opt.port, i->ifa_name);
        any = 1;
    }
    if (!any) printf("  Address:   no network address found (only this PC can connect)\n");
    freeifaddrs(ifa);
}

/* ------------------------------------------------------------------ options and settings file */

/* Applies one option; *used tells how many words it took. Returns 0 ok, -1 unknown, -2 value missing. */
static int apply_option(const char *a, const char *val, int *used)
{
    *used = 1;
    if (strncmp(a, "--", 2) == 0 && a[2] == '-') a++;
    static const char *const with_value[] = {"--port", "--password", "--fps", "--monitor", "--update-url", "--config"};
    for (size_t k = 0; k < sizeof with_value / sizeof *with_value; k++)
        if (!strcmp(a, with_value[k])) {
            if (!val) return -2;
            *used = 2;
            if (!strcmp(a, "--port")) g_opt.port = arg_int(val);
            else if (!strcmp(a, "--password")) {
                snprintf(g_opt.password, sizeof g_opt.password, "%.8s", val);
                g_opt.has_password = g_opt.password[0] != 0;
            }
            else if (!strcmp(a, "--fps")) g_opt.fps = arg_int(val);
            else if (!strcmp(a, "--monitor")) g_opt.monitor = arg_int(val);
            else if (!strcmp(a, "--update-url")) { free(g_opt.update_url); g_opt.update_url = strdup(val); }
            return 0;   /* --config is handled before the file is read */
        }
    if (!strcmp(a, "--view-only")) g_opt.view_only = 1;
    else if (!strcmp(a, "--no-audio")) g_opt.no_audio = 1;
    else if (!strcmp(a, "--test-tone")) g_opt.test_tone = 1;
    else if (!strcmp(a, "--no-resize")) g_opt.no_resize = 1;
    else if (!strcmp(a, "--no-update")) g_opt.no_update = 1;
    else if (!strcmp(a, "--background")) g_opt.background = 1;
    else if (!strcmp(a, "--check-update")) g_opt.check_update = 1;
    else return -1;
    return 0;
}

static void config_home(char *out, size_t cap, const char *sub)
{
    const char *x = getenv("XDG_CONFIG_HOME"), *home = getenv("HOME");
    if (!home || !*home) { struct passwd *pw = getpwuid(getuid()); home = pw ? pw->pw_dir : "/"; }
    if (x && *x == '/') snprintf(out, cap, "%s/%s", x, sub);
    else snprintf(out, cap, "%s/.config/%s", home, sub);
}

/* Reads the settings file: one option per line, written like on the command line. Unknown or
   broken lines are reported and skipped, so a typo never keeps the server from starting. */
static int load_settings(const char *path, int must_exist)
{
    FILE *f = fopen(path, "re");
    if (!f) {
        if (must_exist || errno != ENOENT) { fprintf(stderr, "Cannot read settings file %s: %s\n", path, strerror(errno)); return -1; }
        return 0;
    }
    char line[2048]; int n = 0;
    while (fgets(line, sizeof line, f)) {
        n++;
        char *p = line, *e = line + strlen(line);
        while (e > p && (e[-1] == '\n' || e[-1] == '\r' || e[-1] == ' ' || e[-1] == '\t')) *--e = 0;
        while (*p == ' ' || *p == '\t') p++;
        if (!*p || *p == '#') continue;
        if (n == 1 && !strncmp(p, "\xef\xbb\xbf", 3)) p += 3;   /* UTF-8 byte order mark */
        char *v = p + strcspn(p, " \t=");
        if (*v) {
            *v++ = 0;
            while (*v == ' ' || *v == '\t') v++;
            size_t vl = strlen(v);
            if (vl >= 2 && (v[0] == '"' || v[0] == '\'') && v[vl - 1] == v[0]) { v[vl - 1] = 0; v++; }
        }
        if (!strcmp(p, "--config") || !strcmp(p, "--help") || !strcmp(p, "--version") || !strcmp(p, "--check-update")) {
            fprintf(stderr, "%s line %d: %s is only for the command line (ignored)\n", path, n, p);
            continue;
        }
        int used, r = apply_option(p, *v ? v : NULL, &used);
        if (r == -1) fprintf(stderr, "%s line %d: unknown option %s (ignored)\n", path, n, p);
        else if (r == -2) fprintf(stderr, "%s line %d: %s needs a value (ignored)\n", path, n, p);
        else if (used == 1 && *v) fprintf(stderr, "%s line %d: %s takes no value (\"%s\" ignored)\n", path, n, p, v);
    }
    fclose(f);
    return 0;
}

/* ------------------------------------------------------------------ listening socket, one copy per port */

static int lock_fd = -1;

/* A lock file per port, held while a Quest VNC Server listens there; 1 if we hold it now. */
static int take_port_lock(void)
{
    if (lock_fd >= 0) return 1;
    char path[PATH_MAX];
    const char *rt = getenv("XDG_RUNTIME_DIR");
    if (rt && *rt == '/') snprintf(path, sizeof path, "%s/questvnc-server-%d.lock", rt, g_opt.port);
    else snprintf(path, sizeof path, "/tmp/questvnc-server-%u-%d.lock", (unsigned)getuid(), g_opt.port);
    int fd = open(path, O_RDWR | O_CREAT | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd < 0) return -1;
    if (flock(fd, LOCK_EX | LOCK_NB) < 0) { int e = errno; close(fd); return e == EWOULDBLOCK ? 0 : -1; }
    char pid[24]; int n = snprintf(pid, sizeof pid, "%d\n", (int)getpid());
    if (ftruncate(fd, 0) < 0 || write(fd, pid, (size_t)n) < 0) { }
    lock_fd = fd;
    return 1;
}

static int bind_port(int family)
{
    int fd = socket(family, SOCK_STREAM | SOCK_CLOEXEC, 0), on = 1, off = 0;
    if (fd < 0) return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    int r;
    if (family == AF_INET6) {
        setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &off, sizeof off);
        struct sockaddr_in6 a6; memset(&a6, 0, sizeof a6);
        a6.sin6_family = AF_INET6; a6.sin6_port = htons((uint16_t)g_opt.port); a6.sin6_addr = in6addr_any;
        r = bind(fd, (struct sockaddr *)&a6, sizeof a6);
    } else {
        struct sockaddr_in a4; memset(&a4, 0, sizeof a4);
        a4.sin_family = AF_INET; a4.sin_port = htons((uint16_t)g_opt.port); a4.sin_addr.s_addr = INADDR_ANY;
        r = bind(fd, (struct sockaddr *)&a4, sizeof a4);
    }
    if (r < 0 || listen(fd, 16) < 0) { int e = errno; close(fd); errno = e; return -1; }
    return fd;
}

/* Returns the listening socket; at start-up a port held by another Quest VNC Server makes us exit
   quietly (status 0), other failures print why and exit with status 1. */
int listener_open(int first)
{
    int fd = bind_port(AF_INET6);
    if (fd < 0 && errno != EADDRINUSE) fd = bind_port(AF_INET);
    if (fd < 0) {
        if (!first) return -1;
        if (errno == EADDRINUSE) {
            if (take_port_lock() == 0) {
                printf("Quest VNC Server is already running on port %d; this copy exits.\n", g_opt.port);
                exit(0);
            }
            fprintf(stderr, "Port %d is already in use (another VNC server running?).\n", g_opt.port);
        } else fprintf(stderr, "Cannot listen on port %d: %s\n", g_opt.port, strerror(errno));
        exit(1);
    }
    take_port_lock();
    return fd;
}

/* --background: messages go to ~/.local/state/questvnc/server.log (or $XDG_STATE_HOME/questvnc). */
static void start_background_log(void)
{
    char dir[PATH_MAX], path[PATH_MAX + 16];
    const char *x = getenv("XDG_STATE_HOME"), *home = getenv("HOME");
    if (!home || !*home) { struct passwd *pw = getpwuid(getuid()); home = pw ? pw->pw_dir : "/"; }
    if (x && *x == '/') snprintf(dir, sizeof dir, "%s/questvnc", x);
    else snprintf(dir, sizeof dir, "%s/.local/state/questvnc", home);
    for (char *p = dir + 1; *p; p++) if (*p == '/') { *p = 0; mkdir(dir, 0700); *p = '/'; }
    mkdir(dir, 0700);
    snprintf(path, sizeof path, "%s/server.log", dir);
    int fd = open(path, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0600);
    if (fd < 0) { fprintf(stderr, "Cannot write %s: %s\n", path, strerror(errno)); return; }
    struct stat st;
    if (fchmod(fd, 0600) < 0 || (fstat(fd, &st) == 0 && st.st_size > LOG_MAX && ftruncate(fd, 0) < 0)) { }
    fflush(stdout); fflush(stderr);
    dup2(fd, 1); dup2(fd, 2); close(fd);
    int dn = open("/dev/null", O_RDONLY);
    if (dn >= 0) { dup2(dn, 0); close(dn); }
    log_to_file = 1;
    char ts[64]; time_t t = time(NULL); struct tm tm; localtime_r(&t, &tm);
    strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", &tm);
    printf("\n==== %s: Quest VNC Server %s starting (pid %d)\n", ts, VERSION, (int)getpid());
}

int main(int argc, char **argv)
{
    setvbuf(stdout, NULL, _IOLBF, 0);
    /* --help, --version and --config first; then QUESTVNC_PASSWORD, the settings file and the
       command line, each overriding the one before. */
    const char *config = NULL;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strncmp(a, "--", 2) == 0 && a[2] == '-') a++;
        if (!strcmp(a, "--help") || !strcmp(a, "-h")) { usage(); return 0; }
        if (!strcmp(a, "--version")) { printf("Quest VNC Server %s\n", VERSION); return 0; }
        if (!strcmp(a, "--config")) {
            if (i + 1 >= argc) { fprintf(stderr, "--config needs a file name\n\n"); usage(); return 2; }
            config = argv[++i];
        }
    }
    const char *envpw = getenv("QUESTVNC_PASSWORD");
    if (envpw && *envpw) { snprintf(g_opt.password, sizeof g_opt.password, "%.8s", envpw); g_opt.has_password = 1; }
    char defconf[PATH_MAX];
    config_home(defconf, sizeof defconf, "questvnc/server.conf");
    if (load_settings(config ? config : defconf, config != NULL) < 0) return 2;
    for (int i = 1; i < argc; i++) {
        int used, r = apply_option(argv[i], i + 1 < argc ? argv[i + 1] : NULL, &used);
        if (r < 0) {
            fprintf(stderr, r == -1 ? "Unknown option: %s\n\n" : "%s needs a value\n\n", argv[i]);
            usage(); return 2;
        }
        i += used - 1;
    }
    if (g_opt.fps < 1) g_opt.fps = 1;
    if (g_opt.fps > 60) g_opt.fps = 60;
    if (g_opt.port < 1 || g_opt.port > 65535) { fprintf(stderr, "Bad port\n"); return 2; }
    if (g_opt.monitor < 0) g_opt.monitor = 0;
    if (g_opt.check_update) return update_check_once();
    if (g_opt.background) start_background_log();

    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, SIG_DFL);
    XInitThreads();

    const char *st = getenv("XDG_SESSION_TYPE");
    if (st && !strcmp(st, "wayland")) {
        fprintf(stderr,
            "WARNING: this is a Wayland session. Only X11 sessions are fully supported: the screen may be\n"
            "black or show only X11 (XWayland) windows, and keyboard/mouse control may not work.\n"
            "Log out, choose an \"Xorg\" (or \"GNOME on Xorg\" / \"Plasma (X11)\") session on the login screen, and try again.\n\n");
    }

    printf("Quest VNC Server %s for Linux\n", VERSION);
    update_startup_note();
    int lfd = listener_open(1);   /* first, so a second copy for the same port exits right away */
    if (capture_init() < 0) return 1;
    if (input_init() < 0) fprintf(stderr, "Keyboard and mouse control is not available.\n");
    if (clipboard_init() < 0) fprintf(stderr, "Clipboard sharing is not available.\n");
    int can_resize = !g_opt.no_resize && !g_opt.view_only && resize_init() == 0;

    char host[256] = "linux";
    gethostname(host, sizeof host - 1);
    snprintf(desktop_name, sizeof desktop_name, "Quest VNC Server (%s)", host);

    audio_init();

    printf("  Listening: TCP port %d\n", g_opt.port);
    print_addresses();
    printf("  Screen:    %dx%d%s\n", fb_w, fb_h, g_opt.monitor ? "" : " (primary monitor)");
    if (g_opt.has_password) printf("  Password:  set\n");
    else printf("  Password:  NONE. WARNING: anyone on your network can see and control this PC. Use --password.\n");
    if (g_opt.no_audio) printf("  Sound:     off (--no-audio)\n");
    else if (audio_ok) printf("  Sound:     available via %s\n", audio_source);
    else printf("  Sound:     not available (install pulseaudio-utils for parec, or pipewire for pw-record)\n");
    if (g_opt.view_only) printf("  View only: keyboard and mouse from viewers are ignored\n");
    printf("  Resize:    %s\n", can_resize ? "viewers may change the resolution (restored when they leave)"
                                  : g_opt.no_resize || g_opt.view_only ? "off" : "not available (no XRandR)");
    printf("  Updates:   %s\n", g_opt.no_update ? "off (--no-update)"
                                : update_is_installed() ? "installed copy, updates itself"
                                : "portable copy (only reports new versions)");
    printf("Waiting for viewers. Press Ctrl+C to stop.\n");

    pthread_t cap;
    pthread_create(&cap, NULL, capture_thread, NULL);
    pthread_detach(cap);
    if (!g_opt.no_update) update_start(argv);

    struct sigaction sa; memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_signal;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGHUP, &sa, NULL);

    while (!quit_flag) {
        if (!g_opt.no_update) update_main_tick(&lfd);
        struct pollfd p = {lfd, POLLIN, 0};
        if (poll(&p, 1, 500) <= 0) continue;
        struct sockaddr_storage ss; socklen_t sl = sizeof ss;
        int fd = accept4(lfd, (struct sockaddr *)&ss, &sl, SOCK_CLOEXEC);
        if (fd < 0) continue;
        int on = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof on);
#ifndef TCP_NOTSENT_LOWAT
#define TCP_NOTSENT_LOWAT 25
#endif
        /* Keep at most ~32 KB of unsent data in the kernel, so a slow viewer's backlog stays in our
           queues (where old audio is dropped) instead of piling up seconds of sound in socket buffers. */
        int lowat = 32 * 1024;
        setsockopt(fd, IPPROTO_TCP, TCP_NOTSENT_LOWAT, &lowat, sizeof lowat);
        client_t *c = calloc(1, sizeof *c);
        c->fd = fd;
        pthread_mutex_init(&c->mu, NULL);
        pthread_cond_init(&c->cv, NULL);
        char host2[64] = "?";
        getnameinfo((struct sockaddr *)&ss, sl, host2, sizeof host2, NULL, 0, NI_NUMERICHOST);
        if (!strncmp(host2, "::ffff:", 7)) memmove(host2, host2 + 7, strlen(host2 + 7) + 1);
        snprintf(c->addr, sizeof c->addr, "%s", host2);
        pthread_t t;
        if (pthread_create(&t, NULL, reader_thread, c) != 0) { client_free(c); continue; }
        pthread_detach(t);
    }
    printf("\nStopping.\n");
    resize_restore_on_exit();
    input_shutdown();
    return 0;
}
