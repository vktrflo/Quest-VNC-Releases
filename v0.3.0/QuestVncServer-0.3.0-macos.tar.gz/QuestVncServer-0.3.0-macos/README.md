# Quest VNC Server for macOS

A VNC server for your Mac that also sends the Mac's sound to Quest VNC over the same connection.
It replaces running a separate VNC server plus the Quest VNC Audio Sender.
Ordinary VNC viewers (TigerVNC, RealVNC, TightVNC, noVNC) can connect too. They just don't get sound.

Needs macOS 13 Ventura or later, on Apple Silicon or Intel.

There are two ways to use it:

* **Install it** (recommended): it then runs in the background, starts by itself when you log in, and installs
  new versions by itself. See "Installing" below.
* **Run it from the folder** ("portable"): double-click `run.command` each time. Nothing is installed and it
  never updates itself. See "First start" below.

## Installing

1. Install Apple's command line tools if you don't have them yet. Open Terminal and run
   `xcode-select --install`, then follow the dialog. It takes a few minutes. You don't need the full Xcode app.
2. Unzip the folder.
3. Right-click `install.command` and choose **Open**, then **Open** again in the warning.
   (Double-clicking is blocked the first time because the file was downloaded.)
4. It builds the program (about a minute), then asks you to choose a VNC password. Type it twice; you won't see
   what you type. Enter the same password for this Mac in Quest VNC. Only the first 8 characters count.
5. It puts **Quest VNC Server** in the Applications folder of your home folder (`~/Applications`) and starts it.
   No admin password is needed. There is no window and no Dock icon; it runs in the background.
6. macOS now asks for two permissions for **Quest VNC Server**:
   * **Screen & System Audio Recording** (called **Screen Recording** before macOS 15), to see the screen and hear the Mac's sound.
   * **Accessibility**, so the headset can control the mouse and keyboard.

   Turn both on in System Settings > Privacy & Security. The server starts again by itself within a minute after that.

From then on it starts by itself every time you log in, and starts again if it ever stops.
What it does is written to the log file `~/Library/Logs/QuestVncServer.log`
(open it with the Console app, or in Finder with Go > Go to Folder... and that path).

Running `install.command` again (for example from a newer download) reinstalls it and keeps your settings.

### Uninstalling

Open Terminal, go to the unzipped folder and run `./install.command --uninstall`.
It stops the server and removes the app, the login entry and the log. It asks before deleting your settings file.

### Settings file

The installed server takes its options from the settings file
`~/Library/Application Support/QuestVncServer/server.conf`. To change the password or another option,
open it in TextEdit (in Finder: Go > Go to Folder..., paste `~/Library/Application Support/QuestVncServer`).
Write one option per line, exactly like the options listed under "Options" below, for example:

```
--password yoursecret
--fps 60
--no-audio
```

Lines starting with `#` are ignored. Only you can read the file, because it holds the password.
Changes apply when the server starts again: log out and back in, or run this in Terminal:

```
launchctl kickstart -k gui/$(id -u)/com.questvnc.server
```

`run.command` reads the same settings file too, if it exists. Options given on the command line win over the file.

### Updates

The installed server checks for a new version a minute after it starts and then every 12 hours.
When there is one, it downloads it, checks that the download is complete and unchanged, and waits until no
viewer is connected, so nobody's session is cut off. Then it builds the new version, swaps it in and restarts.
The log shows each step ("Update 0.3.0 available", "Downloaded update 0.3.0", "Installing update 0.3.0 now",
"Updated to 0.3.0"). If anything goes wrong, the old version keeps running and it tries again later.

**After each update, macOS asks again for Screen Recording and Accessibility.** macOS ties these permissions to the
app's signature, and this app is built on your Mac, so every new version has a new signature (this stays so until
the app is signed with an Apple Developer ID). When that happens, turn both on again for Quest VNC Server in
System Settings > Privacy & Security. The server clears its old entries before restarting, but if an old
"Quest VNC Server" entry is still listed there and turned on while the log says the permission is missing,
turn it off and on again, or remove it with the minus button and add the app again.

To turn automatic updates off, add the line `--no-update` to the settings file. To just see whether there is a new
version, run in Terminal:

```
"$HOME/Applications/Quest VNC Server.app/Contents/MacOS/QuestVncServer" --check-update
```

A copy run from the folder with `run.command` never updates itself; it only writes "Update x.y.z is available"
once, and you download the new version yourself.

## First start (from the folder, without installing)

1. Install Apple's command line tools if you don't have them yet. Open Terminal and run
   `xcode-select --install`, then follow the dialog. It takes a few minutes. You don't need the full Xcode app.
2. Unzip the folder somewhere you'll keep it, for example in your home folder.
3. Right-click `run.command` and choose **Open**, then **Open** again in the warning.
   Double-clicking is blocked the first time because the file was downloaded. After this first time, double-clicking works.
4. The first run builds the program, which takes about a minute. Later runs start right away.
5. macOS asks for two permissions for Terminal (or whichever app you started it from):
   * **Screen & System Audio Recording** (called **Screen Recording** before macOS 15). This lets it see the screen and hear the Mac's sound.
     Turn it on in System Settings > Privacy & Security > Screen & System Audio Recording.
   * **Accessibility**. This lets the headset control the mouse and keyboard.
     Turn it on in System Settings > Privacy & Security > Accessibility.

   After turning them on, quit Terminal completely (Terminal > Quit Terminal) and start `run.command` again.
   Without Accessibility you can still watch the screen and hear sound, but clicks and typing won't reach the Mac.

When it is running, the window shows the port, this Mac's network address, the screen size, whether a password is set,
and whether sound is available. Leave the window open while you use Quest VNC. Press Ctrl+C or close the window to stop it.
While it runs, macOS shows its screen recording indicator in the menu bar. macOS 15 may also ask every so often
whether to keep allowing screen recording; choose to allow it.

## Setting a password (recommended)

Without a password, anyone on your network can see and control your Mac. If you installed it, the password is in the
settings file (see "Settings file" above). When running from the folder, open `run.command` in TextEdit
and change the last line to:

```
./QuestVncServer --password yoursecret "$@"
```

Only the first 8 characters count (that is how VNC passwords work). Use plain letters and digits.
Enter the same password for this Mac in Quest VNC.

## Options

Add these after `./QuestVncServer` on the last line of `run.command`, or pass them when starting it from Terminal
(`./run.command --password yoursecret --fps 20`).

```
--port 5900        listen port (use another one if something else already uses 5900)
--password SECRET  VNC password
--fps 30           highest frame rate, 1 to 60
--monitor N        which display to share: 0 is the main display, 1 the next one, and so on
--view-only        only show the screen; ignore keyboard and mouse from viewers
--no-audio         don't capture or offer sound
--test-tone        send a 440 Hz beep every second instead of the Mac's sound, to check the setup
--full-res         capture at full Retina resolution (sharper text, but much more data)
--no-resize        don't let viewers change the Mac's screen resolution
--config FILE      read options from FILE instead of the settings file
--no-update        never check for or install updates
--update-url URL   where to look for new versions (normally not needed)
--check-update     check once for a new version, print the result and stop
--version          print the version and stop
```

By default a Retina screen is captured at its "looks like" size (for example 1512x982 on a 14 inch MacBook Pro),
which keeps the picture fast. Use `--full-res` for the full pixel resolution.

If you use the macOS Screen Sharing feature (System Settings > General > Sharing > Screen Sharing), it already
uses port 5900. Either turn it off or start this server with `--port 5901` and use that port in Quest VNC.

## Resolution from the headset

Quest VNC can ask the Mac to switch to another resolution (for example 1920x1080 or 2560x1440).
The server then picks the Mac display mode of exactly that size. If there isn't one, it uses the closest mode with
the same shape that is not larger, or else the largest mode that fits. The headset is told which size it actually got.
The size counts in "looks like" points, or in pixels when started with `--full-res`.

The change is temporary. The original resolution comes back when the viewer that asked for it disconnects,
when you stop the server (Ctrl+C or closing the window), and also if the server crashes, because macOS undoes it by itself.
If a second viewer asks for another resolution, theirs replaces the first one, and the original comes back when they leave.
Choosing "PC default" in Quest VNC asks for the original size again.

To keep viewers from changing the resolution, start with `--no-resize`. With `--view-only` it is never changed either.

## Keyboard

Keys from the headset (or a PC keyboard in another viewer) map to Mac keys like this:

* Ctrl is Control, Shift is Shift.
* Alt is Option.
* The Windows / Meta / Super key is Command. So Command+C is "Windows key + C" in the viewer.
* Letters, digits and symbols type the character you pressed, whatever keyboard layout the Mac uses.
  While Command, Control or Option is held, the key at that letter's US keyboard position is pressed instead,
  so shortcuts work.
* Print Screen, Scroll Lock and Pause act as F13, F14 and F15. Insert acts as Help.

## Starting automatically

The easiest way is to install it (see "Installing"). To start the folder copy at login instead, open
System Settings > General > Login Items, click **+** under "Open at Login", and choose `run.command`.
It then opens in a Terminal window each time you log in. Set the password in `run.command` first.
Either way, the Mac has to be logged in: it can't show the login window or the lock screen.
Don't use both at once: they would both want port 5900.

## Sound

The Mac's sound is captured with Apple's own ScreenCaptureKit, so no extra audio driver is needed.
Viewers that support sound (Quest VNC) get it inside the VNC connection, about 1.5 Mbit/s for 48 kHz stereo.
If sound capture isn't possible, the server keeps running without sound.

## Firewall

If the macOS firewall is on, macOS asks whether `QuestVncServer` (or `Quest VNC Server` when installed) may accept
incoming connections. Choose **Allow**.

## Building by hand

```
swiftc -O -target $(uname -m)-apple-macos13.0 *.swift -import-objc-header zlib-bridge.h -lz -o QuestVncServer
```

`run.command` does exactly this when the program is missing or a source file is newer, and `install.command`
does it before wrapping the program as `~/Applications/Quest VNC Server.app` (with `QuestVncServer --make-app PATH`,
which writes the app's Info.plist and signs it ad hoc) and adding `~/Library/LaunchAgents/com.questvnc.server.plist`.
The `Core*.swift` files only use Foundation and POSIX and also build on Linux; `test/` holds a Linux test host and
protocol tests for them, plus unit tests for the settings file and the updater in `test/unit/` (`test/run_linux_tests.sh`).
The `Mac*.swift` files and `main.swift` hold the macOS parts: capture, input, JPEG, clipboard and the update build.
