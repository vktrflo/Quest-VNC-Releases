// The Mac clipboard: polled once a second (macOS has no change notification), set from viewers.

import AppKit
import Foundation

final class MacClipboard: ClipboardSink, @unchecked Sendable {
    weak var server: VncServer?
    private var lastChange = 0
    private var timer: Timer?

    /// Call on the main thread.
    func start() {
        lastChange = NSPasteboard.general.changeCount
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in self?.poll() }
    }

    private func poll() {
        let pb = NSPasteboard.general
        let count = pb.changeCount
        guard count != lastChange else { return }
        lastChange = count
        if let text = pb.string(forType: .string) { server?.hostClipboardChanged(text) }
    }

    func setText(_ text: String) {
        DispatchQueue.main.async {
            let pb = NSPasteboard.general
            pb.clearContents()
            pb.setString(text, forType: .string)
            // Not a change to send back to the viewers.
            self.lastChange = pb.changeCount
        }
    }
}
