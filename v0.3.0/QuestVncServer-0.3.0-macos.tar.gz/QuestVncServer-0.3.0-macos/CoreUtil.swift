// Platform-neutral helpers: logging, byte packing, LAN addresses, host name.
// Uses only Foundation and POSIX, so the core also builds on Linux (see test/).

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

func log(_ s: String) {
    print(s)
    fflush(stdout)
}

/// Appends big-endian RFB fields to a byte array.
struct ByteWriter {
    var bytes: [UInt8] = []

    init(capacity: Int = 64) { bytes.reserveCapacity(capacity) }

    mutating func u8(_ v: UInt8) { bytes.append(v) }
    mutating func u8(_ v: Int) { bytes.append(UInt8(truncatingIfNeeded: v)) }
    mutating func u16(_ v: Int) {
        bytes.append(UInt8(truncatingIfNeeded: v >> 8))
        bytes.append(UInt8(truncatingIfNeeded: v))
    }
    mutating func u32(_ v: UInt32) {
        bytes.append(UInt8(truncatingIfNeeded: v >> 24))
        bytes.append(UInt8(truncatingIfNeeded: v >> 16))
        bytes.append(UInt8(truncatingIfNeeded: v >> 8))
        bytes.append(UInt8(truncatingIfNeeded: v))
    }
    mutating func u32(_ v: Int) { u32(UInt32(truncatingIfNeeded: v)) }
    mutating func s32(_ v: Int32) { u32(UInt32(bitPattern: v)) }
    mutating func append(_ b: [UInt8]) { bytes.append(contentsOf: b) }
    mutating func pad(_ n: Int) { for _ in 0..<n { bytes.append(0) } }

    /// Tight "compact length": 1-3 bytes, 7 bits per byte, low bits first, high bit = more follows.
    mutating func compactLength(_ n: Int) {
        bytes.append(UInt8(n & 0x7F) | (n > 0x7F ? 0x80 : 0))
        if n > 0x7F {
            bytes.append(UInt8((n >> 7) & 0x7F) | (n > 0x3FFF ? 0x80 : 0))
            if n > 0x3FFF { bytes.append(UInt8((n >> 14) & 0xFF)) }
        }
    }

    /// Header of one rectangle inside a FramebufferUpdate.
    mutating func rectHeader(x: Int, y: Int, w: Int, h: Int, encoding: Int32) {
        u16(x); u16(y); u16(w); u16(h); s32(encoding)
    }
}

/// Largest value a Tight compact length can carry.
let maxCompactLength = 4_194_303

/// Encodes text as Latin-1, replacing characters outside Latin-1 with '?'.
func latin1Bytes(_ s: String) -> [UInt8] {
    var out: [UInt8] = []
    out.reserveCapacity(s.unicodeScalars.count)
    for u in s.unicodeScalars {
        out.append(u.value <= 0xFF ? UInt8(u.value) : UInt8(ascii: "?"))
    }
    return out
}

func latin1String(_ b: [UInt8]) -> String {
    var s = String.UnicodeScalarView()
    for c in b { s.append(Unicode.Scalar(c)) }
    return String(s)
}

/// IPv4 addresses of the network interfaces that are up (loopback excluded), e.g. "192.168.1.20 (en0)".
func lanAddresses() -> [String] {
    var result: [String] = []
    var ifap: UnsafeMutablePointer<ifaddrs>? = nil
    guard getifaddrs(&ifap) == 0 else { return [] }
    defer { freeifaddrs(ifap) }
    var p = ifap
    while let ifa = p {
        p = ifa.pointee.ifa_next
        let flags = UInt32(ifa.pointee.ifa_flags)
        guard let addr = ifa.pointee.ifa_addr, addr.pointee.sa_family == sa_family_t(AF_INET) else { continue }
        if flags & UInt32(IFF_LOOPBACK) != 0 || flags & UInt32(IFF_UP) == 0 { continue }
        var host = [CChar](repeating: 0, count: 64)
        let rc = getnameinfo(addr, socklen_t(MemoryLayout<sockaddr_in>.size), &host, socklen_t(host.count),
                             nil, 0, NI_NUMERICHOST)
        if rc == 0 {
            result.append("\(String(cString: host)) (\(String(cString: ifa.pointee.ifa_name)))")
        }
    }
    return result
}

/// POSIX host name, without a trailing ".local".
func posixHostName() -> String {
    var buf = [CChar](repeating: 0, count: 256)
    guard gethostname(&buf, buf.count - 1) == 0 else { return "computer" }
    var s = String(cString: buf)
    if s.hasSuffix(".local") { s.removeLast(6) }
    return s.isEmpty ? "computer" : s
}

/// Monotonic seconds.
func monotonicSeconds() -> Double {
    var ts = timespec()
    clock_gettime(CLOCK_MONOTONIC, &ts)
    return Double(ts.tv_sec) + Double(ts.tv_nsec) / 1e9
}

struct FbRect: Equatable {
    var x: Int, y: Int, w: Int, h: Int
    var isEmpty: Bool { w <= 0 || h <= 0 }
    var maxX: Int { x + w }
    var maxY: Int { y + h }

    func intersection(_ o: FbRect) -> FbRect {
        let x0 = max(x, o.x), y0 = max(y, o.y)
        let x1 = min(maxX, o.maxX), y1 = min(maxY, o.maxY)
        return FbRect(x: x0, y: y0, w: max(0, x1 - x0), h: max(0, y1 - y0))
    }

    func union(_ o: FbRect) -> FbRect {
        if isEmpty { return o }
        if o.isEmpty { return self }
        let x0 = min(x, o.x), y0 = min(y, o.y)
        return FbRect(x: x0, y: y0, w: max(maxX, o.maxX) - x0, h: max(maxY, o.maxY) - y0)
    }
}
