#!/bin/bash
# Double-click (the first time: right-click > Open) to start Quest VNC Server.
# To add options, change the last line, for example:
#   ./QuestVncServer --password secret "$@"
cd "$(dirname "$0")" || exit 1
needs_build=0
[ -x ./QuestVncServer ] || needs_build=1
for f in *.swift zlib-bridge.h; do
  [ "$f" -nt QuestVncServer ] && needs_build=1
done
if [ "$needs_build" = 1 ]; then
  echo "Building Quest VNC Server (first run only, takes a minute)..."
  if ! xcrun --find swiftc >/dev/null 2>&1; then
    echo "The Xcode Command Line Tools are needed. Install them with:  xcode-select --install"
    echo "then run this again. Press Enter to close."
    read -r
    exit 1
  fi
  if ! swiftc -O -target "$(uname -m)-apple-macos13.0" *.swift -import-objc-header zlib-bridge.h -lz -o QuestVncServer; then
    rm -f QuestVncServer
    echo "Build failed (see the messages above). Press Enter to close."
    read -r
    exit 1
  fi
fi
./QuestVncServer "$@"
