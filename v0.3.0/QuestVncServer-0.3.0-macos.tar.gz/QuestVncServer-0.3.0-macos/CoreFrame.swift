// Pixel formats, captured frames and the 64x64 tile comparison between frames.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

let tileSize = 64

/// RFB PIXEL_FORMAT. The server's own format is 32 bpp, depth 24, little-endian, shifts 16/8/0,
/// which is exactly the BGRA byte order of the captured frames.
struct PixelFormat: Equatable {
    var bpp = 32
    var depth = 24
    var bigEndian = false
    var trueColour = true
    var rMax = 255, gMax = 255, bMax = 255
    var rShift = 16, gShift = 8, bShift = 0

    init() {}

    /// Parses the 16-byte PIXEL_FORMAT of a SetPixelFormat message.
    init(_ b: [UInt8]) {
        bpp = Int(b[0]); depth = Int(b[1]); bigEndian = b[2] != 0; trueColour = b[3] != 0
        rMax = Int(b[4]) << 8 | Int(b[5]); gMax = Int(b[6]) << 8 | Int(b[7]); bMax = Int(b[8]) << 8 | Int(b[9])
        rShift = Int(b[10]); gShift = Int(b[11]); bShift = Int(b[12])
    }

    var bytes: [UInt8] {
        var w = ByteWriter()
        w.u8(bpp); w.u8(depth); w.u8(bigEndian ? 1 : 0); w.u8(trueColour ? 1 : 0)
        w.u16(rMax); w.u16(gMax); w.u16(bMax)
        w.u8(rShift); w.u8(gShift); w.u8(bShift)
        w.pad(3)
        return w.bytes
    }

    var bytesPerPixel: Int { bpp / 8 }

    /// Formats we can produce: true colour at 8, 16 or 32 bpp.
    var isSupported: Bool {
        trueColour && (bpp == 8 || bpp == 16 || bpp == 32) && rMax > 0 && gMax > 0 && bMax > 0
            && rMax <= 0xFFFF && gMax <= 0xFFFF && bMax <= 0xFFFF && rShift < bpp && gShift < bpp && bShift < bpp
    }

    /// Same layout as our BGRA frames, so pixels can be copied as they are.
    var isNative: Bool {
        bpp == 32 && !bigEndian && rMax == 255 && gMax == 255 && bMax == 255
            && rShift == 16 && gShift == 8 && bShift == 0
    }

    /// Tight sends 3-byte TPIXELs (R, G, B) for this kind of format.
    var usesTPixel: Bool { bpp == 32 && depth == 24 && rMax == 255 && gMax == 255 && bMax == 255 }

    /// Converts BGRA pixels to this format (bytesPerPixel bytes each).
    func convert(_ bgra: [UInt8]) -> [UInt8] {
        if isNative { return bgra }
        let n = bgra.count / 4
        let bpp8 = bytesPerPixel
        var out = [UInt8](repeating: 0, count: n * bpp8)
        let rm = UInt32(rMax), gm = UInt32(gMax), bm = UInt32(bMax)
        let rs = UInt32(rShift), gs = UInt32(gShift), bs = UInt32(bShift)
        let simple = rMax == 255 && gMax == 255 && bMax == 255
        bgra.withUnsafeBufferPointer { src in
            out.withUnsafeMutableBufferPointer { dst in
                for i in 0..<n {
                    let b = UInt32(src[i * 4]), g = UInt32(src[i * 4 + 1]), r = UInt32(src[i * 4 + 2])
                    let v: UInt32
                    if simple {
                        v = (r << rs) | (g << gs) | (b << bs)
                    } else {
                        v = (((r * rm + 127) / 255) << rs) | (((g * gm + 127) / 255) << gs) | (((b * bm + 127) / 255) << bs)
                    }
                    let o = i * bpp8
                    switch bpp8 {
                    case 1:
                        dst[o] = UInt8(truncatingIfNeeded: v)
                    case 2:
                        if bigEndian {
                            dst[o] = UInt8(truncatingIfNeeded: v >> 8); dst[o + 1] = UInt8(truncatingIfNeeded: v)
                        } else {
                            dst[o] = UInt8(truncatingIfNeeded: v); dst[o + 1] = UInt8(truncatingIfNeeded: v >> 8)
                        }
                    default:
                        if bigEndian {
                            dst[o] = UInt8(truncatingIfNeeded: v >> 24); dst[o + 1] = UInt8(truncatingIfNeeded: v >> 16)
                            dst[o + 2] = UInt8(truncatingIfNeeded: v >> 8); dst[o + 3] = UInt8(truncatingIfNeeded: v)
                        } else {
                            dst[o] = UInt8(truncatingIfNeeded: v); dst[o + 1] = UInt8(truncatingIfNeeded: v >> 8)
                            dst[o + 2] = UInt8(truncatingIfNeeded: v >> 16); dst[o + 3] = UInt8(truncatingIfNeeded: v >> 24)
                        }
                    }
                }
            }
        }
        return out
    }
}

/// One captured screen image: BGRA, 4 bytes per pixel, rows packed (stride = width * 4). Immutable.
final class Frame {
    let width: Int
    let height: Int
    let pixels: [UInt8]

    init(width: Int, height: Int, pixels: [UInt8]) {
        self.width = width
        self.height = height
        self.pixels = pixels
    }

    static func black(width: Int, height: Int) -> Frame {
        var px = [UInt8](repeating: 0, count: width * height * 4)
        var i = 3
        while i < px.count { px[i] = 255; i += 4 }
        return Frame(width: width, height: height, pixels: px)
    }

    /// Copies a rectangle out as packed BGRA. Parts outside this frame are black (a viewer that
    /// can't resize keeps its old size, so a smaller screen is shown top-left with black around it).
    func extract(_ r: FbRect) -> [UInt8] {
        var out = [UInt8](repeating: 0, count: r.w * r.h * 4)
        let inside = r.intersection(FbRect(x: 0, y: 0, w: width, h: height))
        if inside.isEmpty { return out }
        pixels.withUnsafeBufferPointer { src in
            out.withUnsafeMutableBufferPointer { dst in
                for row in 0..<inside.h {
                    let sy = inside.y + row
                    let s = (sy * width + inside.x) * 4
                    let d = ((sy - r.y) * r.w + (inside.x - r.x)) * 4
                    memcpy(dst.baseAddress! + d, src.baseAddress! + s, inside.w * 4)
                }
            }
        }
        return out
    }
}

/// What changed between two frames, as a grid of 64x64 tiles in frame coordinates.
struct FrameChange {
    let frame: Frame
    let sizeChanged: Bool
    let tilesX: Int
    let tilesY: Int
    let dirty: [Bool]
}

/// Holds the latest frame and tells listeners which tiles changed.
final class FrameStore {
    private let lock = NSLock()
    private var frame: Frame
    private var listeners: [Int: (FrameChange) -> Void] = [:]
    private var nextId = 0

    init(width: Int, height: Int) {
        frame = Frame.black(width: width, height: height)
    }

    var current: Frame {
        lock.lock(); defer { lock.unlock() }
        return frame
    }

    func addListener(_ f: @escaping (FrameChange) -> Void) -> Int {
        lock.lock(); defer { lock.unlock() }
        nextId += 1
        listeners[nextId] = f
        return nextId
    }

    func removeListener(_ id: Int) {
        lock.lock(); defer { lock.unlock() }
        listeners[id] = nil
    }

    /// Takes a new BGRA image (rows `bytesPerRow` apart), copies it and compares it with the last one.
    /// Called from the capture thread.
    func submit(width: Int, height: Int, bytesPerRow: Int, base: UnsafeRawPointer) {
        guard width > 0, height > 0 else { return }
        let rowBytes = width * 4
        let px = [UInt8](unsafeUninitializedCapacity: rowBytes * height) { buf, count in
            for y in 0..<height {
                memcpy(buf.baseAddress! + y * rowBytes, base + y * bytesPerRow, rowBytes)
            }
            count = rowBytes * height
        }
        submit(Frame(width: width, height: height, pixels: px))
    }

    func submit(_ new: Frame) {
        let old = current
        let tilesX = (new.width + tileSize - 1) / tileSize
        let tilesY = (new.height + tileSize - 1) / tileSize
        let sizeChanged = old.width != new.width || old.height != new.height
        var dirty = [Bool](repeating: sizeChanged, count: tilesX * tilesY)
        var any = sizeChanged
        if !sizeChanged {
            let w = new.width
            old.pixels.withUnsafeBufferPointer { a in
                new.pixels.withUnsafeBufferPointer { b in
                    for ty in 0..<tilesY {
                        let y0 = ty * tileSize, y1 = min(new.height, y0 + tileSize)
                        for tx in 0..<tilesX {
                            let x0 = tx * tileSize
                            let len = (min(w, x0 + tileSize) - x0) * 4
                            var y = y0
                            while y < y1 {
                                let off = (y * w + x0) * 4
                                if memcmp(a.baseAddress! + off, b.baseAddress! + off, len) != 0 {
                                    dirty[ty * tilesX + tx] = true
                                    any = true
                                    break
                                }
                                y += 1
                            }
                        }
                    }
                }
            }
        }
        guard any else { return }
        // Publish the frame first, then mark tiles: a viewer that grabs the frame between the two
        // steps just sends the change twice, never misses it.
        lock.lock()
        frame = new
        let ls = Array(listeners.values)
        lock.unlock()
        let change = FrameChange(frame: new, sizeChanged: sizeChanged, tilesX: tilesX, tilesY: tilesY, dirty: dirty)
        for l in ls { l(change) }
    }
}

/// Turns a tile bitmap into rectangles: horizontal runs per tile row, then runs with the same
/// columns in consecutive rows merged vertically. Returns tile-unit rects.
func mergeTiles(_ dirty: [Bool], tilesX: Int, tilesY: Int) -> [FbRect] {
    var result: [FbRect] = []
    var open: [FbRect] = []   // runs from the previous row that may still grow downwards
    for ty in 0..<tilesY {
        var runs: [FbRect] = []
        var tx = 0
        while tx < tilesX {
            if dirty[ty * tilesX + tx] {
                let start = tx
                while tx < tilesX && dirty[ty * tilesX + tx] { tx += 1 }
                runs.append(FbRect(x: start, y: ty, w: tx - start, h: 1))
            } else {
                tx += 1
            }
        }
        var nextOpen: [FbRect] = []
        for run in runs {
            if let i = open.firstIndex(where: { $0.x == run.x && $0.w == run.w }) {
                var r = open.remove(at: i)
                r.h += 1
                nextOpen.append(r)
            } else {
                nextOpen.append(run)
            }
        }
        result.append(contentsOf: open)
        open = nextOpen
    }
    result.append(contentsOf: open)
    return result
}
