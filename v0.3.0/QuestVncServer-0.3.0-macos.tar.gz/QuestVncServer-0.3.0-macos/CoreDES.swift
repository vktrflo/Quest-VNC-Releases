// Small single-DES (ECB, encrypt only) for VNC Authentication. Plain Swift, so the same code runs
// on macOS and Linux and can be checked against the FIPS 46 test vector (see test/).

enum DES {
    private static let ip: [UInt8] = [
        58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4,
        62, 54, 46, 38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8,
        57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11, 3,
        61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7]
    private static let fp: [UInt8] = [
        40, 8, 48, 16, 56, 24, 64, 32, 39, 7, 47, 15, 55, 23, 63, 31,
        38, 6, 46, 14, 54, 22, 62, 30, 37, 5, 45, 13, 53, 21, 61, 29,
        36, 4, 44, 12, 52, 20, 60, 28, 35, 3, 43, 11, 51, 19, 59, 27,
        34, 2, 42, 10, 50, 18, 58, 26, 33, 1, 41, 9, 49, 17, 57, 25]
    private static let e: [UInt8] = [
        32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16, 17,
        16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1]
    private static let p: [UInt8] = [
        16, 7, 20, 21, 29, 12, 28, 17, 1, 15, 23, 26, 5, 18, 31, 10,
        2, 8, 24, 14, 32, 27, 3, 9, 19, 13, 30, 6, 22, 11, 4, 25]
    private static let pc1: [UInt8] = [
        57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44, 36,
        63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20, 12, 4]
    private static let pc2: [UInt8] = [
        14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2,
        41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32]
    private static let shifts: [Int] = [1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1]
    private static let sbox: [[UInt8]] = [
        [14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7,
         0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3, 8,
         4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0,
         15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10, 0, 6, 13],
        [15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10,
         3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11, 5,
         0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15,
         13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0, 5, 14, 9],
        [10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8,
         13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15, 1,
         13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7,
         1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11, 5, 2, 12],
        [7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15,
         13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14, 9,
         10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4,
         3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12, 7, 2, 14],
        [2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9,
         14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8, 6,
         4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14,
         11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9, 10, 4, 5, 3],
        [12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11,
         10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3, 8,
         9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6,
         4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6, 0, 8, 13],
        [4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1,
         13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8, 6,
         1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2,
         6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14, 2, 3, 12],
        [13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7,
         1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9, 2,
         7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8,
         2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3, 5, 6, 11]]

    /// Picks bits of `input` (an `inBits`-wide value, bit 1 = most significant) in table order.
    private static func permute(_ input: UInt64, _ table: [UInt8], _ inBits: Int) -> UInt64 {
        var out: UInt64 = 0
        for t in table { out = (out << 1) | ((input >> UInt64(inBits - Int(t))) & 1) }
        return out
    }

    private static func subkeys(_ key: [UInt8]) -> [UInt64] {
        var k: UInt64 = 0
        for i in 0..<8 { k = (k << 8) | UInt64(i < key.count ? key[i] : 0) }
        let cd = permute(k, pc1, 64)
        var c = (cd >> 28) & 0xFFFFFFF, d = cd & 0xFFFFFFF
        var keys: [UInt64] = []
        for s in shifts {
            c = ((c << UInt64(s)) | (c >> UInt64(28 - s))) & 0xFFFFFFF
            d = ((d << UInt64(s)) | (d >> UInt64(28 - s))) & 0xFFFFFFF
            keys.append(permute((c << 28) | d, pc2, 56))
        }
        return keys
    }

    private static func block(_ input: UInt64, _ keys: [UInt64]) -> UInt64 {
        let x = permute(input, ip, 64)
        var l = x >> 32, r = x & 0xFFFFFFFF
        for k in keys {
            let ex = permute(r, e, 32) ^ k
            var s: UInt64 = 0
            for i in 0..<8 {
                let six = Int((ex >> UInt64(42 - 6 * i)) & 0x3F)
                let row = ((six & 0x20) >> 4) | (six & 1)
                let col = (six >> 1) & 0xF
                s = (s << 4) | UInt64(sbox[i][row * 16 + col])
            }
            let f = permute(s, p, 32)
            (l, r) = (r, l ^ f)
        }
        return permute((r << 32) | l, fp, 64)
    }

    /// DES-ECB encryption; `data.count` must be a multiple of 8.
    static func encryptECB(key: [UInt8], data: [UInt8]) -> [UInt8] {
        let keys = subkeys(key)
        var out: [UInt8] = []
        out.reserveCapacity(data.count)
        var i = 0
        while i + 8 <= data.count {
            var v: UInt64 = 0
            for j in 0..<8 { v = (v << 8) | UInt64(data[i + j]) }
            let c = block(v, keys)
            for j in 0..<8 { out.append(UInt8(truncatingIfNeeded: c >> UInt64(56 - 8 * j))) }
            i += 8
        }
        return out
    }

    /// The VNC Authentication response: DES-ECB of the challenge with the password (first 8 bytes,
    /// zero padded) as key, each key byte bit-reversed.
    static func vncResponse(password: String, challenge: [UInt8]) -> [UInt8] {
        var key = [UInt8](repeating: 0, count: 8)
        for (i, b) in Array(password.utf8.prefix(8)).enumerated() {
            var r: UInt8 = 0
            for bit in 0..<8 where b & (1 << UInt8(bit)) != 0 { r |= 0x80 >> UInt8(bit) }
            key[i] = r
        }
        return encryptECB(key: key, data: challenge)
    }
}
