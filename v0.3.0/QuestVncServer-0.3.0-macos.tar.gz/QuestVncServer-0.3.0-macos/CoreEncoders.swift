// Raw and Tight rectangle encoders. Each viewer has its own RectEncoder (Tight's zlib stream is
// per connection).

/// Turns packed BGRA pixels into a JPEG. Supplied by the platform (ImageIO on macOS).
protocol JpegEncoder: AnyObject {
    func encode(bgra: [UInt8], width: Int, height: Int, quality: Int) -> [UInt8]?
}

let encRaw: Int32 = 0
let encTight: Int32 = 7
let encDesktopSize: Int32 = -223
let encLastRect: Int32 = -224
let encQemuAudio: Int32 = -259

/// Tight JPEG quality per quality level 0..9.
let jpegQualityForLevel = [15, 25, 35, 45, 55, 65, 75, 85, 90, 95]

struct EncodeSettings {
    var format = PixelFormat()
    var tight = false
    var qualityLevel: Int? = nil   // from pseudo-encodings -32..-23
    var compressLevel = 6          // from pseudo-encodings -256..-247
}

final class RectEncoder {
    private let jpeg: JpegEncoder?
    private var zlib: DeflateStream?

    init(jpeg: JpegEncoder?) { self.jpeg = jpeg }

    /// Encodes one rectangle of `frame` (in framebuffer coordinates) as one or more complete
    /// rectangles (header + data), ready to go into a FramebufferUpdate.
    func encode(_ frame: Frame, _ r: FbRect, _ s: EncodeSettings) -> [[UInt8]] {
        if s.tight {
            let jpegOK = s.qualityLevel != nil && jpeg != nil && s.format.usesTPixel
            // A Tight rect is at most 2048 wide; keep basic rects to 64K pixels as TightVNC does.
            var out: [[UInt8]] = []
            for (part, solid) in partition(frame, r) {
                let maxArea = solid ? Int.max / 4 : (jpegOK ? 2048 * 256 : 65536)
                for piece in split(part, maxW: 2048, maxArea: maxArea) {
                    out.append(contentsOf: tight(frame, piece, s, jpegOK: jpegOK))
                }
            }
            return out
        }
        // Raw in strips, so sound can slip in between them on slow links.
        return split(r, maxW: 65535, maxArea: 65536).map { raw(frame, $0, s.format) }
    }

    /// Cuts `r` along the 64x64 tile grid into areas of one solid colour and areas with detail,
    /// merging neighbours of the same kind (and colour) across and down. Solid areas become Tight
    /// fills; the rest goes to JPEG or zlib.
    private func partition(_ frame: Frame, _ r: FbRect) -> [(FbRect, Bool)] {
        var result: [(FbRect, Bool)] = []
        var open: [(FbRect, UInt32?)] = []
        var y = r.y
        while y < r.maxY {
            let h = min(tileSize - y % tileSize, r.maxY - y)
            var runs: [(FbRect, UInt32?)] = []
            var x = r.x
            while x < r.maxX {
                let w = min(tileSize - x % tileSize, r.maxX - x)
                let c = solidColour(frame, FbRect(x: x, y: y, w: w, h: h))
                if let last = runs.last, last.1 == c {
                    runs[runs.count - 1].0.w += w
                } else {
                    runs.append((FbRect(x: x, y: y, w: w, h: h), c))
                }
                x += w
            }
            var nextOpen: [(FbRect, UInt32?)] = []
            for run in runs {
                if let i = open.firstIndex(where: { $0.0.x == run.0.x && $0.0.w == run.0.w && $0.1 == run.1 }) {
                    var o = open.remove(at: i)
                    o.0.h += run.0.h
                    nextOpen.append(o)
                } else {
                    nextOpen.append(run)
                }
            }
            result.append(contentsOf: open.map { ($0.0, $0.1 != nil) })
            open = nextOpen
            y += h
        }
        result.append(contentsOf: open.map { ($0.0, $0.1 != nil) })
        return result
    }

    /// The colour (BGR, alpha ignored) if every pixel of `r` has it, else nil.
    private func solidColour(_ frame: Frame, _ r: FbRect) -> UInt32? {
        let inside = r.intersection(FbRect(x: 0, y: 0, w: frame.width, h: frame.height))
        if inside.isEmpty { return 0 }   // entirely outside the (smaller) screen: black
        if inside != r {
            let px = frame.extract(r)
            return px.withUnsafeBytes { raw -> UInt32? in
                let p = raw.bindMemory(to: UInt32.self)
                let c = p[0] & 0x00FF_FFFF
                for v in p where v & 0x00FF_FFFF != c { return nil }
                return c
            }
        }
        return frame.pixels.withUnsafeBytes { raw -> UInt32? in
            let p = raw.bindMemory(to: UInt32.self)
            let c = p[r.y * frame.width + r.x] & 0x00FF_FFFF
            for yy in r.y..<r.maxY {
                let row = yy * frame.width
                for xx in r.x..<r.maxX where p[row + xx] & 0x00FF_FFFF != c { return nil }
            }
            return c
        }
    }

    private func split(_ r: FbRect, maxW: Int, maxArea: Int) -> [FbRect] {
        var out: [FbRect] = []
        var x = r.x
        while x < r.maxX {
            let w = min(maxW, r.maxX - x)
            let rows = max(1, maxArea / w)
            var y = r.y
            while y < r.maxY {
                let h = min(rows, r.maxY - y)
                out.append(FbRect(x: x, y: y, w: w, h: h))
                y += h
            }
            x += w
        }
        return out
    }

    private func raw(_ frame: Frame, _ r: FbRect, _ fmt: PixelFormat) -> [UInt8] {
        let px = fmt.convert(frame.extract(r))
        var w = ByteWriter(capacity: 12 + px.count)
        w.rectHeader(x: r.x, y: r.y, w: r.w, h: r.h, encoding: encRaw)
        w.append(px)
        return w.bytes
    }

    /// Pixels the way Tight wants them: 3-byte R,G,B TPIXELs for 32 bpp depth 24, else the viewer's format.
    private func tightPixels(_ bgra: [UInt8], _ fmt: PixelFormat) -> [UInt8] {
        guard fmt.usesTPixel else { return fmt.convert(bgra) }
        let n = bgra.count / 4
        var out = [UInt8](repeating: 0, count: n * 3)
        // TPIXELs are always R, G, B in that order, whatever the shifts (as libvncserver and TigerVNC do).
        bgra.withUnsafeBufferPointer { src in
            out.withUnsafeMutableBufferPointer { dst in
                for i in 0..<n {
                    dst[i * 3] = src[i * 4 + 2]
                    dst[i * 3 + 1] = src[i * 4 + 1]
                    dst[i * 3 + 2] = src[i * 4]
                }
            }
        }
        return out
    }

    private func isSolid(_ bgra: [UInt8]) -> Bool {
        bgra.withUnsafeBytes { raw -> Bool in
            let p = raw.bindMemory(to: UInt32.self)
            guard let first = p.first else { return true }
            let c = first & 0x00FF_FFFF
            for v in p where v & 0x00FF_FFFF != c { return false }
            return true
        }
    }

    private func tight(_ frame: Frame, _ r: FbRect, _ s: EncodeSettings, jpegOK: Bool) -> [[UInt8]] {
        let bgra = frame.extract(r)
        var w = ByteWriter(capacity: 64)
        w.rectHeader(x: r.x, y: r.y, w: r.w, h: r.h, encoding: encTight)

        if isSolid(bgra) {
            w.u8(0x80)   // fill
            w.append(tightPixels(Array(bgra[0..<4]), s.format))
            return [w.bytes]
        }

        if jpegOK, let level = s.qualityLevel, let jpeg = jpeg,
           let data = jpeg.encode(bgra: bgra, width: r.w, height: r.h,
                                  quality: jpegQualityForLevel[max(0, min(9, level))]),
           data.count <= maxCompactLength {
            w.u8(0x90)   // JPEG
            w.compactLength(data.count)
            w.append(data)
            return [w.bytes]
        }

        if r.w * r.h > 65536 {
            // Only reached when a JPEG piece failed: redo it as basic in smaller pieces.
            return split(r, maxW: 2048, maxArea: 65536).flatMap { tight(frame, $0, s, jpegOK: false) }
        }

        // Basic, copy filter, zlib stream 0.
        let px = tightPixels(bgra, s.format)
        w.u8(0x00)
        if px.count < 12 {
            w.append(px)
            return [w.bytes]
        }
        if zlib == nil { zlib = DeflateStream(level: s.compressLevel) }
        zlib!.setLevel(s.compressLevel)
        guard let z = zlib!.compress(px), z.count <= maxCompactLength else {
            // zlib failed (should not happen): Raw is always allowed.
            return [raw(frame, r, s.format)]
        }
        w.compactLength(z.count)
        w.append(z)
        return [w.bytes]
    }
}
