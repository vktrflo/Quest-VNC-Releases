#!/bin/bash
# Installs Quest VNC Server for this user (no admin password needed):
#   builds it, puts "Quest VNC Server.app" in ~/Applications, writes the settings file and a
#   LaunchAgent so it starts at login (and restarts after an update), then starts it.
# Double-click (the first time: right-click > Open). To remove it again, run in Terminal:
#   ./install.command --uninstall
cd "$(dirname "$0")" || exit 1

LABEL=com.questvnc.server
APP="$HOME/Applications/Quest VNC Server.app"
EXE="$APP/Contents/MacOS/QuestVncServer"
STAGING="$HOME/Applications/.QuestVncServer-update"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
CONF_DIR="$HOME/Library/Application Support/QuestVncServer"
CONF="$CONF_DIR/server.conf"
LOG="$HOME/Library/Logs/QuestVncServer.log"
DOMAIN="gui/$(id -u)"

pause_and_exit() {
  echo "Press Enter to close."
  read -r _
  exit "$1"
}

agent_loaded() {
  launchctl print "$DOMAIN/$LABEL" >/dev/null 2>&1
}

stop_agent() {
  if agent_loaded; then
    launchctl bootout "$DOMAIN/$LABEL" 2>/dev/null || launchctl unload "$AGENT" 2>/dev/null
    # bootout returns before the job is fully gone; wait so a following bootstrap doesn't fail.
    for _ in 1 2 3 4 5 6 7 8 9 10; do
      agent_loaded || break
      sleep 1
    done
  fi
}

start_agent() {
  launchctl enable "$DOMAIN/$LABEL" 2>/dev/null
  launchctl bootstrap "$DOMAIN" "$AGENT" 2>/dev/null || launchctl load -w "$AGENT"
}

# Escapes text for an XML plist.
xml() {
  local s=$1
  s=${s//&/&amp;}
  s=${s//</&lt;}
  s=${s//>/&gt;}
  printf '%s' "$s"
}

if [ "${1:-}" = "--uninstall" ]; then
  echo "Removing Quest VNC Server..."
  stop_agent
  rm -f "$AGENT"
  rm -rf "$APP" "$STAGING"
  # Forget the permissions given to the app (only this app's entries; errors don't matter).
  tccutil reset ScreenCapture "$LABEL" >/dev/null 2>&1
  tccutil reset Accessibility "$LABEL" >/dev/null 2>&1
  if [ -f "$CONF" ]; then
    printf 'Also delete your settings (password and options) in %s? [y/N] ' "$CONF"
    read -r answer
    case "$answer" in
      [yY]*) rm -f "$CONF"; rmdir "$CONF_DIR" 2>/dev/null; echo "Settings deleted." ;;
      *) echo "Settings kept." ;;
    esac
  fi
  rm -f "$LOG"
  echo "Quest VNC Server is uninstalled."
  pause_and_exit 0
fi

if [ -n "${1:-}" ]; then
  echo "Usage: ./install.command            install for this user"
  echo "       ./install.command --uninstall remove it again"
  exit 2
fi

echo "Installing Quest VNC Server for $(id -un)."
echo

# 1. Build (same command as run.command).
if ! xcrun --find swiftc >/dev/null 2>&1; then
  echo "The Xcode Command Line Tools are needed. Install them with:  xcode-select --install"
  echo "then run this again."
  pause_and_exit 1
fi
BUILD=$(mktemp -d "${TMPDIR:-/tmp}/questvnc-build.XXXXXX") || pause_and_exit 1
trap 'rm -rf "$BUILD"' EXIT
echo "Building (takes a minute)..."
if ! swiftc -O -target "$(uname -m)-apple-macos13.0" ./*.swift -import-objc-header zlib-bridge.h -lz -o "$BUILD/QuestVncServer"; then
  echo "Build failed (see the messages above). Nothing was installed."
  pause_and_exit 1
fi

# 2. Wrap it as an app and sign it (ad hoc): the program does this itself.
if ! "$BUILD/QuestVncServer" --make-app "$BUILD/Quest VNC Server.app"; then
  echo "Couldn't make the app. Nothing was installed."
  pause_and_exit 1
fi

# 3. Settings file (kept if it already exists; it holds the password, so only you can read it).
mkdir -p "$CONF_DIR"
if [ -f "$CONF" ]; then
  echo "Keeping your settings in $CONF"
else
  echo
  echo "Choose a VNC password. You type the same one for this Mac in Quest VNC."
  echo "Only the first 8 characters count; use plain letters and digits."
  echo "Leave it empty for no password (then anyone on your network can see and control this Mac)."
  while true; do
    printf 'Password: '
    read -rs pw1; echo
    [ -z "$pw1" ] && break
    printf 'Same password again: '
    read -rs pw2; echo
    [ "$pw1" = "$pw2" ] && break
    echo "They don't match, try again."
  done
  (
    umask 077
    {
      echo "# Quest VNC Server settings: one option per line, like on the command line."
      echo "# See README.md for the list. Changes apply after a restart (log out and in, or"
      echo "# run: launchctl kickstart -k $DOMAIN/$LABEL)."
      if [ -n "$pw1" ]; then
        echo "--password $pw1"
      else
        echo "# --password yoursecret"
      fi
      echo "# --port 5900"
      echo "# --fps 30"
    } > "$CONF"
  )
  if [ ${#pw1} -gt 8 ]; then
    echo "Note: only the first 8 characters of the password count."
  fi
  unset pw1 pw2
fi
chmod 600 "$CONF"

# 4. Stop a running copy, then put the new app in place.
stop_agent
mkdir -p "$HOME/Applications"
rm -rf "$APP" "$STAGING"
if ! mv "$BUILD/Quest VNC Server.app" "$APP"; then
  echo "Couldn't copy the app to $APP."
  pause_and_exit 1
fi

# 5. LaunchAgent: start at login, start again if it stops (also after an update), log to a file.
mkdir -p "$HOME/Library/LaunchAgents" "$HOME/Library/Logs"
cat > "$AGENT" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>$LABEL</string>
	<key>ProgramArguments</key>
	<array>
		<string>$(xml "$EXE")</string>
	</array>
	<key>RunAtLoad</key>
	<true/>
	<key>KeepAlive</key>
	<true/>
	<key>LimitLoadToSessionType</key>
	<string>Aqua</string>
	<key>ProcessType</key>
	<string>Interactive</string>
	<key>StandardOutPath</key>
	<string>$(xml "$LOG")</string>
	<key>StandardErrorPath</key>
	<string>$(xml "$LOG")</string>
</dict>
</plist>
EOF
plutil -lint "$AGENT" >/dev/null || { echo "The LaunchAgent file is invalid: $AGENT"; pause_and_exit 1; }

# A new build has a new signature: clear this app's old permission entries (they would look "on" but
# not work), so macOS asks again. Best effort; only this app's entries.
tccutil reset ScreenCapture "$LABEL" >/dev/null 2>&1
tccutil reset Accessibility "$LABEL" >/dev/null 2>&1

if ! start_agent; then
  echo "Couldn't start it with launchctl. It will start the next time you log in."
fi

cat <<EOF

Quest VNC Server is installed in $APP
and starts by itself when you log in. Settings: $CONF
Log: $LOG

Now macOS asks for two permissions for "Quest VNC Server":
  * Screen & System Audio Recording (called Screen Recording before macOS 15)
  * Accessibility (for the headset's mouse and keyboard)
Turn both on in System Settings > Privacy & Security. The server starts again by itself
within a minute after that.

Note: updates install themselves. Because this app is not signed with a Developer ID,
macOS asks for both permissions again after each update; turn them on again then.
To uninstall later, run ./install.command --uninstall from this folder (or from any newer download).
EOF
pause_and_exit 0
