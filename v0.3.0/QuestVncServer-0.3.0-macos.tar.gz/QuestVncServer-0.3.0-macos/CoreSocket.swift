// Blocking POSIX TCP sockets: a dual-stack listener and a buffered connection.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

#if canImport(Glibc)
private let sockStream = Int32(SOCK_STREAM.rawValue)
#else
private let sockStream = SOCK_STREAM
#endif

struct SocketError: Error, CustomStringConvertible {
    let description: String
}

/// Listens on all interfaces (IPv6 dual-stack when possible, else IPv4).
final class Listener {
    let fd: Int32

    init(port: Int) throws {
        signal(SIGPIPE, SIG_IGN)
        var on: Int32 = 1, off: Int32 = 0
        var fd = socket(AF_INET6, sockStream, 0)
        if fd >= 0 {
            setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, socklen_t(MemoryLayout<Int32>.size))
            setsockopt(fd, Int32(IPPROTO_IPV6), IPV6_V6ONLY, &off, socklen_t(MemoryLayout<Int32>.size))
            var a = sockaddr_in6()
            #if canImport(Darwin)
            a.sin6_len = UInt8(MemoryLayout<sockaddr_in6>.size)
            #endif
            a.sin6_family = sa_family_t(AF_INET6)
            a.sin6_port = in_port_t(UInt16(port).bigEndian)
            a.sin6_addr = in6addr_any
            let rc = withUnsafePointer(to: &a) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in6>.size)) }
            }
            if rc != 0 {
                let err = errno
                close(fd)
                fd = -1
                if err == EADDRINUSE { throw SocketError(description: "port \(port) is already in use (is another VNC server running?)") }
            }
        }
        if fd < 0 {
            fd = socket(AF_INET, sockStream, 0)
            guard fd >= 0 else { throw SocketError(description: "can't create a socket") }
            setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, socklen_t(MemoryLayout<Int32>.size))
            var a = sockaddr_in()
            #if canImport(Darwin)
            a.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
            #endif
            a.sin_family = sa_family_t(AF_INET)
            a.sin_port = in_port_t(UInt16(port).bigEndian)
            a.sin_addr.s_addr = 0
            let rc = withUnsafePointer(to: &a) {
                $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { bind(fd, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) }
            }
            if rc != 0 {
                let msg = String(cString: strerror(errno))
                close(fd)
                throw SocketError(description: "can't listen on port \(port): \(msg)")
            }
        }
        guard listen(fd, 16) == 0 else {
            close(fd)
            throw SocketError(description: "can't listen on port \(port)")
        }
        self.fd = fd
    }

    /// Waits for the next connection. Returns the socket and the peer's address.
    func accept() -> (Int32, String)? {
        var storage = sockaddr_storage()
        var len = socklen_t(MemoryLayout<sockaddr_storage>.size)
        let c = withUnsafeMutablePointer(to: &storage) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) { Glue.accept(fd, $0, &len) }
        }
        if c < 0 { return nil }
        var on: Int32 = 1
        setsockopt(c, Int32(IPPROTO_TCP), TCP_NODELAY, &on, socklen_t(MemoryLayout<Int32>.size))
        #if canImport(Darwin)
        setsockopt(c, SOL_SOCKET, SO_NOSIGPIPE, &on, socklen_t(MemoryLayout<Int32>.size))
        #endif
        var host = [CChar](repeating: 0, count: 128)
        let rc = withUnsafePointer(to: &storage) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                getnameinfo($0, len, &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST)
            }
        }
        var peer = rc == 0 ? String(cString: host) : "unknown"
        if peer.hasPrefix("::ffff:") { peer.removeFirst(7) }
        return (c, peer)
    }
}

/// Free-function shims so the methods above can call the C functions of the same name.
enum Glue {
    static func accept(_ fd: Int32, _ a: UnsafeMutablePointer<sockaddr>, _ l: UnsafeMutablePointer<socklen_t>) -> Int32 {
        #if canImport(Darwin)
        return Darwin.accept(fd, a, l)
        #else
        return Glibc.accept(fd, a, l)
        #endif
    }
    static func close(_ fd: Int32) {
        #if canImport(Darwin)
        _ = Darwin.close(fd)
        #else
        _ = Glibc.close(fd)
        #endif
    }
}

/// A connected socket with a read buffer. Reads happen on one thread, writes on one (other) thread.
final class Connection {
    let fd: Int32
    private var buf = [UInt8](repeating: 0, count: 65536)
    private var start = 0, end = 0
    private let lock = NSLock()
    private var isShut = false

    init(fd: Int32) { self.fd = fd }

    private func fill() -> Bool {
        if start == end { start = 0; end = 0 }
        if end == buf.count {
            // Move what's left to the front.
            let n = end - start
            for i in 0..<n { buf[i] = buf[start + i] }
            start = 0; end = n
        }
        while true {
            let n = buf.withUnsafeMutableBytes { recv(fd, $0.baseAddress! + end, $0.count - end, 0) }
            if n > 0 { end += n; return true }
            if n < 0 && errno == EINTR { continue }
            return false
        }
    }

    func readBytes(_ count: Int) -> [UInt8]? {
        var out = [UInt8]()
        out.reserveCapacity(count)
        while out.count < count {
            if start == end && !fill() { return nil }
            let take = min(count - out.count, end - start)
            out.append(contentsOf: buf[start..<(start + take)])
            start += take
        }
        return out
    }

    func skip(_ count: Int) -> Bool {
        var left = count
        while left > 0 {
            if start == end && !fill() { return false }
            let take = min(left, end - start)
            start += take
            left -= take
        }
        return true
    }

    func u8() -> UInt8? {
        if start == end && !fill() { return nil }
        let v = buf[start]
        start += 1
        return v
    }

    func u16() -> Int? {
        guard let b = readBytes(2) else { return nil }
        return Int(b[0]) << 8 | Int(b[1])
    }

    func u32() -> UInt32? {
        guard let b = readBytes(4) else { return nil }
        return UInt32(b[0]) << 24 | UInt32(b[1]) << 16 | UInt32(b[2]) << 8 | UInt32(b[3])
    }

    func write(_ bytes: [UInt8]) -> Bool {
        bytes.withUnsafeBytes { raw -> Bool in
            var off = 0
            while off < raw.count {
                #if canImport(Glibc)
                let n = send(fd, raw.baseAddress! + off, raw.count - off, Int32(MSG_NOSIGNAL))
                #else
                let n = send(fd, raw.baseAddress! + off, raw.count - off, 0)
                #endif
                if n > 0 { off += n; continue }
                if n < 0 && errno == EINTR { continue }
                return false
            }
            return true
        }
    }

    /// Wakes up any blocked read or write; the descriptor itself is closed by close().
    func shutdownBoth() {
        lock.lock(); defer { lock.unlock() }
        if !isShut {
            isShut = true
            #if canImport(Glibc)
            _ = shutdown(fd, Int32(SHUT_RDWR))
            #else
            _ = shutdown(fd, SHUT_RDWR)
            #endif
        }
    }

    func close() {
        shutdownBoth()
        Glue.close(fd)
    }
}
