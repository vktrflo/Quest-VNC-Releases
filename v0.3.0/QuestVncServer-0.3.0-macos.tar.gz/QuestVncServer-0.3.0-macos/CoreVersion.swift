// Release number of Quest VNC Server; package.sh writes it from server/VERSION.
let questVncVersion = "0.3.0"
