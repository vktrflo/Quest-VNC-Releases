// macOS screen and sound capture with ScreenCaptureKit: one SCStream on the chosen display gives
// BGRA frames (cursor included) and the system sound.

import AVFoundation
import CoreGraphics
import CoreMedia
import CoreVideo
import Foundation
import ScreenCaptureKit

let screenPermissionHelp = """
    macOS didn't allow screen capture. Open System Settings > Privacy & Security >
    Screen & System Audio Recording (called "Screen Recording" before macOS 15), turn it on for
    Terminal (or the app you started this from), then quit Terminal and run this again.
    """

/// Where the shared display sits on the desktop, in global points (for mapping viewer input).
final class DisplayGeometry {
    private let lock = NSLock()
    private var _frame = CGRect(x: 0, y: 0, width: 1, height: 1)

    var frame: CGRect {
        get { lock.lock(); defer { lock.unlock() }; return _frame }
        set { lock.lock(); _frame = newValue; lock.unlock() }
    }
}

@available(macOS 13.0, *)
final class ScreenCapture: NSObject, SCStreamOutput, SCStreamDelegate, @unchecked Sendable {
    let options: Options
    let audio: AudioHub
    let geometry = DisplayGeometry()
    private(set) var frames: FrameStore?
    private(set) var displayID: CGDirectDisplayID = 0
    private(set) var displayIndex = 0
    private(set) var displayCount = 0
    private(set) var width = 0
    private(set) var height = 0
    private(set) var capturingAudio = false

    private var stream: SCStream?
    private var config: SCStreamConfiguration?
    private var filter: SCContentFilter?
    private let videoQueue = DispatchQueue(label: "questvnc.capture.video")
    private let audioQueue = DispatchQueue(label: "questvnc.capture.audio")
    private var sizeTimer: Timer?
    private var restarting = false

    init(options: Options, audio: AudioHub) {
        self.options = options
        self.audio = audio
    }

    /// Size to capture at: points by default (Retina pixel sizes are huge), pixels with --full-res.
    private func captureSize(for id: CGDirectDisplayID) -> (Int, Int) {
        let bounds = CGDisplayBounds(id)
        var w = Int(bounds.width), h = Int(bounds.height)
        if options.fullRes, let mode = CGDisplayCopyDisplayMode(id) {
            w = mode.pixelWidth
            h = mode.pixelHeight
        }
        return (max(w, 1), max(h, 1))
    }

    /// Starts capturing. `done` runs on the main thread with nil on success or an error message.
    func start(_ completion: @escaping @Sendable (String?) -> Void) {
        let done: @Sendable (String?) -> Void = { msg in DispatchQueue.main.async { completion(msg) } }
        SCShareableContent.getExcludingDesktopWindows(false, onScreenWindowsOnly: true) { content, error in
            guard let content = content, !content.displays.isEmpty else {
                done(screenPermissionHelp + "\n(\(error?.localizedDescription ?? "no displays found"))")
                return
            }
            // Main display first, then the others in the order macOS lists them.
            let main = CGMainDisplayID()
            let displays = content.displays.filter { $0.displayID == main } + content.displays.filter { $0.displayID != main }
            guard self.options.monitor < displays.count else {
                done("There is no display \(self.options.monitor): this Mac has \(displays.count) (0 to \(displays.count - 1)).")
                return
            }
            let display = displays[self.options.monitor]
            self.displayIndex = self.options.monitor
            self.displayCount = displays.count
            self.displayID = display.displayID
            self.geometry.frame = CGDisplayBounds(display.displayID)
            let (w, h) = self.captureSize(for: display.displayID)
            self.width = w
            self.height = h
            if self.frames == nil { self.frames = FrameStore(width: w, height: h) }

            let cfg = SCStreamConfiguration()
            cfg.width = w
            cfg.height = h
            cfg.pixelFormat = kCVPixelFormatType_32BGRA
            cfg.colorSpaceName = CGColorSpace.sRGB
            cfg.showsCursor = true
            cfg.minimumFrameInterval = CMTime(value: 1, timescale: CMTimeScale(self.options.fps))
            cfg.queueDepth = 5
            let wantAudio = !self.options.noAudio && !self.options.testTone
            cfg.capturesAudio = wantAudio
            if wantAudio {
                cfg.excludesCurrentProcessAudio = true
                cfg.sampleRate = 48000
                cfg.channelCount = 2
            }
            let filter = SCContentFilter(display: display, excludingApplications: [], exceptingWindows: [])
            let s = SCStream(filter: filter, configuration: cfg, delegate: self)
            do {
                try s.addStreamOutput(self, type: .screen, sampleHandlerQueue: self.videoQueue)
            } catch {
                done("Can't capture the screen: \(error.localizedDescription)")
                return
            }
            let audioOK: Bool
            if wantAudio {
                do {
                    try s.addStreamOutput(self, type: .audio, sampleHandlerQueue: self.audioQueue)
                    audioOK = true
                } catch {
                    log("Sound capture isn't available (\(error.localizedDescription)); the screen still works.")
                    audioOK = false
                }
            } else {
                audioOK = false
            }
            s.startCapture { err in
                if let err = err {
                    done(screenPermissionHelp + "\n(\(err.localizedDescription))")
                    return
                }
                DispatchQueue.main.async {
                    self.stream = s
                    self.config = cfg
                    self.filter = filter
                    self.capturingAudio = audioOK
                    self.restarting = false
                    completion(nil)
                }
            }
        }
    }

    /// Watches for resolution changes (and display moves) every 2 seconds; must run on the main thread.
    func watchDisplayChanges() {
        sizeTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            self?.refreshSize()
        }
    }

    /// Makes the stream follow the display's current size. Main thread.
    func refreshSize() {
        guard let stream = stream, let cfg = config else { return }
        geometry.frame = CGDisplayBounds(displayID)
        let (w, h) = captureSize(for: displayID)
        guard w != width || h != height else { return }
        log("Screen size changed to \(w)x\(h)")
        width = w
        height = h
        cfg.width = w
        cfg.height = h
        stream.updateConfiguration(cfg) { err in
            if let err = err { log("Couldn't follow the new screen size: \(err.localizedDescription)") }
        }
    }

    // MARK: - SCStreamOutput

    func stream(_ stream: SCStream, didOutputSampleBuffer sampleBuffer: CMSampleBuffer, of type: SCStreamOutputType) {
        guard sampleBuffer.isValid else { return }
        switch type {
        case .screen: handleVideo(sampleBuffer)
        case .audio: handleAudio(sampleBuffer)
        default: break
        }
    }

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        log("Screen capture stopped: \(error.localizedDescription). Restarting in 3 seconds...")
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            guard !self.restarting else { return }
            self.restarting = true
            self.stream = nil
            self.start { err in
                if let err = err {
                    log(err)
                    exit(1)
                }
                log("Screen capture running again")
            }
        }
    }

    private func handleVideo(_ sb: CMSampleBuffer) {
        // Only "complete" frames carry an image; idle/blank ones mean nothing changed.
        guard let attachments = CMSampleBufferGetSampleAttachmentsArray(sb, createIfNecessary: false)
                as? [[SCStreamFrameInfo: Any]],
              let info = attachments.first,
              let statusRaw = info[SCStreamFrameInfo.status] as? Int,
              let status = SCFrameStatus(rawValue: statusRaw), status == .complete,
              let pb = CMSampleBufferGetImageBuffer(sb), let frames = frames else { return }
        CVPixelBufferLockBaseAddress(pb, .readOnly)
        defer { CVPixelBufferUnlockBaseAddress(pb, .readOnly) }
        guard let base = CVPixelBufferGetBaseAddress(pb) else { return }
        frames.submit(width: CVPixelBufferGetWidth(pb), height: CVPixelBufferGetHeight(pb),
                      bytesPerRow: CVPixelBufferGetBytesPerRow(pb), base: UnsafeRawPointer(base))
    }

    private var floatBuf: [Float] = []

    /// ScreenCaptureKit sound is 32-bit float, usually one buffer per channel; hand it on interleaved.
    private func handleAudio(_ sb: CMSampleBuffer) {
        guard let fmtDesc = sb.formatDescription,
              let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(fmtDesc)?.pointee else { return }
        var blockBuffer: CMBlockBuffer?
        var sizeNeeded = 0
        CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sb, bufferListSizeNeededOut: &sizeNeeded,
            bufferListOut: nil, bufferListSize: 0, blockBufferAllocator: nil, blockBufferMemoryAllocator: nil,
            flags: 0, blockBufferOut: nil)
        guard sizeNeeded > 0 else { return }
        let abl = UnsafeMutableRawPointer.allocate(byteCount: sizeNeeded, alignment: 16)
        defer { abl.deallocate() }
        let listPtr = abl.bindMemory(to: AudioBufferList.self, capacity: 1)
        guard CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sb, bufferListSizeNeededOut: nil,
            bufferListOut: listPtr, bufferListSize: sizeNeeded, blockBufferAllocator: nil,
            blockBufferMemoryAllocator: nil, flags: kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment,
            blockBufferOut: &blockBuffer) == noErr else { return }

        let buffers = UnsafeMutableAudioBufferListPointer(listPtr)
        let isFloat = asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0
        let nonInterleaved = asbd.mFormatFlags & kAudioFormatFlagIsNonInterleaved != 0
        let channels = Int(asbd.mChannelsPerFrame)
        let rate = Int(asbd.mSampleRate)
        guard isFloat, asbd.mBitsPerChannel == 32, channels > 0, rate > 0 else { return }
        let frames = CMSampleBufferGetNumSamples(sb)
        guard frames > 0 else { return }

        if floatBuf.count != frames * channels { floatBuf = [Float](repeating: 0, count: frames * channels) }
        floatBuf.withUnsafeMutableBufferPointer { dst in
            if nonInterleaved {
                for c in 0..<channels {
                    guard c < buffers.count, let p = buffers[c].mData?.assumingMemoryBound(to: Float.self) else { continue }
                    let n = min(frames, Int(buffers[c].mDataByteSize) / 4)
                    for f in 0..<n { dst[f * channels + c] = p[f] }
                }
            } else if let p = buffers[0].mData?.assumingMemoryBound(to: Float.self) {
                let n = min(frames * channels, Int(buffers[0].mDataByteSize) / 4)
                for i in 0..<n { dst[i] = p[i] }
            }
        }
        floatBuf.withUnsafeBufferPointer { audio.push($0, channels: channels, rate: rate) }
    }
}
