// Sound for the QEMU audio extension: sample formats, a linear-interpolation resampler, the hub
// that hands captured sound to every listening viewer, and the --test-tone generator.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// QEMU audio sample formats.
enum SampleFormat: UInt8 {
    case u8 = 0, s8 = 1, u16 = 2, s16 = 3, u32 = 4, s32 = 5

    var bytes: Int {
        switch self {
        case .u8, .s8: return 1
        case .u16, .s16: return 2
        case .u32, .s32: return 4
        }
    }
}

struct AudioFormat: Equatable {
    var sample: SampleFormat = .s16
    var channels = 2
    var rate = 48000

    var bytesPerFrame: Int { sample.bytes * channels }
}

/// Converts float sound (interleaved, any channel count and rate) into a viewer's format.
/// Keeps its position between calls so consecutive chunks join up without clicks.
final class PcmConverter {
    let out: AudioFormat
    private var srcRate = 0
    private var srcChannels = 0
    private var t = 0.0            // read position in source frames, relative to the current chunk
    private var prev: [Float] = [] // last source frame of the previous chunk (index -1)

    init(_ out: AudioFormat) { self.out = out }

    func convert(_ src: UnsafeBufferPointer<Float>, channels: Int, rate: Int) -> [UInt8] {
        guard channels > 0, rate > 0 else { return [] }
        let frames = src.count / channels
        guard frames > 0 else { return [] }
        if channels != srcChannels || rate != srcRate {
            srcChannels = channels
            srcRate = rate
            t = 0
            prev = []
        }
        let step = Double(rate) / Double(out.rate)
        let outCh = out.channels
        let estimate = Int(Double(frames) / step) + 2
        var result = [UInt8]()
        result.reserveCapacity(estimate * out.bytesPerFrame)
        var frameBuf = [Float](repeating: 0, count: outCh)

        // Value of source channel `c` at source frame `i` (i = -1 is the previous chunk's last frame).
        @inline(__always) func sample(_ i: Int, _ c: Int) -> Float {
            if i < 0 { return prev.isEmpty ? 0 : prev[c] }
            return src[i * channels + c]
        }
        @inline(__always) func mapped(_ i: Int, _ oc: Int) -> Float {
            if outCh == 1 && channels > 1 {
                var sum: Float = 0
                for c in 0..<channels { sum += sample(i, c) }
                return sum / Float(channels)
            }
            return sample(i, min(oc, channels - 1))
        }

        if prev.isEmpty && t < 0 { t = 0 }
        // Interpolate between frames i and i+1; a position exactly on the last frame is produced
        // by the next chunk (as index -1), so nothing is skipped or doubled.
        while t < Double(frames - 1) {
            let i = Int(t.rounded(.down))
            let frac = Float(t - Double(i))
            for oc in 0..<outCh {
                let a = mapped(i, oc)
                let b = mapped(i + 1, oc)
                frameBuf[oc] = a + (b - a) * frac
            }
            append(frameBuf, to: &result)
            t += step
        }
        t -= Double(frames)
        prev = (0..<channels).map { src[(frames - 1) * channels + $0] }
        return result
    }

    private func append(_ f: [Float], to out: inout [UInt8]) {
        for v0 in f {
            let v = Double(max(-1, min(1, v0)))
            switch self.out.sample {
            case .s16, .u16:
                var s = Int32((v * 32767).rounded())
                if self.out.sample == .u16 { s += 32768 }
                let u = UInt16(truncatingIfNeeded: s)
                out.append(UInt8(truncatingIfNeeded: u)); out.append(UInt8(truncatingIfNeeded: u >> 8))
            case .s8:
                out.append(UInt8(bitPattern: Int8((v * 127).rounded())))
            case .u8:
                out.append(UInt8(Int((v * 127).rounded()) + 128))
            case .s32, .u32:
                var u = UInt32(bitPattern: Int32((v * 2147483647.0).rounded()))
                if self.out.sample == .u32 { u ^= 0x8000_0000 }
                out.append(UInt8(truncatingIfNeeded: u)); out.append(UInt8(truncatingIfNeeded: u >> 8))
                out.append(UInt8(truncatingIfNeeded: u >> 16)); out.append(UInt8(truncatingIfNeeded: u >> 24))
            }
        }
    }
}

/// Fans captured sound out to the viewers that enabled it.
final class AudioHub {
    /// True when sound capture (or the test tone) is running; only then is -259 acknowledged.
    var available = false
    private let lock = NSLock()
    private var sinks: [Int: (UnsafeBufferPointer<Float>, Int, Int) -> Void] = [:]
    private var nextId = 0

    func addSink(_ f: @escaping (UnsafeBufferPointer<Float>, Int, Int) -> Void) -> Int {
        lock.lock(); defer { lock.unlock() }
        nextId += 1
        sinks[nextId] = f
        return nextId
    }

    func removeSink(_ id: Int) {
        lock.lock(); defer { lock.unlock() }
        sinks[id] = nil
    }

    /// Interleaved float samples from the capture thread.
    func push(_ samples: UnsafeBufferPointer<Float>, channels: Int, rate: Int) {
        lock.lock()
        let all = Array(sinks.values)
        lock.unlock()
        for s in all { s(samples, channels, rate) }
    }
}

/// --test-tone: a 440 Hz beep (a quarter second) every second, stereo 48 kHz, in 10 ms chunks.
final class TestTone {
    private let hub: AudioHub

    init(hub: AudioHub) { self.hub = hub }

    func start() {
        let t = Thread { [hub] in
            let rate = 48000, chunk = 480
            var frame = 0
            let start = monotonicSeconds()
            var buf = [Float](repeating: 0, count: chunk * 2)
            while true {
                for i in 0..<chunk {
                    let on = frame % rate < rate / 4
                    let v: Float = on ? Float(sin(2 * Double.pi * 440 * Double(frame) / Double(rate)) * 0.2) : 0
                    buf[i * 2] = v
                    buf[i * 2 + 1] = v
                    frame += 1
                }
                buf.withUnsafeBufferPointer { hub.push($0, channels: 2, rate: rate) }
                // Pace by the clock so the tone neither drifts nor bunches up.
                let due = start + Double(frame) / Double(rate)
                let wait = due - monotonicSeconds()
                if wait > 0 { usleep(UInt32(wait * 1_000_000)) }
            }
        }
        t.name = "test-tone"
        t.start()
    }
}
