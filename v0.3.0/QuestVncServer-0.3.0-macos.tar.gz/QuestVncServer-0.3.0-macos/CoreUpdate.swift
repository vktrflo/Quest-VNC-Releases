// Self-update, the platform-neutral part: version compare, the release feed, download checks and
// the update steps. The platform supplies the download, the install (build + swap) and the viewer
// count, so all of this is tested on Linux with fakes (see test/unit/).

import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

let defaultUpdateURL = "https://raw.githubusercontent.com/vktrflo/Quest-VNC-Releases/main/latest.json"
/// The key of this platform in the feed's "platforms".
let updatePlatformKey = "macos"

/// A numeric dotted version (major.minor.patch; missing parts count as 0).
struct Version: Comparable, CustomStringConvertible {
    let parts: [Int]

    init?(_ s: String) {
        var t = s.trimmingCharacters(in: .whitespaces)
        if t.hasPrefix("v") || t.hasPrefix("V") { t.removeFirst() }
        let p = t.split(separator: ".", omittingEmptySubsequences: false)
        guard (1...3).contains(p.count) else { return nil }
        var out: [Int] = []
        for x in p {
            guard !x.isEmpty, x.allSatisfy({ $0.isASCII && $0.isNumber }), let n = Int(x) else { return nil }
            out.append(n)
        }
        while out.count < 3 { out.append(0) }
        parts = out
    }

    static func < (a: Version, b: Version) -> Bool { a.parts.lexicographicallyPrecedes(b.parts) }
    var description: String { parts.map(String.init).joined(separator: ".") }
}

/// This platform's entry of the release feed.
struct ReleaseInfo: Equatable {
    var version: String
    var notes: String
    var url: String
    var sha256: String
    var size: Int
}

struct UpdateError: Error, CustomStringConvertible {
    let description: String
    init(_ d: String) { description = d }
}

/// Parses latest.json and picks this platform's payload.
func parseReleaseFeed(_ data: Data, platform: String = updatePlatformKey) throws -> ReleaseInfo {
    guard let root = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
        throw UpdateError("the release feed isn't valid JSON")
    }
    guard let version = root["version"] as? String, Version(version) != nil else {
        throw UpdateError("the release feed has no valid version")
    }
    guard let plats = root["platforms"] as? [String: Any], let p = plats[platform] as? [String: Any] else {
        throw UpdateError("the release feed has nothing for \(platform)")
    }
    guard let url = p["url"] as? String, let u = URL(string: url), let scheme = u.scheme?.lowercased(),
          scheme == "https" || scheme == "http" else {
        throw UpdateError("the release feed has no valid download address for \(platform)")
    }
    guard let sha = p["sha256"] as? String, sha.count == 64, sha.allSatisfy({ $0.isHexDigit }) else {
        throw UpdateError("the release feed has no valid sha256 for \(platform)")
    }
    // JSON numbers come back as NSNumber (Int or Double depending on the platform).
    guard let sizeNum = p["size"] as? NSNumber, sizeNum.intValue > 0, Double(sizeNum.intValue) == sizeNum.doubleValue else {
        throw UpdateError("the release feed has no valid size for \(platform)")
    }
    return ReleaseInfo(version: version, notes: (root["notes"] as? String) ?? "", url: url,
                       sha256: sha.lowercased(), size: sizeNum.intValue)
}

/// Checks a downloaded payload against the feed. Returns nil when it matches, else the reason.
func verifyPayload(path: String, release: ReleaseInfo) -> String? {
    let attrs = try? FileManager.default.attributesOfItem(atPath: path)
    guard let size = (attrs?[.size] as? NSNumber)?.intValue else { return "the download is missing" }
    if size != release.size { return "size is \(size) bytes, expected \(release.size)" }
    guard let sum = sha256Hex(ofFile: path) else { return "can't read the download" }
    if sum != release.sha256 { return "sha256 is \(sum), expected \(release.sha256)" }
    return nil
}

/// HTTPS access for the updater.
protocol UpdateTransport {
    func fetch(_ url: String, timeout: Double) throws -> Data
    func download(_ url: String, to path: String, timeout: Double) throws
}

/// Turns a verified payload into the new install, then swaps it in.
protocol UpdateInstaller {
    /// Slow part (macOS: extract and build). Runs once nobody is connected; may throw with the reason.
    func prepare(payload: String, release: ReleaseInfo) throws
    /// Quick part: put the new version in place. After this the process exits and is restarted.
    func swap(release: ReleaseInfo) throws
    /// Removes what prepare left behind after a failure.
    func cleanUp()
}

/// Carries a completion handler's result back to the waiting thread (the handlers are @Sendable on
/// macOS, so they can't assign to a captured local variable).
private final class ResultBox<T>: @unchecked Sendable {
    var value: T
    init(_ v: T) { value = v }
}

/// URLSession-based transport (macOS; also builds on Linux with FoundationNetworking).
final class URLSessionTransport: UpdateTransport {
    func fetch(_ url: String, timeout: Double) throws -> Data {
        guard let u = URL(string: url) else { throw UpdateError("bad address \(url)") }
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = timeout
        cfg.timeoutIntervalForResource = timeout
        cfg.requestCachePolicy = .reloadIgnoringLocalCacheData
        let session = URLSession(configuration: cfg)
        defer { session.finishTasksAndInvalidate() }
        let sem = DispatchSemaphore(value: 0)
        let result = ResultBox<Result<Data, Error>>(.failure(UpdateError("no answer")))
        session.dataTask(with: u) { data, resp, err in
            if let err = err {
                result.value = .failure(err)
            } else if let h = resp as? HTTPURLResponse, !(200...299).contains(h.statusCode) {
                result.value = .failure(UpdateError("HTTP \(h.statusCode)"))
            } else {
                result.value = .success(data ?? Data())
            }
            sem.signal()
        }.resume()
        sem.wait()
        return try result.value.get()
    }

    func download(_ url: String, to path: String, timeout: Double) throws {
        guard let u = URL(string: url) else { throw UpdateError("bad address \(url)") }
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 60
        cfg.timeoutIntervalForResource = timeout
        let session = URLSession(configuration: cfg)
        defer { session.finishTasksAndInvalidate() }
        let sem = DispatchSemaphore(value: 0)
        let failure = ResultBox<Error?>(nil)
        session.downloadTask(with: u) { tmp, resp, err in
            defer { sem.signal() }
            if let err = err { failure.value = err; return }
            if let h = resp as? HTTPURLResponse, !(200...299).contains(h.statusCode) {
                failure.value = UpdateError("HTTP \(h.statusCode)"); return
            }
            guard let tmp = tmp else { failure.value = UpdateError("no file"); return }
            // The temp file is deleted when this handler returns, so move it now.
            do {
                try? FileManager.default.removeItem(atPath: path)
                try FileManager.default.moveItem(at: tmp, to: URL(fileURLWithPath: path))
            } catch {
                failure.value = error
            }
        }.resume()
        sem.wait()
        if let f = failure.value { throw f }
    }
}

/// The update steps (see SPEC.md "Update behaviour"). `runOnce` is one check; `start` runs the
/// schedule (60 s after start, then every 12 hours) on a background thread.
final class Updater {
    enum Outcome: Equatable {
        case upToDate
        case availableNotInstalled(String)   // portable copy: only told the user
        case failed(String)
        case installed(String)               // swapped in; the caller restarts
    }

    let currentVersion: String
    let feedURL: String
    let installed: Bool
    let workDir: String
    let transport: UpdateTransport
    let installer: UpdateInstaller?
    let viewerCount: () -> Int
    let sleep: (Double) -> Void
    let say: (String) -> Void
    /// Extra sentence for the "Installing" line (macOS: the permission warning).
    var installNote = ""

    var firstCheckDelay = 60.0
    var checkInterval = 12 * 3600.0
    var viewerPollInterval = 30.0
    var feedTimeout = 30.0
    var payloadTimeout = 600.0

    private var announced: Set<String> = []

    init(currentVersion: String, feedURL: String, installed: Bool, workDir: String,
         transport: UpdateTransport, installer: UpdateInstaller?, viewerCount: @escaping () -> Int,
         sleep: @escaping (Double) -> Void = { Thread.sleep(forTimeInterval: $0) },
         say: @escaping (String) -> Void = { log($0) }) {
        self.currentVersion = currentVersion
        self.feedURL = feedURL
        self.installed = installed
        self.workDir = workDir
        self.transport = transport
        self.installer = installer
        self.viewerCount = viewerCount
        self.sleep = sleep
        self.say = say
    }

    /// Fetches the feed. Returns the release when it is strictly newer than this version, nil when not.
    func check() throws -> ReleaseInfo? {
        let data = try transport.fetch(feedURL, timeout: feedTimeout)
        let r = try parseReleaseFeed(data)
        guard let latest = Version(r.version), let mine = Version(currentVersion) else { return nil }
        return latest > mine ? r : nil
    }

    var payloadPath: String { (workDir as NSString).appendingPathComponent("update-download.tmp") }

    private func waitForNoViewers() {
        while viewerCount() > 0 { sleep(viewerPollInterval) }
    }

    func runOnce() -> Outcome {
        let r: ReleaseInfo
        do {
            guard let found = try check() else { return .upToDate }
            r = found
        } catch {
            return fail("Couldn't check for updates: \(error)")
        }
        let notes = r.notes.isEmpty ? "" : ": \(r.notes)"
        guard installed, let installer = installer else {
            if !announced.contains(r.version) {
                announced.insert(r.version)
                say("Update \(r.version) is available (this is \(currentVersion))\(notes). Download it from the Quest VNC releases page.")
            }
            return .availableNotInstalled(r.version)
        }
        say("Update \(r.version) available\(notes)")
        let fm = FileManager.default
        try? fm.createDirectory(atPath: workDir, withIntermediateDirectories: true)
        let tmp = payloadPath
        defer { try? fm.removeItem(atPath: tmp) }
        do {
            try transport.download(r.url, to: tmp, timeout: payloadTimeout)
        } catch {
            return fail("Couldn't download update \(r.version): \(error). Trying again later.")
        }
        if let why = verifyPayload(path: tmp, release: r) {
            return fail("Refused update \(r.version): \(why). Trying again later.")
        }
        say("Downloaded update \(r.version)")
        waitForNoViewers()
        say("Installing update \(r.version) now (no viewers connected)" + (installNote.isEmpty ? "" : ". " + installNote))
        do {
            try installer.prepare(payload: tmp, release: r)
            waitForNoViewers()   // someone may have connected during the build
            try installer.swap(release: r)
        } catch {
            installer.cleanUp()
            return fail("Update \(r.version) failed, still running \(currentVersion): \(error)")
        }
        say("Update \(r.version) installed, restarting")
        return .installed(r.version)
    }

    private func fail(_ msg: String) -> Outcome {
        say(msg)
        return .failed(msg)
    }

    /// Runs checks forever on a background thread; calls `restart` after a successful install.
    func start(restart: @escaping () -> Void) {
        let t = Thread { [self] in
            sleep(firstCheckDelay)
            while true {
                switch runOnce() {
                case .installed:
                    restart()
                    return
                default: break
                }
                sleep(checkInterval)
            }
        }
        t.name = "updater"
        t.start()
    }
}

/// --check-update: checks once and prints the result. Exit status 0 = up to date, 10 = update
/// available, 1 = the check failed.
func checkForUpdateOnce(feedURL: String, transport: UpdateTransport, currentVersion: String = questVncVersion,
                        say: (String) -> Void = { log($0) }) -> Int32 {
    let u = Updater(currentVersion: currentVersion, feedURL: feedURL, installed: false, workDir: "",
                    transport: transport, installer: nil, viewerCount: { 0 })
    do {
        if let r = try u.check() {
            say("Update \(r.version) is available (this is \(currentVersion))" + (r.notes.isEmpty ? "" : ": \(r.notes)"))
            return 10
        }
        say("Quest VNC Server \(currentVersion) is up to date.")
        return 0
    } catch {
        say("Couldn't check for updates: \(error)")
        return 1
    }
}
