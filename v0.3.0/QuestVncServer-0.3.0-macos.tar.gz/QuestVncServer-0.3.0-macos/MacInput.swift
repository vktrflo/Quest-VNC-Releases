// Viewer keyboard and mouse -> macOS, with CGEvent. Needs the Accessibility permission.
//
// Modifier mapping (a viewer on a PC keyboard):
//   Shift -> Shift, Ctrl -> Control, Alt (Alt_L/Alt_R) and Meta -> Option,
//   Super / Windows key -> Command, Caps Lock -> Caps Lock.
//   AltGr (ISO_Level3_Shift) is not passed on: the viewer already sends the character it produces.
// Printable characters are typed as Unicode text (so the viewer's layout wins over the Mac's),
// except while Command, Control or Option is held: then the US key position for that character is
// pressed, so shortcuts like Command+C work.

import ApplicationServices
import CoreGraphics
import Foundation

/// Asks macOS whether we may control the Mac, showing the system prompt if not.
func checkAccessibility(prompt: Bool) -> Bool {
    let opts = ["AXTrustedCheckOptionPrompt": prompt] as CFDictionary
    return AXIsProcessTrustedWithOptions(opts)
}

final class MacInput: InputSink {
    private let lock = NSLock()
    private let geometry: DisplayGeometry
    private let frames: () -> Frame?
    private let source = CGEventSource(stateID: .hidSystemState)

    private var buttons: UInt8 = 0
    private var lastPoint = CGPoint(x: -1, y: -1)
    private var clickCount = 1
    private var lastClickTime = 0.0
    private var lastClickButton: UInt8 = 0
    private var lastClickPoint = CGPoint.zero
    private var heldModifiers: [UInt32: CGEventFlags] = [:]   // keysym -> flag

    /// Lines scrolled per wheel notch (a PC mouse notch scrolls about 3 lines).
    private let linesPerNotch: Int32 = 3

    init(geometry: DisplayGeometry, frames: @escaping () -> Frame?) {
        self.geometry = geometry
        self.frames = frames
    }

    private var flags: CGEventFlags {
        var f = CGEventFlags()
        for v in heldModifiers.values { f.insert(v) }
        return f
    }

    // MARK: - Pointer

    func pointer(x: Int, y: Int, buttons newButtons: UInt8, wheelUp: Int, wheelLeft: Int) {
        lock.lock()
        defer { lock.unlock() }
        let g = geometry.frame
        let fw = max(1, frames()?.width ?? Int(g.width)), fh = max(1, frames()?.height ?? Int(g.height))
        // Framebuffer pixel -> global screen point (the capture may be scaled, e.g. --full-res).
        let px = g.minX + min(g.width - 1, (CGFloat(x) + 0.5) * g.width / CGFloat(fw))
        let py = g.minY + min(g.height - 1, (CGFloat(y) + 0.5) * g.height / CGFloat(fh))
        let p = CGPoint(x: px.rounded(.down), y: py.rounded(.down))

        if p != lastPoint {
            let type: CGEventType
            let button: CGMouseButton
            if buttons & 1 != 0 { type = .leftMouseDragged; button = .left }
            else if buttons & 4 != 0 { type = .rightMouseDragged; button = .right }
            else if buttons & 2 != 0 { type = .otherMouseDragged; button = .center }
            else { type = .mouseMoved; button = .left }
            post(CGEvent(mouseEventSource: source, mouseType: type, mouseCursorPosition: p, mouseButton: button))
            lastPoint = p
        }

        let changed = buttons ^ newButtons
        let table: [(UInt8, CGEventType, CGEventType, CGMouseButton)] = [
            (1, .leftMouseDown, .leftMouseUp, .left),
            (4, .rightMouseDown, .rightMouseUp, .right),
            (2, .otherMouseDown, .otherMouseUp, .center)]
        for (bit, downType, upType, button) in table where changed & bit != 0 {
            let down = newButtons & bit != 0
            if down {
                let now = monotonicSeconds()
                let near = abs(p.x - lastClickPoint.x) <= 4 && abs(p.y - lastClickPoint.y) <= 4
                clickCount = (bit == lastClickButton && now - lastClickTime < 0.5 && near) ? min(clickCount + 1, 3) : 1
                lastClickTime = now
                lastClickButton = bit
                lastClickPoint = p
            }
            guard let e = CGEvent(mouseEventSource: source, mouseType: down ? downType : upType,
                                  mouseCursorPosition: p, mouseButton: button) else { continue }
            e.setIntegerValueField(.mouseEventClickState, value: Int64(clickCount))
            if button == .center { e.setIntegerValueField(.mouseEventButtonNumber, value: 2) }
            post(e)
        }
        buttons = newButtons

        if wheelUp != 0 || wheelLeft != 0,
           let e = CGEvent(scrollWheelEvent2Source: source, units: .line, wheelCount: 2,
                           wheel1: Int32(wheelUp) * linesPerNotch, wheel2: Int32(wheelLeft) * linesPerNotch, wheel3: 0) {
            e.location = p
            post(e)
        }
    }

    // MARK: - Keyboard

    func key(keysym: UInt32, down: Bool) {
        lock.lock()
        defer { lock.unlock() }

        if let m = Self.modifiers[keysym] {
            let (code, flag) = m
            if let flag = flag {
                if down { heldModifiers[keysym] = flag } else { heldModifiers[keysym] = nil }
            }
            postKey(code, down: down)
            return
        }
        if Self.ignored.contains(keysym) { return }
        if let code = Self.specialKeys[keysym] {
            postKey(code, down: down)
            return
        }
        guard let scalar = Self.unicode(for: keysym) else { return }
        let ch = Character(scalar)
        let lower = String(ch).lowercased().first ?? ch
        let code = Self.ansiKeys[lower] ?? Self.ansiKeys[ch]
        let f = flags
        if !f.intersection([.maskCommand, .maskControl, .maskAlternate]).isEmpty, let code = code {
            // A shortcut: press the key, let the modifiers do the rest.
            postKey(code, down: down)
            return
        }
        // Plain typing: send the character itself, whatever the Mac's keyboard layout.
        guard let e = CGEvent(keyboardEventSource: source, virtualKey: code ?? 0, keyDown: down) else { return }
        var utf16 = Array(String(ch).utf16)
        e.keyboardSetUnicodeString(stringLength: utf16.count, unicodeString: &utf16)
        e.flags = f
        e.post(tap: .cghidEventTap)
    }

    private func postKey(_ code: CGKeyCode, down: Bool) {
        guard let e = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: down) else { return }
        e.flags = flags
        e.post(tap: .cghidEventTap)
    }

    private func post(_ e: CGEvent?) {
        guard let e = e else { return }
        e.flags = flags
        e.post(tap: .cghidEventTap)
    }

    // MARK: - Tables (macOS virtual key codes, from Carbon's Events.h)

    /// X11 modifier keysyms -> key code and the flag they hold down (nil for Caps Lock).
    static let modifiers: [UInt32: (CGKeyCode, CGEventFlags?)] = [
        0xFFE1: (0x38, .maskShift), 0xFFE2: (0x3C, .maskShift),           // Shift_L/R
        0xFFE3: (0x3B, .maskControl), 0xFFE4: (0x3E, .maskControl),       // Control_L/R
        0xFFE9: (0x3A, .maskAlternate), 0xFFEA: (0x3D, .maskAlternate),   // Alt_L/R -> Option
        0xFFE7: (0x3A, .maskAlternate), 0xFFE8: (0x3D, .maskAlternate),   // Meta_L/R -> Option
        0xFFEB: (0x37, .maskCommand), 0xFFEC: (0x36, .maskCommand),       // Super_L/R -> Command
        0xFFE5: (0x39, nil),                                              // Caps_Lock
    ]

    /// AltGr / Mode_switch, Num_Lock: the viewer sends the resulting characters itself.
    static let ignored: Set<UInt32> = [0xFE03, 0xFF7E, 0xFFED, 0xFFEE]

    static let specialKeys: [UInt32: CGKeyCode] = [
        0x0020: 0x31,                                   // space
        0xFF08: 0x33, 0xFF09: 0x30, 0xFE20: 0x30,       // BackSpace, Tab, ISO_Left_Tab
        0xFF0D: 0x24, 0xFF1B: 0x35, 0xFFFF: 0x75,       // Return, Escape, Delete (forward)
        0xFF50: 0x73, 0xFF51: 0x7B, 0xFF52: 0x7E, 0xFF53: 0x7C, 0xFF54: 0x7D,  // Home, arrows
        0xFF55: 0x74, 0xFF56: 0x79, 0xFF57: 0x77,       // Page_Up, Page_Down, End
        0xFF63: 0x72, 0xFF6A: 0x72,                     // Insert, Help -> Help
        0xFF61: 0x69, 0xFF14: 0x6B, 0xFF13: 0x71,       // Print, Scroll_Lock, Pause -> F13, F14, F15
        0xFFBE: 0x7A, 0xFFBF: 0x78, 0xFFC0: 0x63, 0xFFC1: 0x76, 0xFFC2: 0x60, 0xFFC3: 0x61,  // F1-F6
        0xFFC4: 0x62, 0xFFC5: 0x64, 0xFFC6: 0x65, 0xFFC7: 0x6D, 0xFFC8: 0x67, 0xFFC9: 0x6F,  // F7-F12
        0xFFCA: 0x69, 0xFFCB: 0x6B, 0xFFCC: 0x71, 0xFFCD: 0x6A,                              // F13-F16
        0xFFCE: 0x40, 0xFFCF: 0x4F, 0xFFD0: 0x50, 0xFFD1: 0x5A,                              // F17-F20
        // Keypad
        0xFF7F: 0x47,                                   // Num_Lock -> Clear
        0xFF80: 0x31, 0xFF89: 0x30, 0xFF8D: 0x4C,       // KP_Space, KP_Tab, KP_Enter
        0xFF95: 0x73, 0xFF96: 0x7B, 0xFF97: 0x7E, 0xFF98: 0x7C, 0xFF99: 0x7D,  // KP_Home, arrows
        0xFF9A: 0x74, 0xFF9B: 0x79, 0xFF9C: 0x77, 0xFF9D: 0x57,                // KP_Prior, Next, End, Begin(5)
        0xFF9E: 0x72, 0xFF9F: 0x75,                                            // KP_Insert, KP_Delete
        0xFFAA: 0x43, 0xFFAB: 0x45, 0xFFAC: 0x2B, 0xFFAD: 0x4E, 0xFFAE: 0x41, 0xFFAF: 0x4B,  // * + , - . /
        0xFFB0: 0x52, 0xFFB1: 0x53, 0xFFB2: 0x54, 0xFFB3: 0x55, 0xFFB4: 0x56,  // KP_0-4
        0xFFB5: 0x57, 0xFFB6: 0x58, 0xFFB7: 0x59, 0xFFB8: 0x5B, 0xFFB9: 0x5C,  // KP_5-9
        0xFFBD: 0x51,                                                          // KP_Equal
    ]

    /// US (ANSI) key positions, used for shortcuts. Shifted symbols map to their base key.
    static let ansiKeys: [Character: CGKeyCode] = {
        var m: [Character: CGKeyCode] = [
            "a": 0x00, "s": 0x01, "d": 0x02, "f": 0x03, "h": 0x04, "g": 0x05, "z": 0x06, "x": 0x07,
            "c": 0x08, "v": 0x09, "b": 0x0B, "q": 0x0C, "w": 0x0D, "e": 0x0E, "r": 0x0F, "y": 0x10,
            "t": 0x11, "1": 0x12, "2": 0x13, "3": 0x14, "4": 0x15, "6": 0x16, "5": 0x17, "=": 0x18,
            "9": 0x19, "7": 0x1A, "-": 0x1B, "8": 0x1C, "0": 0x1D, "]": 0x1E, "o": 0x1F, "u": 0x20,
            "[": 0x21, "i": 0x22, "p": 0x23, "l": 0x25, "j": 0x26, "'": 0x27, "k": 0x28, ";": 0x29,
            "\\": 0x2A, ",": 0x2B, "/": 0x2C, "n": 0x2D, "m": 0x2E, ".": 0x2F, "`": 0x32, " ": 0x31,
        ]
        let shifted: [Character: Character] = [
            "!": "1", "@": "2", "#": "3", "$": "4", "%": "5", "^": "6", "&": "7", "*": "8", "(": "9", ")": "0",
            "_": "-", "+": "=", "{": "[", "}": "]", "|": "\\", ":": ";", "\"": "'", "<": ",", ">": ".",
            "?": "/", "~": "`",
        ]
        for (s, base) in shifted { m[s] = m[base] }
        return m
    }()

    /// The character an X11 keysym stands for (Latin-1 and Unicode keysyms, plus a few common others).
    static func unicode(for keysym: UInt32) -> Unicode.Scalar? {
        switch keysym {
        case 0x20...0x7E, 0xA0...0xFF: return Unicode.Scalar(keysym)
        case 0x0100_0100...0x0110_FFFF: return Unicode.Scalar(keysym - 0x0100_0000)
        case 0x20AC: return "\u{20AC}"   // EuroSign
        case 0xFF0A: return "\n"          // Linefeed
        default: return nil
        }
    }
}
