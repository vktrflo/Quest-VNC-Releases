// Lets Swift call the system zlib (libz ships with macOS and Linux).
// Built with: swiftc -O *.swift -import-objc-header zlib-bridge.h -lz -o QuestVncServer
// Apple's Compression framework can't do a persistent deflate stream with sync flushes, which
// Tight encoding needs, so we use zlib directly.
#include <zlib.h>
