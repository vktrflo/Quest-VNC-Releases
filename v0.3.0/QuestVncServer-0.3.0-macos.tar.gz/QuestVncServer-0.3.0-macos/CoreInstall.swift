// Install layout, the .app wrapper and the folder swap for in-place updates. Plain Foundation and
// POSIX (the macOS-only pieces, building and signing, are passed in), so test/unit/ checks these
// steps on Linux with temporary folders and fake builders.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

let appBundleIdentifier = "com.questvnc.server"
let appDisplayName = "Quest VNC Server"
let appExecutableName = "QuestVncServer"

/// Where an installed server and its files live, for one user's home folder.
struct InstallLayout {
    let home: String

    init(home: String = NSHomeDirectory()) { self.home = home }

    private func p(_ parts: String...) -> String {
        parts.reduce(home) { ($0 as NSString).appendingPathComponent($1) }
    }

    var appPath: String { p("Applications", "\(appDisplayName).app") }
    var executableInApp: String { (appPath as NSString).appendingPathComponent("Contents/MacOS/\(appExecutableName)") }
    /// Hidden work folder next to the app (same volume, so the swap is a plain rename).
    var stagingDir: String { p("Applications", ".QuestVncServer-update") }
    var newAppPath: String { (stagingDir as NSString).appendingPathComponent("\(appDisplayName).app") }
    var oldAppPath: String { (stagingDir as NSString).appendingPathComponent("\(appDisplayName).old.app") }
    var sourceDir: String { (stagingDir as NSString).appendingPathComponent("src") }
    var newBinary: String { (stagingDir as NSString).appendingPathComponent("\(appExecutableName).new") }
    /// Written by the swap; the new copy sees it on start and logs "Updated to x.y.z".
    var markerPath: String { (stagingDir as NSString).appendingPathComponent("updated-from") }
    var settingsPath: String { p("Library", "Application Support", "QuestVncServer", "server.conf") }
    var logPath: String { p("Library", "Logs", "QuestVncServer.log") }
    var launchAgentPath: String { p("Library", "LaunchAgents", "\(appBundleIdentifier).plist") }

    /// True when `executable` is the binary inside the installed app.
    func isInstalled(executable: String) -> Bool {
        func norm(_ s: String) -> String {
            (URL(fileURLWithPath: s).resolvingSymlinksInPath().path as NSString).standardizingPath
        }
        return norm(executable) == norm(executableInApp)
    }
}

/// Info.plist of the app wrapper. LSUIElement keeps it out of the Dock.
func appInfoPlist(version: String) -> String {
    """
    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
    <plist version="1.0">
    <dict>
    \t<key>CFBundleIdentifier</key>
    \t<string>\(appBundleIdentifier)</string>
    \t<key>CFBundleName</key>
    \t<string>\(appDisplayName)</string>
    \t<key>CFBundleDisplayName</key>
    \t<string>\(appDisplayName)</string>
    \t<key>CFBundleExecutable</key>
    \t<string>\(appExecutableName)</string>
    \t<key>CFBundlePackageType</key>
    \t<string>APPL</string>
    \t<key>CFBundleInfoDictionaryVersion</key>
    \t<string>6.0</string>
    \t<key>CFBundleShortVersionString</key>
    \t<string>\(version)</string>
    \t<key>CFBundleVersion</key>
    \t<string>\(version)</string>
    \t<key>LSMinimumSystemVersion</key>
    \t<string>13.0</string>
    \t<key>LSUIElement</key>
    \t<true/>
    </dict>
    </plist>

    """
}

/// Builds `<app>/Contents/{Info.plist,PkgInfo,MacOS/QuestVncServer}` from an executable (replacing
/// anything at `app`). Signing is separate.
func makeAppBundle(at app: String, executable: String, version: String) throws {
    let fm = FileManager.default
    if fm.fileExists(atPath: app) { try fm.removeItem(atPath: app) }
    let contents = (app as NSString).appendingPathComponent("Contents")
    let macos = (contents as NSString).appendingPathComponent("MacOS")
    try fm.createDirectory(atPath: macos, withIntermediateDirectories: true)
    let exe = (macos as NSString).appendingPathComponent(appExecutableName)
    try fm.copyItem(atPath: executable, toPath: exe)
    try fm.setAttributes([.posixPermissions: 0o755], ofItemAtPath: exe)
    try Data(appInfoPlist(version: version).utf8).write(to: URL(fileURLWithPath: (contents as NSString).appendingPathComponent("Info.plist")))
    try Data("APPL????".utf8).write(to: URL(fileURLWithPath: (contents as NSString).appendingPathComponent("PkgInfo")))
}

/// Runs a program and collects its output (stdout and stderr together).
func runProcess(_ executable: String, _ args: [String], cwd: String? = nil,
                environment: [String: String]? = nil) -> (status: Int32, output: String) {
    let p = Process()
    p.executableURL = URL(fileURLWithPath: executable)
    p.arguments = args
    if let c = cwd { p.currentDirectoryURL = URL(fileURLWithPath: c) }
    if let e = environment { p.environment = e }
    let pipe = Pipe()
    p.standardOutput = pipe
    p.standardError = pipe
    p.standardInput = FileHandle.nullDevice
    do {
        try p.run()
    } catch {
        return (-1, "can't run \(executable): \(error)")
    }
    let data = pipe.fileHandleForReading.readDataToEndOfFile()   // read before waiting, so a full pipe can't block it
    p.waitUntilExit()
    return (p.terminationStatus, String(decoding: data, as: UTF8.self))
}

/// The last `n` non-empty lines of some output, for log messages.
func lastLines(_ s: String, _ n: Int) -> String {
    s.split(whereSeparator: \.isNewline).suffix(n).joined(separator: "\n")
}

/// Finds the source folder inside an extracted payload: the folder itself, or its only subfolder,
/// whichever holds zlib-bridge.h.
func findSourceRoot(_ dir: String) -> String? {
    let fm = FileManager.default
    let marker = "zlib-bridge.h"
    if fm.fileExists(atPath: (dir as NSString).appendingPathComponent(marker)) { return dir }
    let subs = ((try? fm.contentsOfDirectory(atPath: dir)) ?? []).filter { !$0.hasPrefix(".") }
    for s in subs {
        let d = (dir as NSString).appendingPathComponent(s)
        if fm.fileExists(atPath: (d as NSString).appendingPathComponent(marker)) { return d }
    }
    return nil
}

/// Updates an installed .app: extract the source, build it, wrap it as a new signed .app in the
/// staging folder, then swap the two app folders with rename. The platform steps are injected.
final class BundleInstaller: UpdateInstaller {
    let layout: InstallLayout
    let currentVersion: String
    /// Unpacks the payload into a folder (macOS: tar -xzf).
    let extract: (_ payload: String, _ into: String) throws -> Void
    /// Compiles the source folder into one executable (macOS: swiftc, as run.command does).
    let build: (_ sourceDir: String, _ output: String) throws -> Void
    /// Wraps a freshly built executable as a signed app (macOS: `<binary> --make-app <path>`).
    let makeApp: (_ binary: String, _ app: String) throws -> Void

    init(layout: InstallLayout, currentVersion: String,
         extract: @escaping (String, String) throws -> Void,
         build: @escaping (String, String) throws -> Void,
         makeApp: @escaping (String, String) throws -> Void) {
        self.layout = layout
        self.currentVersion = currentVersion
        self.extract = extract
        self.build = build
        self.makeApp = makeApp
    }

    func prepare(payload: String, release: ReleaseInfo) throws {
        cleanUp()
        let fm = FileManager.default
        try fm.createDirectory(atPath: layout.sourceDir, withIntermediateDirectories: true)
        try extract(payload, layout.sourceDir)
        guard let src = findSourceRoot(layout.sourceDir) else {
            throw UpdateError("the update doesn't contain the server's source files")
        }
        try build(src, layout.newBinary)
        guard fm.isExecutableFile(atPath: layout.newBinary) else { throw UpdateError("the build made no program") }
        try makeApp(layout.newBinary, layout.newAppPath)
        let exe = (layout.newAppPath as NSString).appendingPathComponent("Contents/MacOS/\(appExecutableName)")
        guard fm.isExecutableFile(atPath: exe) else { throw UpdateError("the new app is incomplete") }
    }

    func swap(release: ReleaseInfo) throws {
        let fm = FileManager.default
        if fm.fileExists(atPath: layout.oldAppPath) { try fm.removeItem(atPath: layout.oldAppPath) }
        let hadApp = fm.fileExists(atPath: layout.appPath)
        if hadApp {
            guard rename(layout.appPath, layout.oldAppPath) == 0 else {
                throw UpdateError("can't move the old app aside: \(String(cString: strerror(errno)))")
            }
        }
        guard rename(layout.newAppPath, layout.appPath) == 0 else {
            let why = String(cString: strerror(errno))
            if hadApp { _ = rename(layout.oldAppPath, layout.appPath) }   // put the old one back
            throw UpdateError("can't move the new app into place: \(why)")
        }
        try? Data(currentVersion.utf8).write(to: URL(fileURLWithPath: layout.markerPath))
        try? fm.removeItem(atPath: layout.sourceDir)
        try? fm.removeItem(atPath: layout.newBinary)
    }

    func cleanUp() {
        let fm = FileManager.default
        for p in [layout.sourceDir, layout.newBinary, layout.newAppPath] { try? fm.removeItem(atPath: p) }
    }
}

/// Called by an installed server on start. When the previous copy just swapped this version in,
/// logs "Updated to x.y.z" (plus `note`) and removes the old app. Returns the previous version then.
@discardableResult
func finishPreviousUpdate(layout: InstallLayout, currentVersion: String, note: String = "",
                          say: (String) -> Void = { log($0) }) -> String? {
    let fm = FileManager.default
    defer {
        // Leftovers of an interrupted update are never needed.
        for p in [layout.oldAppPath, layout.sourceDir, layout.newBinary, layout.newAppPath] { try? fm.removeItem(atPath: p) }
    }
    guard let data = fm.contents(atPath: layout.markerPath) else { return nil }
    try? fm.removeItem(atPath: layout.markerPath)
    let from = String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
    say("Updated to \(currentVersion)" + (from.isEmpty ? "" : " (from \(from))") + (note.isEmpty ? "" : ". " + note))
    return from
}

/// Empties a log file that has grown past `limit` bytes (fd 1 when launchd writes stdout to a file).
/// Returns true when it truncated.
@discardableResult
func truncateLogIfLarge(fd: Int32, limit: Int) -> Bool {
    var st = stat()
    guard fstat(fd, &st) == 0, (st.st_mode & S_IFMT) == S_IFREG, Int(st.st_size) > limit else { return false }
    guard ftruncate(fd, 0) == 0 else { return false }
    _ = lseek(fd, 0, SEEK_SET)
    return true
}
