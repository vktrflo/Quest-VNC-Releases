// macOS side of install and self-update: building a downloaded source payload, wrapping a binary
// as the signed "Quest VNC Server.app", and starting the update checks. The steps themselves live
// in CoreUpdate.swift / CoreInstall.swift.

import Foundation

enum MacUpdate {
    /// Said by the installer, the "Installing" line and the "Updated to" line.
    static let permissionNote = """
        macOS will ask again for Screen Recording and Accessibility for Quest VNC Server, because every \
        build has a new signature (until the app is signed with a Developer ID); turn both on again in \
        System Settings > Privacy & Security
        """

    #if arch(arm64)
    static let arch = "arm64"
    #else
    static let arch = "x86_64"
    #endif

    /// launchd starts agents with a minimal environment; make sure the developer tools find a home
    /// folder and the usual system paths.
    static func toolEnvironment() -> [String: String] {
        var env = ProcessInfo.processInfo.environment
        if env["HOME"] == nil { env["HOME"] = NSHomeDirectory() }
        env["PATH"] = "/usr/bin:/bin:/usr/sbin:/sbin" + (env["PATH"].map { ":" + $0 } ?? "")
        return env
    }

    /// Path of this running program.
    static func selfExecutable() -> String {
        if let p = Bundle.main.executablePath { return p }
        let a0 = CommandLine.arguments[0]
        if a0.hasPrefix("/") { return a0 }
        return (FileManager.default.currentDirectoryPath as NSString).appendingPathComponent(a0)
    }

    static func extract(payload: String, into dir: String) throws {
        let r = runProcess("/usr/bin/tar", ["-xzf", payload, "-C", dir])
        guard r.status == 0 else { throw UpdateError("couldn't unpack it:\n" + lastLines(r.output, 10)) }
    }

    /// Same compiler command as run.command.
    static func build(sourceDir: String, output: String) throws {
        let files = ((try? FileManager.default.contentsOfDirectory(atPath: sourceDir)) ?? [])
            .filter { $0.hasSuffix(".swift") }.sorted()
        guard !files.isEmpty else { throw UpdateError("the update has no Swift files") }
        let args = ["swiftc", "-O", "-target", "\(arch)-apple-macos13.0"] + files +
            ["-import-objc-header", "zlib-bridge.h", "-lz", "-o", output]
        let r = runProcess("/usr/bin/xcrun", args, cwd: sourceDir, environment: toolEnvironment())
        guard r.status == 0 else {
            throw UpdateError("the build failed (are the Xcode Command Line Tools still installed?). Compiler output:\n"
                              + lastLines(r.output, 15))
        }
    }

    /// Has the newly built program wrap and sign itself, so the app carries the new version's Info.plist.
    static func makeApp(binary: String, app: String) throws {
        let r = runProcess(binary, ["--make-app", app], environment: toolEnvironment())
        guard r.status == 0 else { throw UpdateError("couldn't make the app:\n" + lastLines(r.output, 10)) }
    }

    /// `--make-app PATH`: wraps this program as an app at PATH and signs it ad hoc. Exit status.
    static func makeAppHere(_ dest: String) -> Int32 {
        do {
            try makeAppBundle(at: dest, executable: selfExecutable(), version: questVncVersion)
        } catch {
            log("Couldn't make \(dest): \(error)")
            return 1
        }
        let r = runProcess("/usr/bin/codesign", ["--force", "--sign", "-", dest], environment: toolEnvironment())
        guard r.status == 0 else {
            log("Couldn't sign \(dest):\n" + r.output)
            return 1
        }
        return 0
    }

    /// Clears this app's Screen Recording and Accessibility entries (best effort). The old entries
    /// belong to the previous signature and would show as "on" without working; cleared, macOS asks again.
    static func resetPermissions() {
        for service in ["ScreenCapture", "Accessibility"] {
            _ = runProcess("/usr/bin/tccutil", ["reset", service, appBundleIdentifier])
        }
    }

    static func installer(layout: InstallLayout) -> BundleInstaller {
        BundleInstaller(layout: layout, currentVersion: questVncVersion,
                        extract: { try extract(payload: $0, into: $1) },
                        build: { try build(sourceDir: $0, output: $1) },
                        makeApp: { try makeApp(binary: $0, app: $1) })
    }

    /// Starts the update checks (60 s after start, then every 12 hours). An installed copy installs
    /// updates and exits with status 0 so launchd starts the new one; a portable copy only says so.
    static func startUpdater(options: Options, installed: Bool, viewerCount: @escaping () -> Int) {
        if options.noUpdate {
            log("Updates: off (--no-update)")
            return
        }
        let layout = InstallLayout()
        let u = Updater(currentVersion: questVncVersion, feedURL: options.updateURL ?? defaultUpdateURL,
                        installed: installed, workDir: layout.stagingDir, transport: URLSessionTransport(),
                        installer: installed ? installer(layout: layout) : nil, viewerCount: viewerCount)
        u.installNote = permissionNote
        u.start {
            resetPermissions()
            DispatchQueue.main.async { exit(0) }   // exit() restores the display mode via atexit
        }
        log(installed ? "Updates: automatic (installed when no viewer is connected)"
                      : "Updates: only reported (this copy isn't installed; install.command installs it)")
    }
}
