// The VNC server: accepts viewers, owns the shared pieces (frames, sound, input, clipboard).

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// Injects viewer input into the computer. x/y are framebuffer pixels (top-left of the captured
/// image is 0,0). `buttons`: bit0 left, bit1 middle, bit2 right. Wheel values are notches
/// (positive = up / left).
protocol InputSink: AnyObject {
    func pointer(x: Int, y: Int, buttons: UInt8, wheelUp: Int, wheelLeft: Int)
    func key(keysym: UInt32, down: Bool)
}

/// Sets the computer's clipboard.
protocol ClipboardSink: AnyObject {
    func setText(_ text: String)
}

final class VncServer {
    let options: Options
    let frames: FrameStore
    let audio: AudioHub
    let input: InputSink?
    let clipboard: ClipboardSink?
    let jpeg: JpegEncoder?
    let desktopName: String
    let resize: ResizeCoordinator

    private let lock = NSLock()
    private var sessions: [Int: Session] = [:]
    private var nextId = 0
    private var lastTextFromViewer: String? = nil
    private var listener: Listener?

    init(options: Options, frames: FrameStore, audio: AudioHub, input: InputSink?, clipboard: ClipboardSink?,
         jpeg: JpegEncoder?, desktopName: String, resolution: ResolutionControl? = nil) {
        self.options = options
        self.frames = frames
        self.audio = audio
        self.input = input
        self.clipboard = clipboard
        self.jpeg = jpeg
        self.desktopName = desktopName
        self.resize = ResizeCoordinator(control: resolution, allowed: !options.viewOnly && !options.noResize)
    }

    /// Binds the port and starts accepting viewers on a background thread.
    func start() throws {
        let l = try Listener(port: options.port)
        listener = l
        let t = Thread { [weak self] in
            while true {
                guard let (fd, peer) = l.accept() else {
                    // Transient (EINTR, ECONNABORTED, out of descriptors): keep serving.
                    usleep(100_000)
                    continue
                }
                guard let self = self else { Glue.close(fd); return }
                self.lock.lock()
                self.nextId += 1
                let s = Session(server: self, conn: Connection(fd: fd), peer: peer, id: self.nextId)
                self.lock.unlock()
                s.start()
            }
        }
        t.name = "accept"
        t.start()
    }

    func register(_ s: Session) {
        lock.lock(); defer { lock.unlock() }
        sessions[s.id] = s
    }

    func unregister(_ s: Session) {
        lock.lock(); defer { lock.unlock() }
        sessions[s.id] = nil
    }

    var viewerCount: Int {
        lock.lock(); defer { lock.unlock() }
        return sessions.count
    }

    /// A viewer sent its clipboard.
    func viewerCutText(_ text: String) {
        lock.lock()
        lastTextFromViewer = text
        lock.unlock()
        clipboard?.setText(text)
    }

    /// The computer's clipboard changed: send it to every viewer (unless it's the echo of a viewer's text).
    func hostClipboardChanged(_ text: String) {
        lock.lock()
        let echo = text == lastTextFromViewer
        lastTextFromViewer = nil
        let all = Array(sessions.values)
        lock.unlock()
        if echo { return }
        var w = ByteWriter()
        let bytes = latin1Bytes(text)
        w.u8(3); w.pad(3); w.u32(bytes.count); w.append(bytes)
        for s in all { s.sendControl(w.bytes) }
    }
}
