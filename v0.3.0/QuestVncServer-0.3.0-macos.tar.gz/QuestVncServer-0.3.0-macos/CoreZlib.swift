// One persistent deflate stream (Tight zlib stream 0), sync-flushed after each rectangle.
// zlib comes in through zlib-bridge.h (-import-objc-header) and -lz.

final class DeflateStream {
    // zlib keeps a pointer back to the z_stream and checks it, so it must live at a fixed address.
    private let strm: UnsafeMutablePointer<z_stream>
    private var level: Int32
    private var ok = false
    /// Bytes zlib produced while changing the level; they belong at the front of the next output.
    private var carry: [UInt8] = []

    init(level: Int) {
        self.level = Int32(max(0, min(9, level)))
        strm = UnsafeMutablePointer<z_stream>.allocate(capacity: 1)
        strm.initialize(to: z_stream())
        ok = deflateInit2_(strm, self.level, Z_DEFLATED, MAX_WBITS, 8, Z_DEFAULT_STRATEGY,
                           zlibVersion(), Int32(MemoryLayout<z_stream>.size)) == Z_OK
    }

    deinit {
        if ok { deflateEnd(strm) }
        strm.deinitialize(count: 1)
        strm.deallocate()
    }

    func setLevel(_ newLevel: Int) {
        let l = Int32(max(0, min(9, newLevel)))
        guard ok, l != level else { return }
        level = l
        // Everything fed so far was sync-flushed, but zlib may still emit a few bytes here.
        var out = [UInt8](repeating: 0, count: 256)
        out.withUnsafeMutableBufferPointer { buf in
            strm.pointee.next_in = nil
            strm.pointee.avail_in = 0
            strm.pointee.next_out = buf.baseAddress
            strm.pointee.avail_out = UInt32(buf.count)
            _ = deflateParams(strm, l, Z_DEFAULT_STRATEGY)
            let produced = buf.count - Int(strm.pointee.avail_out)
            carry.append(contentsOf: buf[0..<produced])
        }
    }

    /// Compresses `input` and sync-flushes; the result is what the viewer must inflate.
    func compress(_ input: [UInt8]) -> [UInt8]? {
        guard ok else { return nil }
        var out = carry
        carry = []
        var chunk = [UInt8](repeating: 0, count: max(4096, input.count / 2 + 1024))
        var input = input
        let rc: Bool = input.withUnsafeMutableBufferPointer { inBuf -> Bool in
            strm.pointee.next_in = inBuf.baseAddress
            strm.pointee.avail_in = UInt32(inBuf.count)
            while true {
                let r: Int32 = chunk.withUnsafeMutableBufferPointer { outBuf -> Int32 in
                    strm.pointee.next_out = outBuf.baseAddress
                    strm.pointee.avail_out = UInt32(outBuf.count)
                    let r = deflate(strm, Z_SYNC_FLUSH)
                    let produced = outBuf.count - Int(strm.pointee.avail_out)
                    out.append(contentsOf: outBuf[0..<produced])
                    return r
                }
                if r != Z_OK && r != Z_BUF_ERROR { return false }
                // Done once deflate left output space unused (everything flushed).
                if strm.pointee.avail_out != 0 && strm.pointee.avail_in == 0 { return true }
            }
        }
        strm.pointee.next_in = nil
        strm.pointee.next_out = nil
        return rc ? out : nil
    }
}
