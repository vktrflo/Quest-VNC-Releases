// One connected viewer: RFB handshake, client messages, framebuffer updates and sound.
//
// Threads: a reader thread (handshake, then client messages) and a sender thread that is the only
// writer after the handshake. Everything the sender sends goes out as whole RFB messages, so frame
// updates, sound and clipboard never interleave mid-message. A frame is sent as one or more
// FramebufferUpdate messages, and queued sound goes out between them, so sound never waits behind
// a whole large frame.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

final class Session {
    let id: Int
    let peer: String
    private let server: VncServer
    private let conn: Connection
    private let encoder: RectEncoder

    // Shared between threads, guarded by `cond`.
    private let cond = NSCondition()
    private var closed = false
    private var control: [[UInt8]] = []        // complete messages (acks, sound begin/end, clipboard)
    private var audioChunks: [[UInt8]] = []    // complete sound data messages
    private var audioQueuedFrames = 0
    private var updateRequested = false
    private var region = FbRect(x: 0, y: 0, w: 0, h: 0)
    private var fbW = 0, fbH = 0
    private var tilesX = 0, tilesY = 0
    private var dirty: [Bool] = []
    private var pendingResize: (w: Int, h: Int, reason: Int)? = nil
    private var extendedOK = false            // viewer listed ExtendedDesktopSize (-308)
    private var settings = EncodeSettings()
    private var desktopSizeOK = false
    private var audioEnabled = false
    private var audioFormat = AudioFormat()
    private var converter: PcmConverter? = nil
    private var audioAccum: [UInt8] = []

    // Reader thread only.
    private var buttons: UInt8 = 0
    private var lastX = 0, lastY = 0
    private var heldKeys = Set<UInt32>()
    private var protocolMinor = 8

    private var frameListener: Int? = nil
    private var audioSink: Int? = nil
    private let senderDone = DispatchSemaphore(value: 0)

    init(server: VncServer, conn: Connection, peer: String, id: Int) {
        self.server = server
        self.conn = conn
        self.peer = peer
        self.id = id
        self.encoder = RectEncoder(jpeg: server.jpeg)
    }

    func start() {
        let t = Thread { [self] in run() }
        t.name = "viewer-\(id)"
        t.start()
    }

    // MARK: - Lifecycle

    private func run() {
        setReadTimeout(seconds: 30)   // a silent half-open connection must not hang around
        guard handshake() else {
            conn.close()
            return
        }
        setReadTimeout(seconds: 0)

        frameListener = server.frames.addListener { [weak self] in self?.frameChanged($0) }
        let frame = server.frames.current
        cond.lock()
        fbW = frame.width
        fbH = frame.height
        resetTiles()
        cond.unlock()

        var w = ByteWriter()
        let name = Array(server.desktopName.utf8)
        w.u16(fbW); w.u16(fbH); w.append(PixelFormat().bytes); w.u32(name.count); w.append(name)
        guard conn.write(w.bytes) else {
            server.frames.removeListener(frameListener!)
            conn.close()
            return
        }

        server.register(self)
        audioSink = server.audio.addSink { [weak self] p, c, r in self?.audioIn(p, c, r) }
        log("Viewer connected: \(peer) (\(server.viewerCount) connected)")

        let sender = Thread { [self] in senderLoop() }
        sender.name = "viewer-\(id)-send"
        sender.start()

        messageLoop()

        terminate()
        if let f = frameListener { server.frames.removeListener(f) }
        if let a = audioSink { server.audio.removeSink(a) }
        server.unregister(self)
        releaseInput()
        server.resize.sessionEnded(id)
        senderDone.wait()
        conn.close()
        log("Viewer disconnected: \(peer) (\(server.viewerCount) connected)")
    }

    private func terminate() {
        cond.lock()
        closed = true
        cond.broadcast()
        cond.unlock()
        conn.shutdownBoth()
    }

    private func setReadTimeout(seconds: Int) {
        var tv = timeval()
        tv.tv_sec = seconds
        _ = setsockopt(conn.fd, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
    }

    // MARK: - Handshake

    private func handshake() -> Bool {
        guard conn.write(Array("RFB 003.008\n".utf8)), let v = conn.readBytes(12) else { return false }
        guard v[0] == UInt8(ascii: "R"), v[1] == UInt8(ascii: "F"), v[2] == UInt8(ascii: "B"),
              let major = Int(String(decoding: v[4..<7], as: UTF8.self)),
              let minor = Int(String(decoding: v[8..<11], as: UTF8.self)), major >= 3 else {
            log("Not a VNC viewer: \(peer)")
            return false
        }
        // 3.3 (and 3.4-3.6) behave as 3.3; 3.7; anything from 3.8 up (3.889 from Apple too) as 3.8.
        protocolMinor = major > 3 || minor >= 8 ? 8 : (minor == 7 ? 7 : 3)

        let secType: UInt8 = server.options.password != nil ? 2 : 1
        if protocolMinor >= 7 {
            guard conn.write([1, secType]), let chosen = conn.u8() else { return false }
            if chosen != secType {
                if protocolMinor == 8 { _ = conn.write(failure("Security type not offered")) }
                return false
            }
        } else {
            var w = ByteWriter()
            w.u32(Int(secType))
            guard conn.write(w.bytes) else { return false }
        }

        if secType == 2 {
            var challenge = [UInt8](repeating: 0, count: 16)
            var rng = SystemRandomNumberGenerator()
            for i in 0..<16 { challenge[i] = UInt8.random(in: 0...255, using: &rng) }
            guard conn.write(challenge), let response = conn.readBytes(16) else { return false }
            let expected = DES.vncResponse(password: server.options.password ?? "", challenge: challenge)
            if response != expected {
                log("Wrong password from \(peer)")
                var w = ByteWriter()
                if protocolMinor == 8 { w.append(failure("Authentication failed")) } else { w.u32(1) }
                _ = conn.write(w.bytes)
                // Slow down guessing, but never lock anyone out.
                sleep(1)
                return false
            }
            guard conn.write([0, 0, 0, 0]) else { return false }
        } else if protocolMinor == 8 {
            guard conn.write([0, 0, 0, 0]) else { return false }
        }

        // ClientInit: the shared flag is ignored, several viewers are always allowed.
        return conn.u8() != nil
    }

    private func failure(_ reason: String) -> [UInt8] {
        var w = ByteWriter()
        let r = Array(reason.utf8)
        w.u32(1); w.u32(r.count); w.append(r)
        return w.bytes
    }

    // MARK: - Client messages

    private func messageLoop() {
        while let type = conn.u8() {
            switch type {
            case 0: // SetPixelFormat
                guard let b = conn.readBytes(19) else { return }
                let fmt = PixelFormat(Array(b[3..<19]))
                guard fmt.isSupported else {
                    log("Viewer \(peer) asked for an unsupported pixel format (\(fmt.bpp) bpp, true colour \(fmt.trueColour)); closing")
                    return
                }
                cond.lock()
                settings.format = fmt
                cond.unlock()

            case 2: // SetEncodings
                guard conn.skip(1), let n = conn.u16(), let b = conn.readBytes(n * 4) else { return }
                var list: [Int32] = []
                for i in 0..<n {
                    list.append(Int32(bitPattern: UInt32(b[i * 4]) << 24 | UInt32(b[i * 4 + 1]) << 16
                                      | UInt32(b[i * 4 + 2]) << 8 | UInt32(b[i * 4 + 3])))
                }
                setEncodings(list)

            case 3: // FramebufferUpdateRequest
                guard let inc = conn.u8(), let x = conn.u16(), let y = conn.u16(), let w = conn.u16(), let h = conn.u16()
                else { return }
                updateRequest(incremental: inc != 0, FbRect(x: x, y: y, w: w, h: h))

            case 4: // KeyEvent
                guard let down = conn.u8(), conn.skip(2), let keysym = conn.u32() else { return }
                keyEvent(keysym, down: down != 0)

            case 5: // PointerEvent
                guard let mask = conn.u8(), let x = conn.u16(), let y = conn.u16() else { return }
                pointerEvent(mask, x, y)

            case 6: // ClientCutText
                guard conn.skip(3), let len32 = conn.u32() else { return }
                let len = Int(Int32(bitPattern: len32))
                if len < 0 {
                    // Extended clipboard (never offered): skip it.
                    guard len > -(16 << 20), conn.skip(-len) else { return }
                    continue
                }
                guard len <= 16 << 20, let text = conn.readBytes(len) else { return }
                if !server.options.viewOnly { server.viewerCutText(latin1String(text)) }

            case 251: // SetDesktopSize
                guard conn.skip(1), let w = conn.u16(), let h = conn.u16(), let screens = conn.u8(), conn.skip(1),
                      conn.skip(Int(screens) * 16) else { return }
                setDesktopSize(w, h)

            case 255: // QEMU client message
                guard let sub = conn.u8() else { return }
                if sub == 1 {
                    guard let op = conn.u16() else { return }
                    switch op {
                    case 0: audioEnable(true)
                    case 1: audioEnable(false)
                    case 2:
                        guard let f = conn.u8(), let ch = conn.u8(), let rate = conn.u32() else { return }
                        audioSetFormat(f, Int(ch), Int(rate))
                    default:
                        log("Viewer \(peer) sent an unknown audio operation \(op); closing")
                        return
                    }
                } else if sub == 0 {
                    // QEMU extended key event: down u16, keysym u32, keycode u32. Use the keysym.
                    guard let down = conn.u16(), let keysym = conn.u32(), conn.skip(4) else { return }
                    keyEvent(keysym, down: down != 0)
                } else {
                    log("Viewer \(peer) sent an unknown QEMU message \(sub); closing")
                    return
                }

            default:
                log("Viewer \(peer) sent an unknown message type \(type); closing")
                return
            }
        }
    }

    private func setEncodings(_ list: [Int32]) {
        var chosen: Int32? = nil
        var quality: Int? = nil
        var compress: Int? = nil
        var ds = false, wantsAudio = false, ext = false
        for e in list {
            if chosen == nil && (e == encTight || e == encRaw) { chosen = e }
            if quality == nil && (-32 ... -23).contains(e) { quality = Int(e + 32) }
            if compress == nil && (-256 ... -247).contains(e) { compress = Int(e + 256) }
            if e == encDesktopSize { ds = true }
            if e == encQemuAudio { wantsAudio = true }
            if e == encExtendedDesktopSize { ext = true }
        }
        let current = server.frames.current
        cond.lock()
        settings.tight = chosen == encTight
        settings.qualityLevel = quality
        settings.compressLevel = compress ?? 6
        desktopSizeOK = ds || ext
        extendedOK = ext
        if desktopSizeOK && (current.width != fbW || current.height != fbH) {
            pendingResize = (current.width, current.height, 0)
        }
        if ext {
            // Tells the viewer that it may ask for another resolution.
            var w = ByteWriter()
            w.u8(0); w.u8(0); w.u16(1)
            w.append(extendedDesktopSizeRect(reason: 0, status: 0, w: fbW, h: fbH))
            control.append(w.bytes)
        }
        if wantsAudio && server.audio.available {
            // Our acknowledgement: an update with one empty -259 rectangle, sent right away.
            var w = ByteWriter()
            w.u8(0); w.u8(0); w.u16(1)
            w.rectHeader(x: 0, y: 0, w: 0, h: 0, encoding: encQemuAudio)
            control.append(w.bytes)
        }
        cond.signal()
        cond.unlock()
    }

    /// SetDesktopSize: change the display mode, or tell the viewer why not.
    private func setDesktopSize(_ w: Int, _ h: Int) {
        let before = server.frames.current
        let (status, mode) = server.resize.request(from: id, peer: peer, w: w, h: h,
                                                   currentW: before.width, currentH: before.height)
        var replyStatus = status
        if status == .ok, let m = mode, m.w != before.width || m.h != before.height {
            // Wait for the capture to deliver the new size; the size change then reaches every
            // viewer (reason 1 for us, 2 for the others) through frameChanged.
            let deadline = monotonicSeconds() + 4
            while monotonicSeconds() < deadline {
                let f = server.frames.current
                if f.width != before.width || f.height != before.height { return }
                usleep(50_000)
            }
            server.resize.clearCause()
            log("The screen didn't change size after switching mode")
            replyStatus = .failed
        }
        cond.lock()
        // If the size was already what was asked for, or the request failed: answer right away.
        var msg = ByteWriter()
        msg.u8(0); msg.u8(0); msg.u16(1)
        msg.append(extendedDesktopSizeRect(reason: 1, status: replyStatus.rawValue, w: fbW, h: fbH))
        control.append(msg.bytes)
        cond.signal()
        cond.unlock()
    }

    private func updateRequest(incremental: Bool, _ r: FbRect) {
        cond.lock()
        let clipped = r.intersection(FbRect(x: 0, y: 0, w: fbW, h: fbH))
        if !incremental { markDirty(clipped) }
        region = region.union(clipped)
        updateRequested = true
        cond.signal()
        cond.unlock()
    }

    // MARK: - Input

    private func keyEvent(_ keysym: UInt32, down: Bool) {
        guard !server.options.viewOnly, let input = server.input else { return }
        if down { heldKeys.insert(keysym) } else { heldKeys.remove(keysym) }
        input.key(keysym: keysym, down: down)
    }

    private func pointerEvent(_ mask: UInt8, _ x: Int, _ y: Int) {
        guard !server.options.viewOnly, let input = server.input else { return }
        let pressed = mask & ~buttons
        var up = 0, left = 0
        if pressed & 0x08 != 0 { up += 1 }
        if pressed & 0x10 != 0 { up -= 1 }
        if pressed & 0x20 != 0 { left += 1 }
        if pressed & 0x40 != 0 { left -= 1 }
        buttons = mask
        lastX = x
        lastY = y
        input.pointer(x: x, y: y, buttons: mask & 0x07, wheelUp: up, wheelLeft: left)
    }

    private func releaseInput() {
        guard let input = server.input, !server.options.viewOnly else { return }
        for k in heldKeys { input.key(keysym: k, down: false) }
        heldKeys.removeAll()
        if buttons & 0x07 != 0 { input.pointer(x: lastX, y: lastY, buttons: 0, wheelUp: 0, wheelLeft: 0) }
        buttons = 0
    }

    // MARK: - Sound

    private func audioEnable(_ on: Bool) {
        cond.lock()
        if on && !audioEnabled && server.audio.available {
            audioEnabled = true
            converter = nil
            audioAccum = []
            control.append([255, 1, 0, 1])   // stream begins
            cond.signal()
        } else if !on && audioEnabled {
            audioEnabled = false
            audioChunks.removeAll()
            audioQueuedFrames = 0
            audioAccum = []
            control.append([255, 1, 0, 0])   // stream ends
            cond.signal()
        }
        cond.unlock()
    }

    private func audioSetFormat(_ f: UInt8, _ channels: Int, _ rate: Int) {
        guard let sf = SampleFormat(rawValue: f), (1...8).contains(channels), (4000...192000).contains(rate) else {
            log("Viewer \(peer) asked for an unsupported sound format (\(f), \(channels) ch, \(rate) Hz); ignored")
            return
        }
        cond.lock()
        audioFormat = AudioFormat(sample: sf, channels: channels, rate: rate)
        converter = nil
        audioAccum = []
        audioChunks.removeAll()
        audioQueuedFrames = 0
        cond.unlock()
    }

    /// Captured sound (interleaved float) from the capture thread.
    private func audioIn(_ p: UnsafeBufferPointer<Float>, _ channels: Int, _ rate: Int) {
        cond.lock()
        defer { cond.unlock() }
        guard audioEnabled, !closed else { return }
        let fmt = audioFormat
        if converter == nil { converter = PcmConverter(fmt) }
        audioAccum.append(contentsOf: converter!.convert(p, channels: channels, rate: rate))
        // 10 ms chunks.
        let chunkFrames = max(1, fmt.rate / 100)
        let chunkBytes = chunkFrames * fmt.bytesPerFrame
        var off = 0
        while audioAccum.count - off >= chunkBytes {
            var w = ByteWriter(capacity: 8 + chunkBytes)
            w.u8(255); w.u8(1); w.u16(2); w.u32(chunkBytes)
            w.bytes.append(contentsOf: audioAccum[off..<(off + chunkBytes)])
            audioChunks.append(w.bytes)
            audioQueuedFrames += chunkFrames
            off += chunkBytes
        }
        if off > 0 {
            audioAccum.removeFirst(off)
            // Falling behind: drop the oldest sound beyond ~250 ms instead of delaying everything.
            while audioQueuedFrames > fmt.rate / 4 && !audioChunks.isEmpty {
                audioChunks.removeFirst()
                audioQueuedFrames -= chunkFrames
            }
            cond.signal()
        }
    }

    // MARK: - Frames

    private func resetTiles() {
        tilesX = (fbW + tileSize - 1) / tileSize
        tilesY = (fbH + tileSize - 1) / tileSize
        dirty = [Bool](repeating: true, count: tilesX * tilesY)
    }

    /// Marks the tiles touching `r` (framebuffer pixels) as changed. Caller holds `cond`.
    private func markDirty(_ r: FbRect) {
        guard !r.isEmpty else { return }
        for ty in (r.y / tileSize)...((r.maxY - 1) / tileSize) where ty < tilesY {
            for tx in (r.x / tileSize)...((r.maxX - 1) / tileSize) where tx < tilesX {
                dirty[ty * tilesX + tx] = true
            }
        }
    }

    private func frameChanged(_ c: FrameChange) {
        cond.lock()
        let differs = c.frame.width != fbW || c.frame.height != fbH
        // New screen size: resize viewers that can; others keep their size and see it cropped top-left.
        if differs && desktopSizeOK {
            // Reason: 1 = this viewer asked for it, 2 = another viewer did, 0 = the server/PC.
            let cause = server.resize.currentCause()
            pendingResize = (c.frame.width, c.frame.height, cause == nil ? 0 : (cause == id ? 1 : 2))
        } else if !differs {
            pendingResize = nil
        }
        if c.sizeChanged {
            for i in 0..<dirty.count { dirty[i] = true }
        } else {
            for ty in 0..<min(tilesY, c.tilesY) {
                for tx in 0..<min(tilesX, c.tilesX) where c.dirty[ty * c.tilesX + tx] {
                    dirty[ty * tilesX + tx] = true
                }
            }
        }
        cond.signal()
        cond.unlock()
    }

    /// Caller holds `cond`.
    private func updateReady() -> Bool {
        guard updateRequested else { return false }
        if pendingResize != nil { return true }
        guard !region.isEmpty else { return false }
        for ty in (region.y / tileSize)...((region.maxY - 1) / tileSize) where ty < tilesY {
            for tx in (region.x / tileSize)...((region.maxX - 1) / tileSize) where tx < tilesX {
                if dirty[ty * tilesX + tx] { return true }
            }
        }
        return false
    }

    private enum Job {
        case resize(Int, Int, Int, Bool)   // w, h, reason, extended
        case rects(Frame, [FbRect], EncodeSettings)
    }

    /// Takes the pending request and the changed tiles inside it. Caller holds `cond`.
    private func takeUpdate() -> Job {
        if let (w, h, reason) = pendingResize {
            pendingResize = nil
            fbW = w
            fbH = h
            resetTiles()
            // Keep the request open so the whole new screen follows right after.
            region = FbRect(x: 0, y: 0, w: w, h: h)
            return .resize(w, h, reason, extendedOK)
        }
        let frame = server.frames.current
        var mask = [Bool](repeating: false, count: tilesX * tilesY)
        for ty in (region.y / tileSize)...((region.maxY - 1) / tileSize) where ty < tilesY {
            for tx in (region.x / tileSize)...((region.maxX - 1) / tileSize) where tx < tilesX {
                let i = ty * tilesX + tx
                if dirty[i] { mask[i] = true; dirty[i] = false }
            }
        }
        let fb = FbRect(x: 0, y: 0, w: fbW, h: fbH)
        let rects = mergeTiles(mask, tilesX: tilesX, tilesY: tilesY).map {
            FbRect(x: $0.x * tileSize, y: $0.y * tileSize, w: $0.w * tileSize, h: $0.h * tileSize)
                .intersection(region).intersection(fb)
        }.filter { !$0.isEmpty }
        updateRequested = false
        region = FbRect(x: 0, y: 0, w: 0, h: 0)
        return .rects(frame, rects, settings)
    }

    /// Queues a complete message (e.g. ServerCutText) for this viewer.
    func sendControl(_ msg: [UInt8]) {
        cond.lock()
        control.append(msg)
        cond.signal()
        cond.unlock()
    }

    private func takeQueued() -> [[UInt8]] {
        cond.lock()
        defer { cond.unlock() }
        let out = control + audioChunks
        control.removeAll()
        audioChunks.removeAll()
        audioQueuedFrames = 0
        return out
    }

    private func hasQueued() -> Bool {
        cond.lock()
        defer { cond.unlock() }
        return !control.isEmpty || !audioChunks.isEmpty
    }

    private func sendAll(_ msgs: [[UInt8]]) -> Bool {
        for m in msgs where !conn.write(m) { return false }
        return true
    }

    private func senderLoop() {
        defer { senderDone.signal() }
        while true {
            cond.lock()
            while !closed && control.isEmpty && audioChunks.isEmpty && !updateReady() { cond.wait() }
            if closed {
                cond.unlock()
                return
            }
            let job: Job? = updateReady() ? takeUpdate() : nil
            cond.unlock()

            guard sendAll(takeQueued()) else { break }
            if let job = job, !send(job) { break }
        }
        terminate()
    }

    private func send(_ job: Job) -> Bool {
        switch job {
        case let .resize(w, h, reason, extended):
            var m = ByteWriter()
            m.u8(0); m.u8(0); m.u16(1)
            if extended {
                m.append(extendedDesktopSizeRect(reason: reason, status: 0, w: w, h: h))
            } else {
                m.rectHeader(x: 0, y: 0, w: w, h: h, encoding: encDesktopSize)
            }
            return conn.write(m.bytes)

        case let .rects(frame, rects, settings):
            var batch: [UInt8] = []
            var count = 0
            func flush() -> Bool {
                guard count > 0 else { return true }
                var m = ByteWriter(capacity: 4 + batch.count)
                m.u8(0); m.u8(0); m.u16(count)
                m.bytes.append(contentsOf: batch)
                batch.removeAll(keepingCapacity: true)
                count = 0
                return conn.write(m.bytes)
            }
            for r in rects {
                for piece in encoder.encode(frame, r, settings) {
                    batch.append(contentsOf: piece)
                    count += 1
                    if count == 65535 || batch.count >= 1 << 20 || hasQueued() {
                        guard flush(), sendAll(takeQueued()) else { return false }
                    }
                }
            }
            return flush()
        }
    }
}
