// Command line options (same on Windows, Linux and macOS, plus --full-res and --no-resize on macOS),
// and the settings file that an installed server reads them from.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

/// A bad option, in words for the user.
struct OptionError: Error, CustomStringConvertible {
    let description: String
}

struct Options {
    var port = 5900
    var password: String? = nil
    var fps = 30
    var monitor = 0
    var viewOnly = false
    var noAudio = false
    var testTone = false
    var fullRes = false
    var noResize = false
    var config: String? = nil
    var noUpdate = false
    var updateURL: String? = nil
    var checkUpdate = false
    var showVersion = false
    var showHelp = false
    /// Internal (used by install.command and the updater): wrap this program as a signed .app at this path.
    var makeApp: String? = nil
    /// The settings file that was read, if any.
    var settingsFileUsed: String? = nil

    static let usage = """
    Usage: QuestVncServer [options]
      --port 5900            listen port (TCP, all interfaces)
      --password SECRET      VNC password (only the first 8 characters count)
      --fps 30               capture rate cap (1-60)
      --monitor N            which display to share, 0 = main display (default)
      --view-only            ignore keyboard and mouse from viewers
      --no-audio             don't capture or offer sound
      --test-tone            send a 440 Hz beep every second instead of the Mac's sound
      --full-res             capture at full pixel resolution (Retina) instead of points
      --no-resize            don't let viewers change the screen resolution
      --config FILE          read options from FILE instead of the default settings file
      --no-update            never check for or install updates
      --update-url URL       release feed (also QUESTVNC_UPDATE_URL)
      --check-update         check once, print the result, exit (0 = up to date, 10 = update available)
      --version              print the version and exit
    """

    /// Parses arguments without side effects (no exit, no printing).
    static func parseArgs(_ args: [String]) throws -> Options {
        var o = Options()
        var it = args.makeIterator()
        func value(_ name: String) throws -> String {
            guard let v = it.next(), !v.isEmpty else { throw OptionError(description: "\(name) needs a value.") }
            return v
        }
        func intArg(_ name: String, _ range: ClosedRange<Int>) throws -> Int {
            guard let s = it.next(), let v = Int(s), range.contains(v) else {
                throw OptionError(description: "\(name) needs a number from \(range.lowerBound) to \(range.upperBound).")
            }
            return v
        }
        while let a = it.next() {
            switch a {
            case "--port": o.port = try intArg(a, 1...65535)
            case "--password": o.password = try value(a)
            case "--fps": o.fps = try intArg(a, 1...60)
            case "--monitor": o.monitor = try intArg(a, 0...64)
            case "--view-only": o.viewOnly = true
            case "--no-audio": o.noAudio = true
            case "--test-tone": o.testTone = true
            case "--full-res": o.fullRes = true
            case "--no-resize": o.noResize = true
            case "--config": o.config = try value(a)
            case "--no-update": o.noUpdate = true
            case "--update-url": o.updateURL = try value(a)
            case "--check-update": o.checkUpdate = true
            case "--make-app": o.makeApp = try value(a)
            case "--version": o.showVersion = true
            case "-h", "--help": o.showHelp = true
            default: throw OptionError(description: "Unknown option: \(a)")
            }
        }
        return o
    }

    /// Turns a settings file into arguments. One option per line, written like the command-line flag
    /// (`--password secret`, `--fps 60`, `--no-audio`); blank lines and lines starting with `#` are
    /// ignored. Everything after the flag is one value (so a password may contain spaces); a value in
    /// matching double or single quotes loses the quotes.
    static func settingsArgs(_ text: String) -> [String] {
        var out: [String] = []
        for raw in text.split(omittingEmptySubsequences: false, whereSeparator: { $0 == "\n" || $0 == "\r\n" || $0 == "\r" }) {
            let line = raw.trimmingCharacters(in: .whitespaces)
            if line.isEmpty || line.hasPrefix("#") { continue }
            guard let sp = line.firstIndex(where: { $0 == " " || $0 == "\t" }) else {
                out.append(line)
                continue
            }
            out.append(String(line[..<sp]))
            var v = line[sp...].trimmingCharacters(in: .whitespaces)
            if v.count >= 2, let f = v.first, f == "\"" || f == "'", v.last == f {
                v = String(v.dropFirst().dropLast())
            }
            out.append(v)
        }
        return out
    }

    /// Reads the settings file (the one named by --config, else `defaultSettings` if it exists),
    /// then lets the real command line override it. QUESTVNC_UPDATE_URL is used when neither sets
    /// --update-url.
    static func load(commandLine: [String], defaultSettings: String?,
                     environment: [String: String] = ProcessInfo.processInfo.environment) throws -> Options {
        let cmd = try parseArgs(commandLine)   // validates the command line and finds --config
        var path: String? = nil
        if let c = cmd.config {
            guard FileManager.default.fileExists(atPath: c) else {
                throw OptionError(description: "Settings file not found: \(c)")
            }
            path = c
        } else if let d = defaultSettings, FileManager.default.fileExists(atPath: d) {
            path = d
        }
        var fileArgs: [String] = []
        if let p = path {
            guard let data = FileManager.default.contents(atPath: p) else {
                throw OptionError(description: "Can't read the settings file \(p).")
            }
            fileArgs = settingsArgs(String(decoding: data, as: UTF8.self))
            do {
                _ = try parseArgs(fileArgs)
            } catch let e as OptionError {
                throw OptionError(description: "In the settings file \(p): \(e.description)")
            }
        }
        var o = try parseArgs(fileArgs + commandLine)
        o.settingsFileUsed = path
        if o.updateURL == nil, let env = environment["QUESTVNC_UPDATE_URL"], !env.isEmpty {
            o.updateURL = env
        }
        return o
    }

    /// Command line only; prints usage and exits on a bad option, handles --version and --help.
    static func parse(_ args: [String]) -> Options {
        finish { try parseArgs(args) }
    }

    /// Settings file plus command line; prints usage and exits on a bad option, handles --version and --help.
    static func loadOrExit(_ args: [String], defaultSettings: String?) -> Options {
        finish { try load(commandLine: args, defaultSettings: defaultSettings) }
    }

    private static func finish(_ body: () throws -> Options) -> Options {
        let o: Options
        do {
            o = try body()
        } catch {
            log("\(error)")
            log(usage)
            exit(2)
        }
        if o.showVersion {
            log("Quest VNC Server \(questVncVersion)")
            exit(0)
        }
        if o.showHelp {
            log(usage)
            exit(0)
        }
        return o
    }
}
