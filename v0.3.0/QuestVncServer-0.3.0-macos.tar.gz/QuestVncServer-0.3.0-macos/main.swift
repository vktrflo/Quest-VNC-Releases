// Quest VNC Server for macOS (13 Ventura or later): a VNC server that also streams the Mac's
// sound over the same connection (QEMU audio extension). See README.md and ../SPEC.md.
//
// Build: swiftc -O -target $(uname -m)-apple-macos13.0 *.swift -import-objc-header zlib-bridge.h -lz -o QuestVncServer
// (run.command does this on first run; install.command also wraps it as ~/Applications/Quest VNC Server.app.)

import CoreGraphics
import Foundation
import SystemConfiguration

setvbuf(stdout, nil, _IOLBF, 0)

@available(macOS 13.0, *)
final class App: @unchecked Sendable {
    let options: Options
    /// Running from ~/Applications/Quest VNC Server.app (started by the LaunchAgent).
    let installed: Bool
    let audio = AudioHub()
    let capture: ScreenCapture
    let clipboard = MacClipboard()
    var server: VncServer?
    var input: MacInput?

    init(options: Options, installed: Bool) {
        self.options = options
        self.installed = installed
        capture = ScreenCapture(options: options, audio: audio)
    }

    func run() {
        log("Quest VNC Server \(questVncVersion) for macOS")
        if installed {
            finishPreviousUpdate(layout: InstallLayout(), currentVersion: questVncVersion, note: MacUpdate.permissionNote)
        }
        if let s = options.settingsFileUsed { log("Settings: \(s)") }
        if !CGPreflightScreenCaptureAccess() {
            // Shows the system prompt the first time; capture below fails until it's allowed.
            CGRequestScreenCaptureAccess()
        }

        let inputLine: String
        if options.viewOnly {
            inputLine = "off (--view-only)"
        } else if checkAccessibility(prompt: true) {
            inputLine = "on"
        } else {
            inputLine = "NOT ALLOWED YET (you can watch, but keyboard and mouse won't work)"
            if installed {
                log("""
                    Keyboard and mouse control needs permission: System Settings > Privacy & Security >
                    Accessibility, turn on Quest VNC Server.
                    """)
            } else {
                log("""
                    Keyboard and mouse control needs permission: System Settings > Privacy & Security >
                    Accessibility, turn on Terminal (or the app you started this from), then run this again.
                    """)
            }
        }

        capture.start { [self] err in
            if let err = err {
                log(err)
                if installed {
                    log("(For the installed app, the permission is called \"Quest VNC Server\". After turning it on, it starts again by itself.)")
                }
                retryLaterAndExit()
            }
            startServer(inputLine: inputLine)
        }
    }

    /// Exits with an error. The installed copy waits a minute first, so launchd (which starts it again)
    /// doesn't retry every few seconds while a permission is missing or the port is taken.
    func retryLaterAndExit() -> Never {
        if installed {
            log("Trying again in 60 seconds.")
            sleep(60)
        }
        exit(1)
    }

    /// Puts the original display mode back (Ctrl+C, kill, closing the window, normal exit).
    func shutdown() {
        server?.resize.restoreAll()
    }

    private func startServer(inputLine: String) {
        guard let frames = capture.frames else { exit(1) }
        if options.testTone {
            audio.available = true
            TestTone(hub: audio).start()
        } else {
            audio.available = capture.capturingAudio
        }
        if !options.viewOnly {
            input = MacInput(geometry: capture.geometry, frames: { [weak frames] in frames?.current })
        }
        let name = (SCDynamicStoreCopyComputerName(nil, nil) as String?) ?? posixHostName()
        let capture = self.capture
        let resolution = MacResolution(displayID: capture.displayID, fullRes: options.fullRes,
                                       onChange: { capture.refreshSize() })
        let s = VncServer(options: options, frames: frames, audio: audio, input: input, clipboard: clipboard,
                          jpeg: ImageIOJpeg(), desktopName: "Quest VNC Server (\(name))", resolution: resolution)
        do {
            try s.start()
        } catch {
            log("Can't start: \(error)")
            retryLaterAndExit()
        }
        server = s
        clipboard.server = s
        clipboard.start()
        capture.watchDisplayChanges()

        log("Listening on port \(options.port)")
        let addrs = lanAddresses()
        if addrs.isEmpty {
            log("This Mac's address: none found (is Wi-Fi or Ethernet connected?)")
        } else {
            for a in addrs { log("This Mac's address: \(a)") }
        }
        var screen = "Screen: \(capture.width)x\(capture.height) (display \(capture.displayIndex) of \(capture.displayCount)"
        if !options.fullRes, let mode = CGDisplayCopyDisplayMode(capture.displayID), mode.pixelWidth != capture.width {
            screen += "; --full-res would capture \(mode.pixelWidth)x\(mode.pixelHeight)"
        }
        log(screen + ")")
        if options.password != nil {
            log("Password: set")
        } else {
            log("Password: NOT SET. Anyone on your network can see and control this Mac. Use --password to set one.")
        }
        if options.noAudio {
            log("Sound: off (--no-audio)")
        } else if options.testTone {
            log("Sound: TEST TONE (a 440 Hz beep every second)")
        } else if audio.available {
            log("Sound: on (the Mac's sound, via ScreenCaptureKit)")
        } else {
            log("Sound: not available (screen sharing still works)")
        }
        log("Keyboard and mouse: \(inputLine)")
        log("Resolution changes from viewers: " + (options.noResize || options.viewOnly ? "off" : "allowed (undone when they leave)"))
        if installed {
            log("Running in the background; it starts by itself when you log in. Log: \(InstallLayout().logPath)")
        } else {
            log("Leave this window open while you use Quest VNC. Press Ctrl+C to stop.")
        }
        MacUpdate.startUpdater(options: options, installed: installed, viewerCount: { [weak s] in s?.viewerCount ?? 0 })
    }
}

/// Run at exit to restore the display mode (set once the app exists).
var exitHook: (() -> Void)? = nil

let installLayout = InstallLayout()
let options = Options.loadOrExit(Array(CommandLine.arguments.dropFirst()), defaultSettings: installLayout.settingsPath)
if let dest = options.makeApp {
    exit(MacUpdate.makeAppHere(dest))
}
if options.checkUpdate {
    exit(checkForUpdateOnce(feedURL: options.updateURL ?? defaultUpdateURL, transport: URLSessionTransport()))
}
let runningInstalled = installLayout.isInstalled(executable: MacUpdate.selfExecutable())
if runningInstalled {
    truncateLogIfLarge(fd: 1, limit: 1 << 20)   // launchd appends to ~/Library/Logs/QuestVncServer.log
}
if #available(macOS 13.0, *) {
    let app = App(options: options, installed: runningInstalled)
    exitHook = { app.shutdown() }
    atexit { exitHook?() }
    var signalSources: [DispatchSourceSignal] = []
    for sig in [SIGINT, SIGTERM, SIGHUP] {
        signal(sig, SIG_IGN)
        let src = DispatchSource.makeSignalSource(signal: sig, queue: .main)
        src.setEventHandler { exit(0) }   // exit() runs the atexit hook, which restores the mode
        src.resume()
        signalSources.append(src)
    }
    app.run()
    withExtendedLifetime(signalSources) { RunLoop.main.run() }   // never returns
} else {
    log("Quest VNC Server needs macOS 13 Ventura or later.")
    exit(1)
}
