// Display mode changes asked for by viewers (SetDesktopSize). The choice of size happens in the
// core (CoreResize.swift); this file lists the display's modes and switches between them.
// Changes are made with .forAppOnly, so macOS also puts the old mode back if the program dies.

import CoreGraphics
import Foundation

final class MacResolution: ResolutionControl {
    private let displayID: CGDirectDisplayID
    private let fullRes: Bool
    private let onChange: () -> Void
    private let lock = NSLock()
    private var original: CGDisplayMode? = nil

    /// `onChange` runs on the main thread after a mode change (to make the capture follow).
    init(displayID: CGDirectDisplayID, fullRes: Bool, onChange: @escaping () -> Void) {
        self.displayID = displayID
        self.fullRes = fullRes
        self.onChange = onChange
    }

    private func allModes() -> [CGDisplayMode] {
        let opts = [kCGDisplayShowDuplicateLowResolutionModes: kCFBooleanTrue] as CFDictionary
        return (CGDisplayCopyAllDisplayModes(displayID, opts) as? [CGDisplayMode]) ?? []
    }

    /// Mode size in framebuffer units: points normally, pixels with --full-res.
    private func size(_ m: CGDisplayMode) -> (w: Int, h: Int) {
        fullRes ? (m.pixelWidth, m.pixelHeight) : (m.width, m.height)
    }

    func availableSizes() -> [(w: Int, h: Int)] {
        var seen = Set<Int>()
        var out: [(w: Int, h: Int)] = []
        let modes = allModes()
        // Desktop-usable modes only, unless the display has none.
        let usable = modes.filter { $0.isUsableForDesktopGUI() }
        for m in (usable.isEmpty ? modes : usable) {
            let s = size(m)
            if seen.insert(s.w << 20 | s.h).inserted { out.append(s) }
        }
        return out
    }

    func setSize(w: Int, h: Int) -> Bool {
        lock.lock(); defer { lock.unlock() }
        let current = CGDisplayCopyDisplayMode(displayID)
        let currentScale = current.map { Double($0.pixelWidth) / Double(max(1, $0.width)) } ?? 1
        // Same size: prefer desktop-usable, the current Retina scale, the highest refresh rate,
        // then the sharper (more pixels) mode.
        func score(_ m: CGDisplayMode) -> [Double] {
            let scale = Double(m.pixelWidth) / Double(max(1, m.width))
            return [m.isUsableForDesktopGUI() ? 1 : 0, abs(scale - currentScale) < 0.01 ? 1 : 0,
                    m.refreshRate, Double(m.pixelWidth)]
        }
        let candidates = allModes().filter { size($0) == (w, h) }
        guard let best = candidates.max(by: { score($0).lexicographicallyPrecedes(score($1)) }) else { return false }
        if original == nil { original = current }
        return apply(best)
    }

    func restore() {
        lock.lock(); defer { lock.unlock() }
        guard let o = original else { return }
        original = nil
        if !apply(o) { log("Couldn't restore the original resolution") }
    }

    private func apply(_ mode: CGDisplayMode) -> Bool {
        var config: CGDisplayConfigRef?
        guard CGBeginDisplayConfiguration(&config) == .success, let cfg = config else { return false }
        guard CGConfigureDisplayWithDisplayMode(cfg, displayID, mode, nil) == .success else {
            CGCancelDisplayConfiguration(cfg)
            return false
        }
        guard CGCompleteDisplayConfiguration(cfg, .forAppOnly) == .success else { return false }
        let done = onChange
        DispatchQueue.main.async { done() }
        return true
    }
}
