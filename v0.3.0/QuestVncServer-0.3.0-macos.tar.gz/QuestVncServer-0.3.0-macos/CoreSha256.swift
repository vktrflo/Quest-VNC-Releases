// SHA-256 of a file, for checking downloaded updates. Uses CommonCrypto on macOS and a small
// portable implementation elsewhere (so the core still builds and is tested on Linux).

import Foundation
#if canImport(CommonCrypto)
import CommonCrypto
#endif

/// Portable SHA-256 (FIPS 180-4), fed in pieces.
struct PortableSha256 {
    private static let k: [UInt32] = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
    ]
    private var h: [UInt32] = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                               0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]
    private var buffer: [UInt8] = []
    private var length: UInt64 = 0

    mutating func update(_ data: UnsafeRawBufferPointer) {
        length &+= UInt64(data.count)
        var i = 0
        if !buffer.isEmpty {
            let take = min(64 - buffer.count, data.count)
            buffer.append(contentsOf: data[0..<take])
            i = take
            if buffer.count == 64 {
                buffer.withUnsafeBytes { block($0, 0) }
                buffer.removeAll(keepingCapacity: true)
            }
        }
        while data.count - i >= 64 {
            block(data, i)
            i += 64
        }
        if i < data.count { buffer.append(contentsOf: data[i...]) }
    }

    mutating func update(_ bytes: [UInt8]) { bytes.withUnsafeBytes { update($0) } }

    mutating func finish() -> [UInt8] {
        let bits = length &* 8
        var pad: [UInt8] = [0x80]
        let rem = (buffer.count + 1) % 64
        pad += [UInt8](repeating: 0, count: rem <= 56 ? 56 - rem : 120 - rem)
        for s in stride(from: 56, through: 0, by: -8) { pad.append(UInt8(truncatingIfNeeded: bits >> UInt64(s))) }
        let saved = length
        update(pad)
        length = saved
        var out: [UInt8] = []
        for v in h { out += [UInt8(v >> 24), UInt8(truncatingIfNeeded: v >> 16), UInt8(truncatingIfNeeded: v >> 8), UInt8(truncatingIfNeeded: v)] }
        return out
    }

    private mutating func block(_ p: UnsafeRawBufferPointer, _ off: Int) {
        @inline(__always) func rotr(_ x: UInt32, _ n: UInt32) -> UInt32 { (x >> n) | (x << (32 - n)) }
        var w = [UInt32](repeating: 0, count: 64)
        for t in 0..<16 {
            let b = off + t * 4
            w[t] = UInt32(p[b]) << 24 | UInt32(p[b + 1]) << 16 | UInt32(p[b + 2]) << 8 | UInt32(p[b + 3])
        }
        for t in 16..<64 {
            let s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >> 3)
            let s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >> 10)
            w[t] = w[t - 16] &+ s0 &+ w[t - 7] &+ s1
        }
        var a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7]
        for t in 0..<64 {
            let t1 = hh &+ (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) &+ ((e & f) ^ (~e & g)) &+ PortableSha256.k[t] &+ w[t]
            let t2 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) &+ ((a & b) ^ (a & c) ^ (b & c))
            hh = g; g = f; f = e; e = d &+ t1; d = c; c = b; b = a; a = t1 &+ t2
        }
        h[0] &+= a; h[1] &+= b; h[2] &+= c; h[3] &+= d; h[4] &+= e; h[5] &+= f; h[6] &+= g; h[7] &+= hh
    }
}

func hexString(_ bytes: [UInt8]) -> String {
    bytes.map { String(format: "%02x", $0) }.joined()
}

/// Lower-case hex SHA-256 of a file, or nil if it can't be read.
func sha256Hex(ofFile path: String) -> String? {
    guard let fh = FileHandle(forReadingAtPath: path) else { return nil }
    defer { fh.closeFile() }
    #if canImport(CommonCrypto)
    var ctx = CC_SHA256_CTX()
    CC_SHA256_Init(&ctx)
    while true {
        let chunk = fh.readData(ofLength: 1 << 20)
        if chunk.isEmpty { break }
        chunk.withUnsafeBytes { _ = CC_SHA256_Update(&ctx, $0.baseAddress, CC_LONG($0.count)) }
    }
    var digest = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
    CC_SHA256_Final(&digest, &ctx)
    return hexString(digest)
    #else
    var s = PortableSha256()
    while true {
        let chunk = fh.readData(ofLength: 1 << 20)
        if chunk.isEmpty { break }
        chunk.withUnsafeBytes { s.update($0) }
    }
    return hexString(s.finish())
    #endif
}
