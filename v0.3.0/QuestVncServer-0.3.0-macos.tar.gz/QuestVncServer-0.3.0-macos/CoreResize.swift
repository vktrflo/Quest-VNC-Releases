// Resolution changes requested by viewers (ExtendedDesktopSize -308 + SetDesktopSize 251).
// The platform supplies a ResolutionControl; mode choice and bookkeeping live here so they can be
// tested on Linux.

import Foundation
#if canImport(Darwin)
import Darwin
#elseif canImport(Glibc)
import Glibc
#endif

let encExtendedDesktopSize: Int32 = -308

/// Display-mode access for the shared monitor. Sizes are in framebuffer units (points, or pixels
/// with --full-res on macOS).
protocol ResolutionControl: AnyObject {
    /// Sizes of the modes the display offers.
    func availableSizes() -> [(w: Int, h: Int)]
    /// Switches to the best mode of exactly this size (one of availableSizes). Remembers the
    /// original mode the first time. Returns false if the change failed.
    func setSize(w: Int, h: Int) -> Bool
    /// Puts the original mode back (no-op if nothing was changed).
    func restore()
}

/// ExtendedDesktopSize status codes.
enum ResizeStatus: Int {
    case ok = 0, prohibited = 1, failed = 2, invalid = 3
}

/// Picks the mode for a request: exact match; else the closest mode with the same aspect ratio
/// (within 2%) that is not larger; else the largest mode that fits inside; else nil (invalid).
func chooseMode(w: Int, h: Int, from modes: [(w: Int, h: Int)]) -> (w: Int, h: Int)? {
    guard w > 0, h > 0 else { return nil }
    if let m = modes.first(where: { $0.w == w && $0.h == h }) { return m }
    let fits = modes.filter { $0.w <= w && $0.h <= h && $0.w > 0 && $0.h > 0 }
    let aspect = Double(w) / Double(h)
    let sameAspect = fits.filter { abs(Double($0.w) / Double($0.h) - aspect) / aspect <= 0.02 }
    let best = { (a: [(w: Int, h: Int)]) in a.max(by: { $0.w * $0.h < $1.w * $1.h }) }
    return best(sameAspect) ?? best(fits)
}

/// Payload of an ExtendedDesktopSize rectangle: one screen, id 0, at 0,0.
func extendedDesktopSizeRect(reason: Int, status: Int, w: Int, h: Int) -> [UInt8] {
    var b = ByteWriter()
    b.rectHeader(x: reason, y: status, w: w, h: h, encoding: encExtendedDesktopSize)
    b.u8(1); b.pad(3)
    b.u32(0); b.u16(0); b.u16(0); b.u16(w); b.u16(h); b.u32(0)
    return b.bytes
}

/// Server-wide resize state: who asked last, and restoring when they leave.
final class ResizeCoordinator {
    private let control: ResolutionControl?
    private let allowed: Bool
    private let lock = NSLock()           // serialises mode changes
    private let causeLock = NSLock()
    private var requester: Int? = nil     // session whose request is in effect
    private var cause: (id: Int, until: Double)? = nil

    init(control: ResolutionControl?, allowed: Bool) {
        self.control = control
        self.allowed = allowed
    }

    /// Handles a SetDesktopSize. Returns the status and, when ok, the chosen size.
    func request(from id: Int, peer: String, w: Int, h: Int, currentW: Int, currentH: Int)
        -> (ResizeStatus, (w: Int, h: Int)?) {
        guard allowed, let control = control else { return (.prohibited, nil) }
        lock.lock(); defer { lock.unlock() }
        guard let m = chooseMode(w: w, h: h, from: control.availableSizes()) else {
            log("Resolution \(w)x\(h) requested by \(peer); no suitable mode")
            return (.invalid, nil)
        }
        if m.w != currentW || m.h != currentH {
            setCause(id)
            guard control.setSize(w: m.w, h: m.h) else {
                clearCause()
                log("Resolution \(w)x\(h) requested by \(peer); changing to \(m.w)x\(m.h) failed")
                return (.failed, nil)
            }
        }
        requester = id
        log("Resolution \(w)x\(h) requested by \(peer); set to \(m.w)x\(m.h)")
        return (.ok, m)
    }

    /// A viewer left: if its request is the one in effect, put the original mode back.
    func sessionEnded(_ id: Int) {
        lock.lock(); defer { lock.unlock() }
        guard requester == id, let control = control else { return }
        requester = nil
        clearCause()
        control.restore()
        log("Resolution restored (the viewer that changed it left)")
    }

    /// Server exit.
    func restoreAll() {
        lock.lock(); defer { lock.unlock() }
        requester = nil
        control?.restore()
    }

    private func setCause(_ id: Int) {
        causeLock.lock(); cause = (id, monotonicSeconds() + 5); causeLock.unlock()
    }

    func clearCause() {
        causeLock.lock(); cause = nil; causeLock.unlock()
    }

    /// The session whose request caused a size change seen now, if any (within 5 s of the request).
    func currentCause() -> Int? {
        causeLock.lock(); defer { causeLock.unlock() }
        guard let c = cause, monotonicSeconds() < c.until else { return nil }
        return c.id
    }
}
