# Quest VNC Server for Windows

Quest VNC Server lets you see and control your Windows PC from the Quest VNC app on your headset, and it
plays the PC's sound in the headset over the same connection. It replaces running TightVNC together with
the old Quest VNC Audio Sender. Other VNC viewers (TigerVNC, RealVNC, TightVNC Viewer, noVNC) work too,
they just don't get the sound.

It is a single file, `QuestVncServer.exe`. You can install it for your Windows user, so it starts by
itself when you sign in and keeps itself up to date, or just run it from any folder ("portable" use).
Neither needs administrator rights.

## Install (recommended)

1. Unzip the download and double-click `QuestVncServer.exe`.
2. Windows SmartScreen may say "Windows protected your PC" because the program is not signed.
   Click **More info**, then **Run anyway**.
3. A window asks **Install Quest VNC Server for this user? [Y/n]**. Press Enter.
4. Type the password the Quest VNC app should use, press Enter, and type it again. The letters are shown
   as `*`. Only the first 8 characters count.
5. Windows Firewall asks whether to allow the program on networks. Tick **Private networks** and click
   **Allow access**. If your home network is set to "Public" in Windows, either change it to "Private"
   (Settings > Network & internet > your connection > Network profile type) or tick "Public networks" too.
6. The window shows the PC's address, for example `192.168.1.20  port 5900`. Enter that address in the
   Quest VNC app together with the password. Press Enter to close the window.

That's it. The server now runs in the background without a window, starts every time you sign in to
Windows, and installs new versions by itself. You can delete the downloaded zip.

What the installer does, all for your Windows user only:

- copies the program to `%LOCALAPPDATA%\Programs\QuestVncServer\QuestVncServer.exe`
- writes your settings to `%APPDATA%\QuestVncServer\server.conf` (only your user can read it)
- starts the server when you sign in (Settings > Apps > Startup lists it as "QuestVncServer")
- adds **Quest VNC Server** to the Start menu; it shows whether the server is running and the address to
  use in the app (if the background server isn't running, it starts the server in a window instead)
- adds **Quest VNC Server** to Settings > Apps > Installed apps, where you can uninstall it

From a Command Prompt you can also install in one step, with any options you want saved:

```
QuestVncServer.exe --install --password MySecret --fps 20
```

Running the installer again (for example from a newer zip) replaces the program and keeps your settings,
unless you give options on the command line, which then replace the settings.

When it runs in the background, the server writes what it would print to
`%LOCALAPPDATA%\QuestVncServer\server.log` (emptied when it reaches 1 MB). Look there if something doesn't
work. It is not a Windows service on purpose: a service can't see or control your desktop.

## Changing the settings

Open `%APPDATA%\QuestVncServer\server.conf` in Notepad (press Win+R, paste
`notepad %APPDATA%\QuestVncServer\server.conf`, press Enter). It has one option per line, written exactly
like on the command line (see Options below), for example:

```
--password MySecret
--fps 20
--no-audio
```

Lines starting with `#` are ignored. Save the file, then sign out of Windows and back in, so the server
starts again and reads it. Options given on a command line override the file. A different settings file can be used with `--config FILE`.

## Updates

An installed server checks for a new version one minute after it starts and then every 12 hours. When it
finds one, it downloads it, checks that the file is exactly the published one (size and SHA-256
fingerprint; anything else is thrown away and tried again later), and waits until no viewer is connected,
so nobody's session is cut off. Then it swaps in the new program and restarts with the same settings. This
takes a few seconds. The log shows each step:

```
Update 0.3.0 available
Downloaded update 0.3.0
Installing update 0.3.0 now (no viewers connected)
Updated to 0.3.0
```

To turn updates off, add `--no-update` to the settings file. To see whether there is a new version without
installing it, run `QuestVncServer.exe --check-update` (exit code 0 = up to date, 10 = update available).
Updates come from `https://github.com/vktrflo/Quest-VNC-Releases`; `--update-url URL` or the environment
variable `QUESTVNC_UPDATE_URL` points the server at another release feed.

## Uninstall

Settings > Apps > Installed apps (or "Apps & features"), find **Quest VNC Server**, click **Uninstall**. A
window stops the server, removes the autostart, the Start menu entry and the program, and asks whether to
delete your settings file too (press Enter to keep it). Or run `QuestVncServer.exe --uninstall`.

## Portable use (without installing)

Answer **n** to the install question, or start the program from a Command Prompt or PowerShell window, and
it works exactly as before: it runs in that window until you close it, takes its options from the command
line only, and never changes itself. It does tell you once in the window when a new version is available.

1. Copy `QuestVncServer.exe` to a folder of your choice, for example `C:\Tools\QuestVnc`.
2. Start it from a Command Prompt or PowerShell window so you can add a password:

   ```
   QuestVncServer.exe --password MySecret
   ```

3. The window shows the PC's address, for example `This PC: 192.168.1.20`. Enter that address in the
   Quest VNC app (port 5900, unless you changed it) together with the password.

Leave the window open while you use the headset. Press Ctrl+C or close the window to stop the server.
A portable copy can't run at the same time as the installed one on the same port; use `--port 5901`.

## Password

Always set a password with `--password`. Without one, anyone on your network can see and control your
PC, and the program prints a warning. VNC passwords only use the first 8 characters, so `MySecret123`
and `MySecret` are the same password. Use plain letters and digits; the headset app sends only basic
ASCII characters.

A wrong password is refused and logged in the window. There is no lockout, so typing the password wrong
a few times never blocks you.

## Options

| Option | Meaning |
|---|---|
| `--port 5900` | TCP port to listen on (all network adapters). |
| `--password SECRET` | VNC password. Only the first 8 characters count. |
| `--fps 30` | Highest screen capture rate, 1 to 60. Lower values use less CPU and network. |
| `--monitor N` | Which display to share. 0 is the primary display. The window lists all displays and their numbers at start. |
| `--view-only` | Viewers can watch but keyboard and mouse input is ignored. |
| `--no-audio` | Don't capture or send sound. |
| `--no-resize` | Don't let viewers change the PC's screen resolution. |
| `--test-tone` | Send a short 440 Hz beep every second instead of the PC's sound, to check the sound path. |
| `--install` | Install for this user (see Install). Other options on the same line go into the settings file. |
| `--uninstall` | Remove the installed copy, its autostart, Start menu entry and Apps entry. |
| `--background` | Run without a window and log to `%LOCALAPPDATA%\QuestVncServer\server.log`. Used by the autostart. |
| `--config FILE` | Read options from FILE instead of the default settings file. |
| `--no-update` | Never check for or install updates. |
| `--update-url URL` | Release feed to check for updates (also the `QUESTVNC_UPDATE_URL` environment variable). |
| `--check-update` | Check once, print the result and exit (0 = up to date, 10 = update available). |
| `--version` | Print the version and exit. |

Example: `QuestVncServer.exe --password MySecret --monitor 1 --fps 20`

## What it can and cannot control

The server runs as a normal program in your Windows session. Because of how Windows protects itself:

- It cannot see or control the lock screen, the login screen, or the dimmed "User Account Control"
  (UAC) prompt. While one of these is shown, the headset keeps showing the last picture and input is
  ignored. After you unlock or answer the prompt at the PC, it continues by itself.
- It cannot control windows of programs that run "as administrator" (for example Task Manager, some
  installers and settings pages) unless it also runs as administrator. To do that, right-click
  `QuestVncServer.exe` and choose **Run as administrator**, or tick **Run as administrator** under
  **Properties > Shortcut > Advanced** for the startup shortcut. The window prints a message when
  Windows blocks input.

Controlling the lock screen and UAC prompts would need a Windows service, which this program is not.

## Sound

The server records whatever the PC plays on its default output device (the same sound you would hear
from the speakers or headphones), using Windows' loopback recording. The sound still plays on the PC
too. If you switch the default output device, for example by plugging in headphones, the server
follows within about two seconds.

Only the Quest VNC app receives sound. The window shows at start which device is recorded. If no sound
device is available, the server keeps working without sound.

Sound is sent as a steady stream at the PC's own timing: nothing is added or left out while something
plays, and when nothing plays the server sends silence of exactly the right length. Surround output
(5.1, 7.1) is mixed down to stereo, including the centre channel. When the picture changes a lot, the
server sends the picture only as fast as the headset can take it, so the sound never waits behind it.

## Changing the resolution from the headset

The Quest VNC app can ask the PC to switch the shared display to another resolution, for example
1920 x 1080 or 2560 x 1440. If the display has exactly that mode, it is used. If not, the server picks
the closest mode with the same shape that is not bigger, or else the biggest mode that fits, and the app
shows the size it actually got. Choosing "PC default" in the app goes back to the original resolution.

The change is temporary. The original resolution comes back when the viewer that asked for the change
disconnects, when you stop the server (Ctrl+C or closing the window), and, because Windows treats the
change as temporary, even if the server crashes. Nothing is saved in the Windows display settings.

If several viewers are connected, the most recent request wins and all viewers see the new size. Use
`--no-resize` to keep the PC's resolution fixed; resolution requests are also refused with `--view-only`.
Other windows on the PC may move or get smaller while a lower resolution is active, just as when you
change the resolution yourself.

## Multiple displays and high-DPI screens

One display is shared at a time; choose it with `--monitor`. The server captures real screen pixels on
scaled (high-DPI) displays, so a 4K display set to 150 % is shared as 3840 x 2160. If the display
resolution changes while a viewer is connected, the Quest VNC app adapts to the new size. Resolution
requests from the headset apply to the shared display only.

## Troubleshooting

- **The headset can't connect.** Check that the PC and the headset are on the same network, that you
  used the address shown in the window, and that Windows Firewall allows the program (Windows Security >
  Firewall & network protection > Allow an app through firewall).
- **"Could not listen on port 5900".** Another VNC server (or a second copy of this one, for example the
  installed one running in the background) already uses the port. Close it, or start this one with
  `--port 5901` and use that port in the app.
- **The installed server doesn't seem to run.** Open **Quest VNC Server** from the Start menu: it says
  whether it is running. Check `%LOCALAPPDATA%\QuestVncServer\server.log` for errors, for example a typo in
  the settings file.
- **Black or frozen picture.** The window prints a "Screen capture" line when it switches between
  Desktop Duplication (fast) and GDI (compatible) capture. Remote Desktop sessions and some graphics
  drivers only work with GDI, which uses more CPU. A frozen picture is expected while the lock screen or a
  UAC prompt is shown.
- **No sound in the headset.** Start the server with `--test-tone`. If you hear the beeps, the
  connection is fine and the problem is on the PC side (muted app, wrong default device).
- **Sound breaks up.** When the server closes a connection it prints how much sound was dropped because
  the network or the headset could not keep up. If that number is large, use a 5 GHz Wi-Fi network or a
  lower picture quality in the app.

## For developers

The source is in `src/`. `QuestVnc.Core` is the platform-neutral part (RFB protocol, sessions, tile
comparison, Tight and Raw encoders, JPEG encoder, sound conversion, VNC authentication) and builds on any
OS. `QuestVncServer` is the Windows part (Desktop Duplication and GDI capture, SendInput, clipboard,
WASAPI loopback). The protocol is described in `../SPEC.md`.

Build the exe (works on Linux too):

```
dotnet publish src/QuestVncServer -c Release -o publish
```

Run the tests on Linux or macOS (needs the .NET 8 SDK, Python 3 and a JDK):

```
tests/run_tests.sh                               # protocol tests + the headset app's own RFB client
dotnet run --project tests/InteropCheck          # Win32 struct layouts and key mapping
dotnet run --project tests/TestHost -c Release -- --bench   # encoder speed
```

Install and update code: `QuestVnc.Core` holds the platform-neutral parts (`SettingsFile`, `AppVersion`,
`ReleaseFeed`, the `Updater` state machine with an injectable download transport and viewer count,
`ExeSwapper` with injectable file operations and process start, `CappedLogWriter`, `InstallLayout`), which
`tests/UpdateTests` checks on Linux. `QuestVncServer` adds the Windows parts: `Installer.cs` (registry,
copying, running copies, the update swap), `ShellLink.cs` (the Start menu shortcut through IShellLinkW,
using the .NET 8 COM source generator so it stays trim-safe) and `WindowsConsole.cs`.

Why the exe stays a console program: run from Command Prompt or PowerShell it must behave as before (the
prompt waits, output and Ctrl+C go to that window), and a double-click must open a console window for the
install prompt. A GUI-subsystem exe (WinExe) with AttachConsole would return the prompt at once and mix the
server's output with the shell's. So the cost is on the autostart side: Windows opens a console window for
`--background`, and the program immediately starts a copy of itself with CREATE_NO_WINDOW (a console with no
window, marked by `QUESTVNC_HIDDEN=1`) and exits, which closes the window in both the classic console and
Windows Terminal. At sign-in a window may flash for a moment. The installer and the updater start the
background copy hidden directly, so no window appears then.

How the Windows update swap works: the new exe is downloaded to `QuestVncServer.update.tmp` in the install
folder and verified; the running exe is renamed to `QuestVncServer.old.exe` (Windows allows renaming, not
deleting, a running exe), the new one is moved into place and started with the same arguments plus
`QUESTVNC_UPDATED_FROM_PID`. If it can't be started or exits within 3 seconds, the old exe is moved back.
The old copy then stops; the new one waits for it to exit (it still holds the port), deletes the `.old.exe`,
logs "Updated to x.y.z" and updates the version shown in Installed apps.
