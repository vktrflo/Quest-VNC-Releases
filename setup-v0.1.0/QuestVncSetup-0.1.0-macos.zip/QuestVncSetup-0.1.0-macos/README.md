# Quest VNC for macOS: one-step setup

This sets up your Mac so the Quest VNC headset app can show its screen and play its sound.

* **Picture:** macOS's built-in Screen Sharing (a VNC server). Nothing extra to install.
* **Sound:** *Quest VNC Audio*, a small helper that the installer builds and starts automatically when you log in.

Needs macOS 13 Ventura or later and an administrator account. The installer takes about 5 minutes.
The first time, it may also download Apple's free Command Line Tools, which takes a few minutes more.

## Install

1. Unzip the download. Keep the folder as it is.
2. Right-click **Install Quest VNC.command** and choose **Open**, then **Open** again.
   (Double-clicking is blocked the first time because the file was downloaded.)
3. Answer the questions in the Terminal window:
   * **Sound port:** press Return to use 5910. Choose another number only if something else uses 5910.
   * **Picture port:** press Return to keep 5900. macOS Screen Sharing always uses 5900, and Apple has no setting for it.
     The installer can move it with an unofficial tweak, but a macOS update may undo that later. Keep 5900 unless you have a reason not to.
   * **Password:** choose a password for this Mac. Typing is hidden. VNC only checks the first 8 characters, so 8 or fewer is best.
4. If asked, install the **Command Line Tools**: click **Install** (not *Get Xcode*), wait, then press Return.
5. **Turn on Screen Sharing.** The installer opens System Settings at General > Sharing and shows these steps:
   1. If **Remote Management** is on, turn it off. macOS won't run it together with Screen Sharing.
   2. Turn on **Screen Sharing**.
   3. Click the **(i)** button next to Screen Sharing.
   4. Turn on **VNC viewers may control screen with password**, type the same password, and click **OK**.
   5. Click **Done**, then press Return in Terminal. The installer checks that it worked.

   macOS doesn't let scripts switch Screen Sharing on, so you have to click it yourself.
   The installer offers to store the password for you first. If that works on your Mac, you may only need step 2.
6. **Allow sound capture.** macOS asks: *"Quest VNC Audio would like to record this computer's screen and audio."*
   Click **Open System Settings**, turn on **Quest VNC Audio** under Privacy & Security > **Screen & System Audio Recording**,
   then press Return in Terminal. If macOS offers **Quit & Reopen**, choose **Later**, because the installer restarts it.
   Apple puts system sound under screen recording. Quest VNC Audio only captures the sound.
7. The installer then shows this Mac's address and ports, for example:

   ```
   Address:        192.168.1.23 (en0)
   Picture port:   5900 (macOS Screen Sharing)
   Sound port:     5910 (Quest VNC Audio)
   ```

## Connect from the headset

In Quest VNC, add this Mac with the address shown, or use **Scan**, then enter the password.
If you chose a sound port other than 5910, open the Mac's **Edit** screen and set **Audio port** to that number.
If you moved the picture port, set **Port** too. The app uses the same password for sound unless you set a separate **Audio password**.

Keep the Mac awake and logged in while you use it.

## Check or remove

* **Check:** in Terminal, run `bash install.sh --check` from this folder. It tests Screen Sharing with the saved password and shows whether the sound helper is capturing.
* **Uninstall:** right-click **Uninstall Quest VNC.command** and choose **Open**, or run `bash install.sh --uninstall`.
  This removes Quest VNC Audio, its login item, password file and log.
  It leaves Screen Sharing on, because other apps may use it. Turn it off in System Settings > General > Sharing.
* **Reinstall or change the port or password:** run the installer again.

## Troubleshooting

* **No sound:** run `--check`. Make sure Quest VNC Audio is switched on in Screen & System Audio Recording.
  Each time the installer rebuilds the helper, macOS treats it as a new app, so you may need to allow it again.
* **macOS 15 Sequoia** asks again about once a month whether Quest VNC Audio may keep recording. Choose **Allow** to keep the sound.
* **Wrong password in the headset:** use the same password in System Settings (Screen Sharing > (i)) and in Quest VNC.
* **Can't connect at all:** the headset and Mac must be on the same network. If the macOS firewall is on, the installer adds Quest VNC Audio to it.
  Screen Sharing is allowed automatically.
* **Slow or laggy picture:** macOS only sends uncompressed or ZRLE pictures to viewers that aren't Apple's.
  Use 5 GHz Wi-Fi or Ethernet, keep the headset close to the router, or lower the Mac's display resolution.
  At the end, the installer shows the format your Mac uses.
* **Log file:** `~/Library/Logs/Quest VNC Audio.log`.

## Security

The VNC password is the old VNC kind: it uses only 8 characters, and the picture isn't encrypted.
Use it only on your home network, and don't forward port 5900 or 5910 on your router.
The sound password is stored in `~/Library/Application Support/Quest VNC/audio-password`, readable only by your account.
While the installer stores the VNC password in macOS, it is briefly visible to other accounts on this Mac through the process list.
If you share the Mac with other people, answer **No** to that question and type the password in System Settings yourself.

## What the installer changes

| What | Where |
|---|---|
| Sound helper app | `~/Applications/Quest VNC Audio.app` (built on your Mac, ad-hoc signed) |
| Start at login | `~/Library/LaunchAgents/com.questvnc.audio.plist` |
| Password, settings, checker | `~/Library/Application Support/Quest VNC/` |
| Log | `~/Library/Logs/Quest VNC Audio.log` |
| Screen Sharing VNC password | System Settings (you set it, or the installer stores it with Apple's `kickstart` tool) |
| Picture port, only if you changed it | `/etc/services` (a backup is kept as `/etc/services.questvnc-backup`) |
