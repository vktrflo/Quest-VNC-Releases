// Quest VNC Audio Sender for macOS (13 Ventura or later).
//
// Streams whatever the Mac is playing to the Quest VNC app, using ScreenCaptureKit's system-audio
// capture, so no extra audio driver is needed. macOS asks for Screen Recording permission the first
// time (System Settings > Privacy & Security > Screen & System Audio Recording): allow it for the
// app you run this from (e.g. Terminal), then run it again.
//
// Run:   swift QuestVncAudio.swift [--port 5910] [--password SECRET | --password-file FILE] [--test-tone]
// Build: swiftc -O QuestVncAudio.swift -o QuestVncAudio
// (needs the Xcode Command Line Tools: xcode-select --install)
//
// Same protocol as the Windows and Linux senders (big-endian integers):
//   server -> client  "QVAUDIO1", authRequired (1 byte), challenge (16 bytes)
//   client -> server  HMAC-SHA256(password, challenge) (32 bytes)
//   server -> client  result (1 byte, 0 = ok), then sampleRate (4), channels (1), bits (1)
//   server -> client  chunks: length (4) + interleaved s16le PCM; length 0 = keep-alive

import AVFoundation
import CoreMedia
import CryptoKit
import Foundation
import Network
import ScreenCaptureKit

let sampleRate = 48000
let channelCount = 2
let maxPendingChunks = 25 // ~250 ms; older audio is dropped to stay live

// MARK: - Arguments

// stdout is a log file when run as a LaunchAgent: flush every line so the log is readable live.
setvbuf(stdout, nil, _IOLBF, 0)

let usage = "Usage: QuestVncAudio [--port 5910] [--password SECRET | --password-file FILE] [--test-tone]"
var port: UInt16 = 5910
var password: Data? = nil
var testTone = false
do {
    var args = CommandLine.arguments.dropFirst().makeIterator()
    while let a = args.next() {
        switch a {
        case "--port":
            guard let p = UInt16(args.next() ?? ""), p > 0 else { print("--port needs a number from 1 to 65535"); exit(1) }
            port = p
        case "--password": password = (args.next() ?? "").data(using: .utf8)
        case "--password-file":
            // The whole file is the password, minus one trailing newline. Keeps it out of `ps` and launchd plists.
            let path = args.next() ?? ""
            guard var text = try? String(contentsOfFile: path, encoding: .utf8) else {
                print("Can't read the password file '\(path)'"); exit(1)
            }
            // ("\r\n" is a single Character in Swift, so one removeLast() covers both endings.)
            if text.hasSuffix("\n") || text.hasSuffix("\r\n") { text.removeLast() }
            password = text.isEmpty ? nil : Data(text.utf8)
        case "--test-tone": testTone = true
        default:
            print(usage)
            exit(1)
        }
    }
}

func be32(_ v: Int) -> Data { Data([UInt8(truncatingIfNeeded: v >> 24), UInt8(truncatingIfNeeded: v >> 16),
                                    UInt8(truncatingIfNeeded: v >> 8), UInt8(truncatingIfNeeded: v)]) }

// MARK: - Clients

final class Client {
    let conn: NWConnection
    private let queue = DispatchQueue(label: "client")
    private var pending = 0
    private(set) var ready = false
    var lastSend = Date()
    var onClose: (() -> Void)?

    init(_ c: NWConnection) { conn = c }

    func start() {
        conn.stateUpdateHandler = { [weak self] state in
            switch state {
            case .failed, .cancelled: self?.onClose?()
            default: break
            }
        }
        conn.start(queue: queue)
        var hello = Data("QVAUDIO1".utf8)
        hello.append(password == nil ? 0 : 1)
        var challenge = Data(count: 16)
        _ = challenge.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 16, $0.baseAddress!) }
        hello.append(challenge)
        conn.send(content: hello, completion: .contentProcessed { _ in })
        conn.receive(minimumIncompleteLength: 32, maximumLength: 32) { [weak self] data, _, _, error in
            guard let self = self, let answer = data, answer.count == 32, error == nil else { self?.conn.cancel(); return }
            if let pw = password {
                let expected = Data(HMAC<SHA256>.authenticationCode(for: challenge, using: SymmetricKey(data: pw)))
                if expected != answer {
                    print("\(self.conn.endpoint): wrong password")
                    self.conn.send(content: Data([1]), completion: .contentProcessed { _ in self.conn.cancel() })
                    return
                }
            }
            var ok = Data([0])
            ok.append(be32(sampleRate))
            ok.append(UInt8(channelCount))
            ok.append(16)
            self.conn.send(content: ok, completion: .contentProcessed { _ in })
            self.queue.async { self.ready = true }
            print("\(self.conn.endpoint): listening")
        }
    }

    /// Sends one chunk, dropping it if the client is already too far behind.
    func send(_ pcm: Data) {
        queue.async {
            guard self.ready, self.pending < maxPendingChunks else { return }
            self.pending += 1
            var msg = be32(pcm.count)
            msg.append(pcm)
            self.lastSend = Date()
            self.conn.send(content: msg, completion: .contentProcessed { _ in
                self.queue.async { self.pending -= 1 }
            })
        }
    }
}

final class Server {
    private var clients: [ObjectIdentifier: Client] = [:]
    private let lock = NSLock()
    private var listener: NWListener!

    func start() throws {
        let params = NWParameters.tcp
        (params.defaultProtocolStack.transportProtocol as? NWProtocolTCP.Options)?.noDelay = true
        listener = try NWListener(using: params, on: NWEndpoint.Port(rawValue: port)!)
        listener.newConnectionHandler = { [weak self] conn in
            guard let self = self else { return }
            let c = Client(conn)
            let id = ObjectIdentifier(c)
            c.onClose = { [weak self] in
                self?.lock.lock(); self?.clients[id] = nil; self?.lock.unlock()
            }
            self.lock.lock(); self.clients[id] = c; self.lock.unlock()
            c.start()
        }
        listener.stateUpdateHandler = { state in
            if case .failed(let e) = state { print("Listener failed: \(e)"); exit(1) }
        }
        listener.start(queue: .global())
        // Keep-alive during silence (macOS sends no audio buffers while nothing plays).
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            self.lock.lock(); let all = Array(self.clients.values); self.lock.unlock()
            for c in all where Date().timeIntervalSince(c.lastSend) > 1.0 { c.send(Data()) }
        }
    }

    func broadcast(_ pcm: Data) {
        lock.lock(); let all = Array(clients.values); lock.unlock()
        for c in all { c.send(pcm) }
    }
}

let server = Server()

// MARK: - System audio capture (ScreenCaptureKit)

final class AudioCapture: NSObject, SCStreamOutput, SCStreamDelegate {
    private var stream: SCStream?
    private let queue = DispatchQueue(label: "audio")

    func start() {
        SCShareableContent.getExcludingDesktopWindows(false, onScreenWindowsOnly: true) { content, error in
            guard let display = content?.displays.first else {
                print("Can't capture: \(error?.localizedDescription ?? "no display")")
                print("Allow Screen & System Audio Recording for this app in System Settings > Privacy & Security, then run again.")
                exit(1)
            }
            let filter = SCContentFilter(display: display, excludingApplications: [], exceptingWindows: [])
            let config = SCStreamConfiguration()
            config.capturesAudio = true
            config.sampleRate = sampleRate
            config.channelCount = channelCount
            config.excludesCurrentProcessAudio = true
            // We only want sound; keep the video side as small and slow as possible.
            config.width = 2
            config.height = 2
            config.minimumFrameInterval = CMTime(value: 1, timescale: 1)
            let s = SCStream(filter: filter, configuration: config, delegate: self)
            do {
                try s.addStreamOutput(self, type: .audio, sampleHandlerQueue: self.queue)
                try s.addStreamOutput(self, type: .screen, sampleHandlerQueue: self.queue)
            } catch {
                print("Can't start capture: \(error)"); exit(1)
            }
            s.startCapture { err in
                if let err = err {
                    print("Can't start capture: \(err.localizedDescription)")
                    print("Allow Screen & System Audio Recording for this app in System Settings > Privacy & Security, then run again.")
                    exit(1)
                }
                print("Capturing system audio")
            }
            self.stream = s
        }
    }

    func stream(_ stream: SCStream, didOutputSampleBuffer sb: CMSampleBuffer, of type: SCStreamOutputType) {
        guard type == .audio, sb.isValid, let pcm = Self.toPcm16(sb) else { return }
        server.broadcast(pcm)
    }

    func stream(_ stream: SCStream, didStopWithError error: Error) {
        print("Capture stopped: \(error.localizedDescription)"); exit(1)
    }

    /// Converts ScreenCaptureKit audio (32-bit float, usually one buffer per channel) to interleaved s16le.
    static func toPcm16(_ sb: CMSampleBuffer) -> Data? {
        guard let fmtDesc = sb.formatDescription,
              let asbd = CMAudioFormatDescriptionGetStreamBasicDescription(fmtDesc)?.pointee else { return nil }
        var blockBuffer: CMBlockBuffer?
        var sizeNeeded = 0
        CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sb, bufferListSizeNeededOut: &sizeNeeded,
            bufferListOut: nil, bufferListSize: 0, blockBufferAllocator: nil, blockBufferMemoryAllocator: nil,
            flags: 0, blockBufferOut: nil)
        let abl = UnsafeMutableRawPointer.allocate(byteCount: sizeNeeded, alignment: 16)
        defer { abl.deallocate() }
        let listPtr = abl.bindMemory(to: AudioBufferList.self, capacity: 1)
        guard CMSampleBufferGetAudioBufferListWithRetainedBlockBuffer(sb, bufferListSizeNeededOut: nil,
            bufferListOut: listPtr, bufferListSize: sizeNeeded, blockBufferAllocator: nil,
            blockBufferMemoryAllocator: nil, flags: kCMSampleBufferFlag_AudioBufferList_Assure16ByteAlignment,
            blockBufferOut: &blockBuffer) == noErr else { return nil }

        let buffers = UnsafeMutableAudioBufferListPointer(listPtr)
        let isFloat = asbd.mFormatFlags & kAudioFormatFlagIsFloat != 0
        let nonInterleaved = asbd.mFormatFlags & kAudioFormatFlagIsNonInterleaved != 0
        let srcChannels = Int(asbd.mChannelsPerFrame)
        guard isFloat, asbd.mBitsPerChannel == 32, srcChannels > 0 else { return nil }
        let frames = CMSampleBufferGetNumSamples(sb)

        func sample(_ frame: Int, _ ch: Int) -> Float {
            let c = min(ch, srcChannels - 1)
            if nonInterleaved {
                guard c < buffers.count, let p = buffers[c].mData else { return 0 }
                return p.assumingMemoryBound(to: Float.self)[frame]
            } else {
                guard let p = buffers[0].mData else { return 0 }
                return p.assumingMemoryBound(to: Float.self)[frame * srcChannels + c]
            }
        }

        var out = Data(count: frames * channelCount * 2)
        out.withUnsafeMutableBytes { raw in
            let dst = raw.bindMemory(to: Int16.self)
            for f in 0..<frames {
                for ch in 0..<channelCount {
                    let v = max(-1, min(1, sample(f, ch)))
                    dst[f * channelCount + ch] = Int16(v * 32767).littleEndian
                }
            }
        }
        return out
    }
}

func startTestTone() {
    print("TEST TONE: 440 Hz beep every second")
    var frame = 0
    Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { _ in
        let frames = sampleRate / 100
        var out = Data(count: frames * channelCount * 2)
        out.withUnsafeMutableBytes { raw in
            let dst = raw.bindMemory(to: Int16.self)
            for i in 0..<frames {
                let on = frame % sampleRate < sampleRate / 4
                let v = on ? Int16(sin(2 * Double.pi * 440 * Double(frame) / Double(sampleRate)) * 6000) : 0
                dst[i * 2] = v.littleEndian
                dst[i * 2 + 1] = v.littleEndian
                frame += 1
            }
        }
        server.broadcast(out)
    }
}

// MARK: - Main

do {
    try server.start()
} catch {
    print("Can't listen on port \(port): \(error)")
    exit(1)
}
print("Listening on port \(port)" + (password == nil ? " (no password set: anyone on your network can listen)" : " (password required)"))
print("  This Mac: \(ProcessInfo.processInfo.hostName)")
print("Leave this running while you use Quest VNC. Press Ctrl+C to stop.")

let capture = AudioCapture()
if testTone { startTestTone() } else { capture.start() }
RunLoop.main.run()
