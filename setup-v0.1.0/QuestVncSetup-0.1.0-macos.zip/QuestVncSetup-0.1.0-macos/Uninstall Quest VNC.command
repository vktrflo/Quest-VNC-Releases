#!/bin/bash
# Right-click this file and choose Open. Removes Quest VNC Audio and its login item.
cd "$(dirname "$0")" || exit 1
/bin/bash ./install.sh --uninstall
echo
read -r -p "Press Return to close this window. " _
