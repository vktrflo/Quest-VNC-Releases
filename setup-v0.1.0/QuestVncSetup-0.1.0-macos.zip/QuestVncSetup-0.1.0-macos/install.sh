#!/bin/bash
# Quest VNC setup for macOS 13 (Ventura) or later.
#
# Sets up the two things the Quest VNC headset app connects to:
#   * the picture: macOS's own Screen Sharing VNC server, with a VNC password
#   * the sound:   the Quest VNC Audio sender, built here and installed as
#                  ~/Applications/Quest VNC Audio.app, started at login by a LaunchAgent
#
# Usage: install.sh [--uninstall | --check | --help]
# Written for the bash 3.2 that ships with macOS.

set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
LABEL="com.questvnc.audio"
APP_NAME="Quest VNC Audio"
APP="$HOME/Applications/$APP_NAME.app"
BIN="$APP/Contents/MacOS/QuestVncAudio"
AGENT="$HOME/Library/LaunchAgents/$LABEL.plist"
SUPPORT="$HOME/Library/Application Support/Quest VNC"
PWFILE="$SUPPORT/audio-password"
CHECKER="$SUPPORT/vnc-check"
SETTINGS="$SUPPORT/settings"
LOG="$HOME/Library/Logs/$APP_NAME.log"
DEFAULT_SOUND_PORT=5910
KICKSTART=/System/Library/CoreServices/RemoteManagement/ARDAgent.app/Contents/Resources/kickstart
FIREWALL=/usr/libexec/ApplicationFirewall/socketfilterfw
SERVICES_BACKUP=/etc/services.questvnc-backup
# System Settings deep links (macOS 13-15). An unknown anchor still opens the right pane.
SHARING_URL="x-apple.systempreferences:com.apple.preferences.sharing?Services_ScreenSharing"
SHARING_URL_FALLBACK="x-apple.systempreferences:com.apple.Sharing-Settings.extension"
PRIVACY_URL="x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"

WORK=""
SUDO_READY=""

# ------------------------------------------------------------------ helpers

bold() { printf '\033[1m%s\033[0m\n' "$*"; }
say() { printf '%s\n' "$*"; }
warn() { printf '\033[33m! %s\033[0m\n' "$*"; }
good() { printf '\033[32m✓ %s\033[0m\n' "$*"; }
die() { printf '\033[31mx %s\033[0m\n' "$*" >&2; exit 1; }
step() { printf '\n\033[1;34m== %s\033[0m\n' "$*"; }
pause() { read -r -p "${1:-Press Return to continue.} " _; }

cleanup() { [ -n "$WORK" ] && rm -rf "$WORK"; }
trap cleanup EXIT

# ask_yes "Question" Y|N  -> returns 0 for yes
ask_yes() {
  local def="$2" hint ans
  if [ "$def" = Y ]; then hint="[Y/n]"; else hint="[y/N]"; fi
  while true; do
    read -r -p "$1 $hint " ans
    [ -z "$ans" ] && ans="$def"
    case "$ans" in
      [Yy]*) return 0 ;;
      [Nn]*) return 1 ;;
    esac
  done
}

need_sudo() {
  [ -n "$SUDO_READY" ] && return 0
  say "macOS will ask for your Mac login password (you must be an administrator). $1"
  if sudo -v; then SUDO_READY=1; return 0; fi
  warn "No administrator access, skipping that part."
  return 1
}

valid_port() {
  [[ "$1" =~ ^[0-9]+$ ]] && [ "$1" -ge 1024 ] && [ "$1" -le 65535 ]
}

# Something is listening on this TCP port (lsof sees only our own processes without sudo, so also try to connect).
port_in_use() {
  lsof -nP -iTCP:"$1" -sTCP:LISTEN >/dev/null 2>&1 || nc -z -G 2 127.0.0.1 "$1" >/dev/null 2>&1
}

xml_escape() {
  local s="$1"
  s="${s//&/&amp;}"; s="${s//</&lt;}"; s="${s//>/&gt;}"
  printf '%s' "$s"
}

open_url() { open "$1" >/dev/null 2>&1 || { [ -n "${2:-}" ] && open "$2" >/dev/null 2>&1; }; }

# Port macOS Screen Sharing uses: launchd takes it from the "rfb"/"vnc-server" line of /etc/services.
screen_sharing_port() {
  local p
  p="$(awk '$1 == "rfb" && $2 ~ /\/tcp$/ { split($2, a, "/"); print a[1]; exit }' /etc/services 2>/dev/null)"
  if valid_port "${p:-x}"; then echo "$p"; else echo 5900; fi
}

lan_addresses() {
  ifconfig 2>/dev/null | awk '
    /^[a-z]/ { iface = $1; sub(":", "", iface) }
    /inet / && $2 != "127.0.0.1" && $2 !~ /^169\.254\./ { print $2 " (" iface ")" }'
}

agent_loaded() { launchctl print "gui/$(id -u)/$LABEL" >/dev/null 2>&1; }

stop_agent() {
  if agent_loaded; then launchctl bootout "gui/$(id -u)/$LABEL" >/dev/null 2>&1 || true; sleep 1; fi
}

start_agent() {
  : > "$LOG"
  launchctl bootstrap "gui/$(id -u)" "$AGENT" 2>/dev/null || launchctl load -w "$AGENT"
}

restart_agent() {
  : > "$LOG"
  launchctl kickstart -k "gui/$(id -u)/$LABEL" >/dev/null 2>&1 || { stop_agent; start_agent; }
}

# 0 = capturing, 1 = capture refused (permission), 2 = not sure yet
wait_for_capture() {
  for _ in $(seq 1 15); do
    grep -q "Capturing system audio" "$LOG" 2>/dev/null && return 0
    grep -q "Can't capture\|Can't start capture" "$LOG" 2>/dev/null && return 1
    sleep 1
  done
  return 2
}

# Runs the VNC checker; prints its lines indented; returns its exit code (see vnc-check.swift).
CHECK_OUT=""
vnc_check() {
  local rc
  CHECK_OUT="$(printf '%s\n' "${PASSWORD:-}" | "$CHECKER" 127.0.0.1 "$VNC_PORT" "$@" 2>&1)"
  rc=$?
  return $rc
}

check_value() { printf '%s\n' "$CHECK_OUT" | sed -n "s/^$1: //p" | head -n 1; }

# ------------------------------------------------------------------ uninstall / check

uninstall() {
  bold "Removing Quest VNC from this Mac"
  stop_agent
  rm -f "$AGENT"
  rm -rf "$APP" "$SUPPORT"
  rm -f "$LOG"
  tccutil reset ScreenCapture "$LABEL" >/dev/null 2>&1 || true
  good "Removed $APP_NAME, its login item, password file and log."

  if [ -f "$SERVICES_BACKUP" ] && [ "$(screen_sharing_port)" != 5900 ]; then
    if ask_yes "Screen Sharing was moved to port $(screen_sharing_port). Put it back on 5900?" Y && need_sudo "(to edit /etc/services)"; then
      sudo sed -i '' -E 's/^(rfb[[:space:]]+)[0-9]+\/(tcp|udp)/\15900\/\2/' /etc/services && sudo rm -f "$SERVICES_BACKUP"
      good "Port set back to 5900. Turn Screen Sharing off and on again for it to take effect."
    fi
  fi
  say ""
  say "Screen Sharing itself is still on (other apps may use it)."
  if ask_yes "Open System Settings to turn Screen Sharing off?" N; then
    open_url "$SHARING_URL" "$SHARING_URL_FALLBACK"
    say "Turn off Screen Sharing (General > Sharing)."
  fi
}

load_settings() {
  SOUND_PORT="$DEFAULT_SOUND_PORT"
  # shellcheck disable=SC1090
  [ -f "$SETTINGS" ] && . "$SETTINGS"
  VNC_PORT="$(screen_sharing_port)"
}

check_only() {
  load_settings
  bold "Quest VNC status on this Mac"
  if [ -x "$CHECKER" ]; then
    PASSWORD="$(cat "$PWFILE" 2>/dev/null)"
    vnc_check
    case $? in
      0) good "Screen Sharing answers on port $VNC_PORT and accepts the saved password." ;;
      2) warn "Nothing answers on port $VNC_PORT: Screen Sharing is off." ;;
      3) warn "Screen Sharing is on, but \"VNC viewers may control screen with password\" is off." ;;
      4) warn "Screen Sharing's VNC password differs from the one saved by the installer." ;;
      *) warn "Screen Sharing check: $(check_value result)" ;;
    esac
  else
    warn "Not installed (run the installer)."
  fi
  if agent_loaded && grep -q "Capturing system audio" "$LOG" 2>/dev/null; then
    good "$APP_NAME is running and capturing sound (port $SOUND_PORT)."
  elif agent_loaded; then
    warn "$APP_NAME is loaded but not capturing. Last log lines:"; tail -n 5 "$LOG" 2>/dev/null
  else
    warn "$APP_NAME is not running."
  fi
}

# ------------------------------------------------------------------ install steps

preflight() {
  [ "$(uname -s)" = Darwin ] || die "This installer is for macOS."
  [ "$(id -u)" -ne 0 ] || die "Run this as yourself, not with sudo (the sound sender runs in your login session)."
  local major
  major="$(sw_vers -productVersion | cut -d. -f1)"
  [ "${major:-0}" -ge 13 ] || die "macOS 13 Ventura or later is needed (this Mac has $(sw_vers -productVersion))."
  SRC=""
  for f in "$HERE/QuestVncAudio.swift" "$HERE/../../audio-sender/macos/QuestVncAudio.swift"; do
    [ -f "$f" ] && { SRC="$f"; break; }
  done
  [ -n "$SRC" ] || die "Can't find QuestVncAudio.swift (keep the installer folder as it was unzipped)."
  [ -f "$HERE/vnc-check.swift" ] || die "Can't find vnc-check.swift next to the installer."
}

ask_sound_port() {
  step "1. Sound port"
  say "Quest VNC Audio sends this Mac's sound to the headset on its own TCP port."
  local ans
  while true; do
    read -r -p "Sound port [$DEFAULT_SOUND_PORT]: " ans
    ans="${ans:-$DEFAULT_SOUND_PORT}"
    if ! valid_port "$ans"; then warn "Enter a number from 1024 to 65535."; continue; fi
    if [ "$ans" = "$(screen_sharing_port)" ]; then warn "That's the picture (VNC) port. Pick another."; continue; fi
    if port_in_use "$ans"; then
      warn "Something on this Mac already uses port $ans:"
      lsof -nP -iTCP:"$ans" -sTCP:LISTEN 2>/dev/null | sed -n '2,3p'
      continue
    fi
    SOUND_PORT="$ans"; break
  done
  good "Sound port: $SOUND_PORT"
}

ask_vnc_port() {
  step "2. Picture (VNC) port"
  local current ans
  current="$(screen_sharing_port)"
  say "The picture comes from macOS's built-in Screen Sharing, which listens on port $current."
  say "Apple has no setting for this port. Keeping it is recommended. Changing it uses an unofficial"
  say "tweak (it edits /etc/services) that a macOS update can quietly undo."
  VNC_PORT="$current"
  NEW_VNC_PORT=""
  while true; do
    read -r -p "Picture port [$current]: " ans
    ans="${ans:-$current}"
    [ "$ans" = "$current" ] && break
    if ! valid_port "$ans"; then warn "Enter a number from 1024 to 65535."; continue; fi
    if [ "$ans" = "$SOUND_PORT" ]; then warn "That's the sound port. Pick another."; continue; fi
    if port_in_use "$ans"; then warn "Something on this Mac already uses port $ans."; continue; fi
    if ask_yes "Move Screen Sharing to port $ans? Other VNC viewers will need it too." N; then
      NEW_VNC_PORT="$ans"; VNC_PORT="$ans"
    fi
    break
  done
  good "Picture port: $VNC_PORT"
}

ask_password() {
  step "3. Password"
  say "Choose the password Quest VNC will use for this Mac (picture and sound)."
  say "VNC only uses the first 8 characters, so 8 or fewer is best. Typing is hidden."
  local p1 p2
  while true; do
    read -r -s -p "Password: " p1; echo
    if [ -z "$p1" ]; then warn "A password is required."; continue; fi
    read -r -s -p "Same password again: " p2; echo
    if [ "$p1" != "$p2" ]; then warn "They don't match. Try again."; continue; fi
    if printf '%s' "$p1" | LC_ALL=C grep -q '[^ -~]'; then
      warn "Use plain letters, digits and symbols: other characters may not match between macOS and the headset."
      ask_yes "Use it anyway?" N || continue
    fi
    if [ "${#p1}" -gt 8 ]; then
      warn "It's ${#p1} characters. The picture only checks the first 8; the sound checks all of them."
      warn "Type it the same way everywhere (System Settings and Quest VNC) and it will work."
      ask_yes "Keep it?" Y || continue
    fi
    PASSWORD="$p1"; break
  done
  good "Password set."
}

build() {
  step "4. Building Quest VNC Audio"
  while ! { xcode-select -p >/dev/null 2>&1 && xcrun --find swiftc >/dev/null 2>&1; }; do
    say "Building needs Apple's Command Line Tools (free, a few minutes to download)."
    xcode-select --install >/dev/null 2>&1 || true
    say "Click Install in the window that appears (not Get Xcode)."
    pause "When it says the software was installed, press Return."
  done
  WORK="$(mktemp -d "${TMPDIR:-/tmp}/questvnc.XXXXXX")" && [ -d "$WORK" ] || die "Can't create a temporary folder."
  say "Compiling (about a minute the first time)..."
  xcrun swiftc -O "$SRC" -o "$WORK/QuestVncAudio" || die "Build of QuestVncAudio.swift failed (see above)."
  xcrun swiftc -O "$HERE/vnc-check.swift" -o "$WORK/vnc-check" || die "Build of vnc-check.swift failed (see above)."
  good "Built."
}

install_app() {
  step "5. Installing $APP_NAME"
  stop_agent
  local replaced=""
  if [ -f "$BIN" ] && cmp -s "$WORK/QuestVncAudio" "$BIN"; then
    say "Same version already installed; keeping it (and its permission)."
  else
    [ -d "$APP" ] && replaced=1
    rm -rf "$APP"
    mkdir -p "$APP/Contents/MacOS" || die "Can't create $APP"
    cp "$WORK/QuestVncAudio" "$BIN"
    cat > "$APP/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleIdentifier</key><string>$LABEL</string>
  <key>CFBundleName</key><string>$APP_NAME</string>
  <key>CFBundleDisplayName</key><string>$APP_NAME</string>
  <key>CFBundleExecutable</key><string>QuestVncAudio</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>CFBundleVersion</key><string>1</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>LSUIElement</key><true/>
  <key>NSHumanReadableCopyright</key><string>Sends this Mac's sound to the Quest VNC headset app.</string>
</dict>
</plist>
EOF
    # Ad-hoc signature: gives the app a stable identity so the permission prompt and list name it.
    codesign --force --sign - --identifier "$LABEL" "$APP" || die "codesign failed"
    # A rebuilt app has a new signature, so an old permission entry would no longer match it.
    [ -n "$replaced" ] && tccutil reset ScreenCapture "$LABEL" >/dev/null 2>&1
  fi

  mkdir -p "$SUPPORT" && chmod 700 "$SUPPORT"
  ( umask 077; printf '%s' "$PASSWORD" > "$PWFILE" ) || die "Can't write $PWFILE"
  chmod 600 "$PWFILE"
  cp "$WORK/vnc-check" "$CHECKER"
  printf 'SOUND_PORT=%s\n' "$SOUND_PORT" > "$SETTINGS"
  mkdir -p "$(dirname "$AGENT")" "$(dirname "$LOG")"

  cat > "$AGENT" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>$(xml_escape "$BIN")</string>
    <string>--port</string><string>$SOUND_PORT</string>
    <string>--password-file</string><string>$(xml_escape "$PWFILE")</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ThrottleInterval</key><integer>10</integer>
  <key>ProcessType</key><string>Interactive</string>
  <key>LimitLoadToSessionType</key><string>Aqua</string>
  <key>StandardOutPath</key><string>$(xml_escape "$LOG")</string>
  <key>StandardErrorPath</key><string>$(xml_escape "$LOG")</string>
</dict>
</plist>
EOF
  plutil -lint "$AGENT" >/dev/null || die "The LaunchAgent file is invalid: $AGENT"
  good "Installed $APP, starting at login."

  if "$FIREWALL" --getglobalstate 2>/dev/null | grep -qi enabled; then
    say "The macOS firewall is on: allowing $APP_NAME to accept connections."
    if need_sudo "(to add $APP_NAME to the firewall)"; then
      sudo "$FIREWALL" --add "$BIN" >/dev/null && sudo "$FIREWALL" --unblockapp "$BIN" >/dev/null && good "Firewall allows $APP_NAME."
    fi
  fi
}

set_vnc_port() {
  [ -z "$NEW_VNC_PORT" ] && return 0
  need_sudo "(to move Screen Sharing to port $NEW_VNC_PORT in /etc/services)" || { VNC_PORT="$(screen_sharing_port)"; return 0; }
  [ -f "$SERVICES_BACKUP" ] || sudo cp /etc/services "$SERVICES_BACKUP"
  if sudo sed -i '' -E "s/^(rfb[[:space:]]+)[0-9]+\/(tcp|udp)/\1$NEW_VNC_PORT\/\2/" /etc/services \
     && [ "$(screen_sharing_port)" = "$NEW_VNC_PORT" ]; then
    good "Screen Sharing will use port $NEW_VNC_PORT once it is turned off and on again (next step)."
  else
    warn "Couldn't change the port; keeping $(screen_sharing_port)."
    VNC_PORT="$(screen_sharing_port)"; NEW_VNC_PORT=""
  fi
}

screen_sharing_steps() {
  say ""
  bold "In the System Settings window that just opened (General > Sharing):"
  say "  1. If Remote Management is on, turn it off (it can't be on together with Screen Sharing)."
  if [ -n "$NEW_VNC_PORT" ]; then
    say "  2. Turn Screen Sharing OFF, wait a moment, then turn it ON again (this applies the new port)."
  else
    say "  2. Turn on Screen Sharing."
  fi
  say "  3. Click the (i) button next to Screen Sharing."
  say "  4. Turn on \"VNC viewers may control screen with password\"."
  say "     Type the same password you chose here, and click OK."
  say "  5. Click Done."
  say ""
}

setup_screen_sharing() {
  step "6. Screen Sharing (the picture)"
  set_vnc_port
  vnc_check
  local rc=$?
  if [ $rc -eq 0 ] && [ -z "$NEW_VNC_PORT" ]; then
    good "Screen Sharing is on and already accepts this password."
    return 0
  fi

  # Since macOS 12.1 a script can't switch Screen Sharing on (Apple allows that only by hand or MDM),
  # but kickstart may still be able to store the VNC password, leaving only the switch for you.
  if [ -x "$KICKSTART" ] && ask_yes "Let the installer store the VNC password in macOS for you? (needs admin; you'll still flip the switch)" Y \
     && need_sudo "(to set Screen Sharing's VNC password)"; then
    # kickstart only takes the password as an argument, so it is visible to `ps` for that moment.
    sudo "$KICKSTART" -configure -clientopts -setvnclegacy -vnclegacy yes -setvncpw -vncpw "$PASSWORD" >/dev/null 2>&1 \
      && say "Stored. (Some macOS versions ignore this; the steps below cover it either way.)"
    vnc_check; rc=$?
    if [ $rc -eq 0 ] && [ -z "$NEW_VNC_PORT" ]; then good "Screen Sharing is on and accepts the password."; return 0; fi
  fi

  while true; do
    open_url "$SHARING_URL" "$SHARING_URL_FALLBACK"
    screen_sharing_steps
    pause "Press Return when you've done this."
    vnc_check; rc=$?
    case $rc in
      0) good "Screen Sharing is on (port $VNC_PORT) and accepts the password."; return 0 ;;
      2) warn "Nothing answers on port $VNC_PORT yet: Screen Sharing looks off${NEW_VNC_PORT:+ (or still on the old port: switch it off and on)}." ;;
      3) warn "Screen Sharing is on, but \"VNC viewers may control screen with password\" is off (step 4)." ;;
      4) warn "Screen Sharing has a different VNC password. Set it again in step 4 (click the (i) button)." ;;
      *) warn "Unexpected answer from Screen Sharing: $(check_value result)" ;;
    esac
    if ! ask_yes "Try again?" Y; then
      warn "Skipped. The headset can't show this Mac until this is done; run the installer again any time."
      return 1
    fi
  done
}

setup_sound_permission() {
  step "7. Permission to capture sound"
  say "macOS files system sound under \"Screen & System Audio Recording\". $APP_NAME only uses the sound."
  start_agent
  say "Starting $APP_NAME..."
  wait_for_capture; local rc=$?
  [ $rc -eq 0 ] && { good "$APP_NAME is capturing sound."; return 0; }
  while true; do
    open_url "$PRIVACY_URL"
    say ""
    bold "macOS may ask: \"$APP_NAME would like to record this computer's screen and audio\"."
    say "  1. If you see that, click Open System Settings (or Allow)."
    say "  2. In Privacy & Security > Screen & System Audio Recording, turn on $APP_NAME."
    say "     Not in the list? Click +, press Cmd+Shift+G, type ~/Applications, choose $APP_NAME."
    say "  3. If macOS offers to \"Quit & Reopen\", choose Later (the installer restarts it)."
    say ""
    pause "Press Return when $APP_NAME is turned on."
    restart_agent
    say "Restarting $APP_NAME..."
    wait_for_capture; rc=$?
    case $rc in
      0) good "$APP_NAME is capturing sound."; return 0 ;;
      1) warn "macOS still refuses capture. Check the switch for $APP_NAME is on." ;;
      *) warn "No answer from $APP_NAME yet. Log: $LOG"; tail -n 3 "$LOG" 2>/dev/null ;;
    esac
    if ! ask_yes "Try again?" Y; then
      warn "Skipped. The picture works without it, but there will be no sound until it's allowed."
      return 1
    fi
  done
}

report_picture() {
  # One real session the way the app connects: shows what the Mac will send the headset.
  vnc_check --probe || return 0
  local desk enc
  desk="$(check_value desktop)"
  # e.g. "ExtendedDesktopSize x1, LastRect x1, Tight x12" -> "Tight"
  enc="$(check_value encodings | tr ',' '\n' | sed 's/^ *//; s/ x[0-9]*$//' \
         | grep -v -e DesktopSize -e LastRect -e 'QEMU audio' | sort -u | tr '\n' ' ' | sed 's/ $//')"
  say "Screen as the headset will see it: ${desk%% *} (picture format: ${enc:-unknown})."
  case "$enc" in
    *Tight*) ;;
    *Raw*) warn "macOS sends this picture uncompressed to non-Apple viewers, so it needs a fast network (5 GHz Wi-Fi or Ethernet). Lowering the Mac's resolution helps." ;;
  esac
}

summary() {
  local hostname addrs
  hostname="$(scutil --get LocalHostName 2>/dev/null)"
  addrs="$(lan_addresses)"
  step "Done"
  if [ "$vnc_ok" -eq 0 ] && [ "$sound_ok" -eq 0 ]; then
    bold "This Mac is ready for Quest VNC."
  else
    [ "$vnc_ok" -eq 0 ] || warn "Screen Sharing isn't set up yet: the headset can't show this Mac until it is."
    [ "$sound_ok" -eq 0 ] || warn "$APP_NAME can't capture sound yet: allow it in Screen & System Audio Recording."
    say "Run the installer again to finish. Everything else is in place:"
  fi
  if [ -n "$addrs" ]; then
    say "  Address:        $(printf '%s\n' "$addrs" | head -n 1)"
    printf '%s\n' "$addrs" | sed -n '2,$p' | sed 's/^/                  /'
  else
    warn "  No network address found: connect this Mac to the same Wi-Fi/network as the headset."
  fi
  [ -n "$hostname" ] && say "  Name:           $hostname.local"
  say "  Picture port:   $VNC_PORT (macOS Screen Sharing)"
  say "  Sound port:     $SOUND_PORT ($APP_NAME)"
  say "  Password:       the one you chose (used for picture and sound)"
  say ""
  local extra=""
  [ "$VNC_PORT" != 5900 ] && extra="set Port to $VNC_PORT"
  if [ "$SOUND_PORT" != "$DEFAULT_SOUND_PORT" ]; then
    [ -n "$extra" ] && extra="$extra and "
    extra="${extra}set Audio port to $SOUND_PORT"
  fi
  if [ -n "$extra" ]; then
    bold "In Quest VNC, add this Mac (or use Scan), and in its Edit screen $extra."
  else
    bold "In Quest VNC, add this Mac (or use Scan) and enter the password."
  fi
  say ""
  say "Keep the Mac awake and logged in while you use it. To check later:   bash \"$HERE/install.sh\" --check"
  say "To remove the sound sender:   bash \"$HERE/install.sh\" --uninstall"
}

# ------------------------------------------------------------------ main

case "${1:-}" in
  --uninstall) [ "$(uname -s)" = Darwin ] || die "This is for macOS."; uninstall; exit 0 ;;
  --check) check_only; exit 0 ;;
  -h|--help) sed -n '2,11p' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
  "") ;;
  *) die "Unknown option $1 (use --uninstall, --check or --help)" ;;
esac

preflight
bold "Quest VNC setup for macOS"
say "This sets up Screen Sharing (the picture) and $APP_NAME (the sound) for the Quest VNC headset app."
stop_agent   # so a previous install doesn't hold the sound port
ask_sound_port
ask_vnc_port
ask_password
build
install_app
setup_screen_sharing; vnc_ok=$?
setup_sound_permission; sound_ok=$?
[ "$vnc_ok" -eq 0 ] && report_picture
summary
