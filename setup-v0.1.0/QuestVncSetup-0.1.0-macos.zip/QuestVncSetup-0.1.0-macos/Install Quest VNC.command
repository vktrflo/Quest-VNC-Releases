#!/bin/bash
# Right-click this file and choose Open (the first time; macOS blocks double-clicking downloaded scripts).
cd "$(dirname "$0")" || exit 1
/bin/bash ./install.sh
echo
read -r -p "Press Return to close this window. " _
