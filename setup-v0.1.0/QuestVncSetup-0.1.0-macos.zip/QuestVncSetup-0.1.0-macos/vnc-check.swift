// vnc-check: connects to a VNC server the way the Quest VNC app does, so the installer can verify
// macOS Screen Sharing before you put the headset on.
//
//   vnc-check HOST PORT [--probe]      (the VNC password, if any, is read from the first line of stdin)
//
// Prints "key: value" lines and exits with:
//   0  the server answered; with a password, it was accepted (with --probe, a picture update was read)
//   2  nothing is listening / can't connect
//   3  the server doesn't offer VNC password authentication (security type 2)
//   4  the password was rejected
//   5  anything else (protocol error, timeout, connection closed)
//
// --probe asks for the same pixel format and encodings as the app (Tight, CopyRect, Raw, DesktopSize,
// ExtendedDesktopSize, LastRect, QEMU audio) and reports which encoding the server answers with.
// Build: swiftc -O vnc-check.swift -o vnc-check   (works on macOS and Linux; no CommonCrypto needed)

#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif

setvbuf(stdout, nil, _IOLBF, 0)

struct Failure: Error { let code: Int32; let message: String }

// MARK: - Socket

final class Conn {
    let fd: Int32
    var received = 0

    init(host: String, port: String, timeoutSeconds: Int) throws {
        var hints = addrinfo()
        hints.ai_family = AF_UNSPEC
        #if canImport(Darwin)
        hints.ai_socktype = SOCK_STREAM
        #else
        hints.ai_socktype = Int32(SOCK_STREAM.rawValue)
        #endif
        var res: UnsafeMutablePointer<addrinfo>?
        guard getaddrinfo(host, port, &hints, &res) == 0, let first = res else {
            throw Failure(code: 2, message: "can't resolve \(host)")
        }
        defer { freeaddrinfo(res) }
        var ai: UnsafeMutablePointer<addrinfo>? = first
        var lastErr: Int32 = 0
        while let a = ai {
            let s = socket(a.pointee.ai_family, a.pointee.ai_socktype, a.pointee.ai_protocol)
            if s >= 0 {
                var tv = timeval(tv_sec: timeoutSeconds, tv_usec: 0)
                setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                setsockopt(s, SOL_SOCKET, SO_SNDTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                if connect(s, a.pointee.ai_addr, a.pointee.ai_addrlen) == 0 { fd = s; return }
                lastErr = errno
                close(s)
            }
            ai = a.pointee.ai_next
        }
        throw Failure(code: 2, message: "can't connect to \(host):\(port) (\(String(cString: strerror(lastErr))))")
    }

    deinit { close(fd) }

    func read(_ n: Int) throws -> [UInt8] {
        var buf = [UInt8](repeating: 0, count: n)
        var got = 0
        while got < n {
            let r = buf.withUnsafeMutableBytes { recv(fd, $0.baseAddress! + got, n - got, 0) }
            if r == 0 { throw Failure(code: 5, message: "the server closed the connection") }
            if r < 0 {
                if errno == EINTR { continue }
                throw Failure(code: 5, message: errno == EAGAIN || errno == EWOULDBLOCK ? "timed out waiting for the server"
                                                                                         : String(cString: strerror(errno)))
            }
            got += r
        }
        received += n
        return buf
    }

    func skip(_ n: Int) throws {
        var left = n
        while left > 0 { let c = min(left, 1 << 20); _ = try read(c); left -= c }
    }

    func u8() throws -> Int { Int(try read(1)[0]) }
    func u16() throws -> Int { let b = try read(2); return Int(b[0]) << 8 | Int(b[1]) }
    func u32() throws -> UInt32 { let b = try read(4); return UInt32(b[0]) << 24 | UInt32(b[1]) << 16 | UInt32(b[2]) << 8 | UInt32(b[3]) }
    func s32() throws -> Int { Int(Int32(bitPattern: try u32())) }

    func write(_ bytes: [UInt8]) throws {
        var sent = 0
        while sent < bytes.count {
            let r = bytes.withUnsafeBytes { send(fd, $0.baseAddress! + sent, bytes.count - sent, 0) }
            if r < 0 { if errno == EINTR { continue }; throw Failure(code: 5, message: "send failed: \(String(cString: strerror(errno)))") }
            sent += r
        }
    }
}

func be32(_ v: Int) -> [UInt8] { [UInt8(truncatingIfNeeded: v >> 24), UInt8(truncatingIfNeeded: v >> 16),
                                  UInt8(truncatingIfNeeded: v >> 8), UInt8(truncatingIfNeeded: v)] }

// MARK: - DES (only what VNC authentication needs: encrypt one 8-byte block)

enum DES {
    static let pc1: [Int] = [57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,
                             63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4]
    static let pc2: [Int] = [14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,
                             41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32]
    static let shifts: [Int] = [1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1]
    static let ip: [Int] = [58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8,
                            57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7]
    static let fp: [Int] = [40,8,48,16,56,24,64,32,39,7,47,15,55,23,63,31,38,6,46,14,54,22,62,30,37,5,45,13,53,21,61,29,
                            36,4,44,12,52,20,60,28,35,3,43,11,51,19,59,27,34,2,42,10,50,18,58,26,33,1,41,9,49,17,57,25]
    static let e: [Int] = [32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,15,16,17,
                           16,17,18,19,20,21,20,21,22,23,24,25,24,25,26,27,28,29,28,29,30,31,32,1]
    static let p: [Int] = [16,7,20,21,29,12,28,17,1,15,23,26,5,18,31,10,2,8,24,14,32,27,3,9,19,13,30,6,22,11,4,25]
    static let sbox: [[Int]] = [
        [14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7,0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8,
         4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0,15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13],
        [15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10,3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5,
         0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15,13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9],
        [10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8,13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1,
         13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7,1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12],
        [7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15,13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9,
         10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4,3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14],
        [2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9,14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6,
         4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14,11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3],
        [12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11,10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8,
         9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6,4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13],
        [4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1,13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6,
         1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2,6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12],
        [13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7,1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2,
         7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8,2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11]]

    /// Applies a 1-based bit permutation (bit 1 = most significant of `inBits`).
    static func permute(_ v: UInt64, _ table: [Int], _ inBits: Int) -> UInt64 {
        var out: UInt64 = 0
        for pos in table { out = out << 1 | (v >> UInt64(inBits - pos)) & 1 }
        return out
    }

    static func encrypt(key: [UInt8], block: [UInt8]) -> [UInt8] {
        let k = key.reduce(UInt64(0)) { $0 << 8 | UInt64($1) }
        var cd = permute(k, pc1, 64)
        var c = cd >> 28, d = cd & 0xFFFFFFF
        var subkeys: [UInt64] = []
        for s in shifts {
            c = (c << UInt64(s) | c >> UInt64(28 - s)) & 0xFFFFFFF
            d = (d << UInt64(s) | d >> UInt64(28 - s)) & 0xFFFFFFF
            cd = c << 28 | d
            subkeys.append(permute(cd, pc2, 56))
        }
        let v = permute(block.reduce(UInt64(0)) { $0 << 8 | UInt64($1) }, ip, 64)
        var l = v >> 32, r = v & 0xFFFFFFFF
        for sk in subkeys {
            let x = permute(r, e, 32) ^ sk
            var f: UInt64 = 0
            for i in 0..<8 {
                let six = Int((x >> UInt64(42 - 6 * i)) & 0x3F)
                let row = (six >> 4 & 2) | (six & 1), col = six >> 1 & 0xF
                f = f << 4 | UInt64(sbox[i][row * 16 + col])
            }
            (l, r) = (r, l ^ permute(f, p, 32))
        }
        let out = permute(r << 32 | l, fp, 64)
        return (0..<8).map { UInt8(truncatingIfNeeded: out >> UInt64(56 - 8 * $0)) }
    }

    /// VNC's quirk: each key byte is bit-reversed; only the first 8 password bytes count.
    static func vncResponse(password: String, challenge: [UInt8]) -> [UInt8] {
        var key = [UInt8](repeating: 0, count: 8)
        for (i, b) in Array(password.utf8.prefix(8)).enumerated() {
            var r: UInt8 = 0
            for bit in 0..<8 where b & (1 << bit) != 0 { r |= 0x80 >> bit }
            key[i] = r
        }
        return DES.encrypt(key: key, block: Array(challenge[0..<8])) + DES.encrypt(key: key, block: Array(challenge[8..<16]))
    }
}

// MARK: - RFB

let encodingNames: [Int: String] = [0: "Raw", 1: "CopyRect", 2: "RRE", 5: "Hextile", 6: "Zlib", 7: "Tight", 16: "ZRLE",
                                    -223: "DesktopSize", -224: "LastRect", -259: "QEMU audio", -308: "ExtendedDesktopSize"]
func encName(_ e: Int) -> String { encodingNames[e] ?? "unknown(\(e))" }

func compactLength(_ c: Conn) throws -> Int {
    var len = 0
    for i in 0..<3 {
        let b = try c.u8()
        len |= (i < 2 ? b & 0x7F : b) << (7 * i)
        if i < 2 && b & 0x80 == 0 { break }
    }
    return len
}

/// Skips one Tight rectangle for our 32bpp/depth-24 format (3-byte TPIXELs).
func skipTight(_ c: Conn, _ w: Int, _ h: Int) throws {
    let ctrl = try c.u8()
    let comp = ctrl >> 4
    if comp == 8 { try c.skip(3); return }                        // fill
    if comp == 9 { try c.skip(try compactLength(c)); return }     // JPEG
    if comp > 9 { throw Failure(code: 5, message: "bad Tight control byte \(ctrl)") }
    var size = w * h * 3
    if comp & 4 != 0 {
        switch try c.u8() {
        case 0: break
        case 1:
            let colours = try c.u8() + 1
            try c.skip(colours * 3)
            size = colours == 2 ? (w + 7) / 8 * h : w * h
        case 2: break
        case let f: throw Failure(code: 5, message: "bad Tight filter \(f)")
        }
    }
    if size < 12 { try c.skip(size) } else { try c.skip(try compactLength(c)) }
}

func run() throws -> Int32 {
    var args = Array(CommandLine.arguments.dropFirst())
    let probe = args.contains("--probe")
    args.removeAll { $0 == "--probe" }
    guard args.count == 2 else {
        print("usage: vnc-check HOST PORT [--probe]   (password on stdin)")
        return 5
    }
    let password = readLine(strippingNewline: true) ?? ""

    let c = try Conn(host: args[0], port: args[1], timeoutSeconds: 10)
    let version = String(decoding: try c.read(12), as: UTF8.self).trimmingCharacters(in: "\n")
    print("version: \(version)")
    guard version.hasPrefix("RFB "), version.count == 11,
          let minorRaw = Int(version.suffix(3)), let major = Int(version.dropFirst(4).prefix(3)) else {
        throw Failure(code: 5, message: "not a VNC server")
    }
    // Same choice as the app's RfbClient: Apple's 3.889 is answered as 3.8.
    let minor = (major > 3 || minorRaw >= 8) ? 8 : (minorRaw >= 7 ? 7 : 3)
    try c.write(Array(String(format3(minor)).utf8))

    var types: [Int]
    if minor == 3 {
        types = [Int(try c.u32())]
    } else {
        let n = try c.u8()
        if n == 0 { throw Failure(code: 5, message: "server refused: \(try reason(c))") }
        types = try c.read(n).map { Int($0) }
    }
    print("security: \(types.map(String.init).joined(separator: " "))")
    if types.contains(0) && minor == 3 { throw Failure(code: 5, message: "server refused: \(try reason(c))") }
    guard types.contains(2) else {
        print("result: no VNC password option (type 2) offered")
        return 3
    }
    if password.isEmpty {
        print("result: VNC password authentication is available")
        return 0
    }
    if minor != 3 { try c.write([2]) }
    let challenge = try c.read(16)
    try c.write(DES.vncResponse(password: password, challenge: challenge))
    let status = try c.u32()
    if status != 0 {
        let why = minor == 8 ? (try? reason(c)) ?? "" : ""
        print("result: password rejected\(why.isEmpty ? "" : " (\(why))")")
        return 4
    }
    print("auth: ok")
    if !probe { return 0 }

    try c.write([1]) // ClientInit, shared
    let width = try c.u16(), height = try c.u16()
    let pf = try c.read(16)
    let name = String(decoding: try c.read(Int(try c.u32())), as: UTF8.self)
    print("desktop: \(width)x\(height) \(pf[0])bpp \"\(name)\"")

    // Exactly what RfbClient sends: SetPixelFormat (32bpp LE, depth 24), then SetEncodings.
    try c.write([0, 0, 0, 0, 32, 24, 0, 1, 0, 255, 0, 255, 0, 255, 16, 8, 0, 0, 0, 0])
    let encs = [7, 1, 0, -223, -308, -224, -256 + 6, -32 + 6, -259] // Tight, CopyRect, Raw, sizes, LastRect, compress 6, JPEG quality 6, audio
    try c.write([2, 0, 0, UInt8(encs.count)] + encs.flatMap { be32($0) })
    let request: [UInt8] = [3, 0, 0, 0, 0, 0, UInt8(width >> 8), UInt8(width & 255), UInt8(height >> 8), UInt8(height & 255)]
    try c.write(request)

    let start = c.received
    var seen: [String: Int] = [:]
    var gotPixels = false
    var updates = 0
    while !gotPixels && updates < 5 {
        let type = try c.u8()
        switch type {
        case 0: break
        case 1: _ = try c.read(3); try c.skip(6 * (try c.u16())); continue
        case 2: continue
        case 3: _ = try c.read(3); try c.skip(Int(try c.u32())); continue
        default: throw Failure(code: 5, message: "unknown server message type \(type) (the app would disconnect)")
        }
        updates += 1
        _ = try c.u8()
        let rects = try c.u16()
        rectLoop: for _ in 0..<rects {
            _ = try c.u16(); _ = try c.u16()
            let w = try c.u16(), h = try c.u16()
            let enc = try c.s32()
            seen[encName(enc), default: 0] += 1
            switch enc {
            case 0: try c.skip(w * h * 4); gotPixels = true
            case 1: try c.skip(4); gotPixels = true
            case 7: try skipTight(c, w, h); gotPixels = true
            case 16: try c.skip(Int(try c.u32())); gotPixels = true
            case -223, -259: break
            case -224: break rectLoop
            case -308: let n = try c.u8(); try c.skip(3 + 16 * n)
            default:
                print("encodings: \(seen.map { "\($0.key) x\($0.value)" }.sorted().joined(separator: ", "))")
                throw Failure(code: 5, message: "server sent \(encName(enc)), which the app doesn't decode")
            }
        }
        // An update with only layout rectangles (e.g. ExtendedDesktopSize) answers the request: ask again,
        // incrementally (TigerVNC answers every full request with the layout first; the pixels are still owed).
        if !gotPixels { var again = request; again[1] = 1; try c.write(again) }
    }
    print("encodings: \(seen.map { "\($0.key) x\($0.value)" }.sorted().joined(separator: ", "))")
    guard gotPixels else { throw Failure(code: 5, message: "the server sent no picture") }
    print("first-update-bytes: \(c.received - start)")
    print("result: ok")
    return 0
}

func format3(_ minor: Int) -> String { "RFB 003.00\(minor)\n" }

func reason(_ c: Conn) throws -> String { String(decoding: try c.read(Int(try c.u32())), as: UTF8.self) }

extension String {
    func trimmingCharacters(in chars: String) -> String {
        var s = Substring(self)
        while let l = s.last, chars.contains(l) { s.removeLast() }
        return String(s)
    }
}

do {
    exit(try run())
} catch let f as Failure {
    print("result: \(f.message)")
    exit(f.code)
} catch {
    print("result: \(error)")
    exit(5)
}
