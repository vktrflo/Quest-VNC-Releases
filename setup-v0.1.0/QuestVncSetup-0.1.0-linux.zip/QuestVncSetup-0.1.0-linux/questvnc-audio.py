#!/usr/bin/env python3
"""Quest VNC Audio Sender for Linux.

Streams whatever the PC is playing to the Quest VNC app. Uses the monitor of the default
PulseAudio / PipeWire output (via `parec`, or `pw-record` on PipeWire-only systems).
Python 3 standard library only.

Usage: python3 questvnc-audio.py [--port 5910] [--password SECRET | --password-file FILE]
                                 [--sink NAME] [--test-tone]

--sink NAME makes a virtual output called NAME (a PulseAudio/PipeWire null sink, created with
pactl when missing) and sends only what plays on it, instead of the default output. Apps choose
it with PULSE_SINK=NAME; the Linux installer uses this for the Quest VNC virtual desktop.

Same protocol as the Windows sender (big-endian integers):
  server -> client  b"QVAUDIO1", auth_required (1 byte), challenge (16 bytes)
  client -> server  HMAC-SHA256(password, challenge) (32 bytes)
  server -> client  result (1 byte, 0 = ok), then sample_rate (4), channels (1), bits (1)
  server -> client  chunks: length (4) + interleaved s16le PCM; length 0 = keep-alive
"""

import argparse
import collections
import hmac
import hashlib
import math
import os
import shutil
import socket
import struct
import subprocess
import sys
import threading
import time

RATE, CHANNELS = 48000, 2
CHUNK_BYTES = RATE * CHANNELS * 2 // 100   # 10 ms
MAX_QUEUED = 25                            # ~250 ms; older audio is dropped to stay live

clients = []
clients_lock = threading.Lock()


class Client:
    def __init__(self, sock, addr):
        self.sock, self.addr = sock, addr
        self.queue = collections.deque()
        self.cond = threading.Condition()
        self.last_send = time.monotonic()
        self.alive = True

    def enqueue(self, data):
        with self.cond:
            while len(self.queue) > MAX_QUEUED:
                self.queue.popleft()
            self.queue.append(data)
            self.cond.notify()

    def send_loop(self):
        try:
            while self.alive:
                with self.cond:
                    while not self.queue:
                        self.cond.wait(1.0)
                        if not self.queue and time.monotonic() - self.last_send > 1.0:
                            self.queue.append(b"")  # keep-alive during silence
                    data = self.queue.popleft()
                self.sock.sendall(struct.pack(">I", len(data)) + data)
                self.last_send = time.monotonic()
        except OSError as e:
            print(f"{self.addr[0]}: {e}")
        finally:
            self.alive = False


def broadcast(data):
    with clients_lock:
        for c in clients:
            c.enqueue(data)


def handle(sock, addr, password):
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        sock.settimeout(10)
        challenge = os.urandom(16)
        sock.sendall(b"QVAUDIO1" + bytes([1 if password else 0]) + challenge)
        answer = b""
        while len(answer) < 32:
            part = sock.recv(32 - len(answer))
            if not part:
                return
            answer += part
        if password and not hmac.compare_digest(answer, hmac.new(password, challenge, hashlib.sha256).digest()):
            sock.sendall(b"\x01")
            print(f"{addr[0]}: wrong password")
            return
        sock.sendall(b"\x00" + struct.pack(">IBB", RATE, CHANNELS, 16))
        sock.settimeout(None)
        client = Client(sock, addr)
        with clients_lock:
            clients.append(client)
        print(f"{addr[0]}: listening")
        client.send_loop()
    except OSError as e:
        print(f"{addr[0]}: {e}")
    finally:
        with clients_lock:
            clients[:] = [c for c in clients if c.sock is not sock]
        sock.close()


def sink_exists(name):
    try:
        out = subprocess.run(["pactl", "list", "short", "sinks"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return out.returncode == 0 and any(line.split("\t")[1:2] == [name] for line in out.stdout.splitlines())


def ensure_sink(name, wait=0.0):
    """Creates the null sink `name` if it is missing. Retries for `wait` seconds while the
    sound server is starting. Returns True when the sink exists."""
    if not shutil.which("pactl"):
        print("pactl (pulseaudio-utils) is missing, so --sink cannot create its output.")
        return False
    deadline = time.monotonic() + wait
    while True:
        if sink_exists(name):
            return True
        try:
            subprocess.run(["pactl", "load-module", "module-null-sink", f"sink_name={name}",
                            f"rate={RATE}", f"channels={CHANNELS}",
                            "sink_properties=device.description=Quest-VNC-headset"],
                           capture_output=True, timeout=10)
        except (OSError, subprocess.TimeoutExpired):
            pass
        if sink_exists(name):
            print(f"Created the sound output '{name}'")
            return True
        if time.monotonic() >= deadline:
            print(f"Could not create the sound output '{name}' (is PulseAudio or PipeWire running?)")
            return False
        time.sleep(1)


def capture_command(sink=None):
    if shutil.which("parec"):
        return ["parec", f"--device={sink}.monitor" if sink else "--device=@DEFAULT_MONITOR@", "--format=s16le", f"--rate={RATE}",
                f"--channels={CHANNELS}", "--latency-msec=20", "--raw"]
    if shutil.which("pw-record"):
        # Record the default sink's monitor on PipeWire without the pulse tools.
        return ["pw-record", "-P", "{ stream.capture.sink=true }"] + (["--target", sink] if sink else []) + \
               ["--format=s16", f"--rate={RATE}", f"--channels={CHANNELS}", "-"]
    sys.exit("Neither parec (pulseaudio-utils) nor pw-record (pipewire) was found. "
             "Install one, e.g. 'sudo apt install pulseaudio-utils'.")


def capture_loop(sink=None):
    cmd = capture_command(sink)
    print("Capturing with:", " ".join(cmd))
    while True:
        if sink:
            ensure_sink(sink)  # again after a sound server restart
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        while True:
            data = proc.stdout.read(CHUNK_BYTES)
            if not data:
                break
            broadcast(data)
        proc.wait()
        print("Capture ended, restarting in 2 s…")
        time.sleep(2)


def tone_loop():
    print("TEST TONE: 440 Hz beep every second")
    frame, nxt = 0, time.monotonic()
    while True:
        out = bytearray()
        for _ in range(RATE // 100):
            v = int(math.sin(2 * math.pi * 440 * frame / RATE) * 6000) if frame % RATE < RATE // 4 else 0
            out += struct.pack("<hh", v, v)
            frame += 1
        broadcast(bytes(out))
        nxt += 0.01
        time.sleep(max(0, nxt - time.monotonic()))


def local_ips():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 9))  # no packet is sent; just picks the outgoing interface
        return [s.getsockname()[0]]
    except OSError:
        return []


def main():
    ap = argparse.ArgumentParser(description="Send this PC's sound to Quest VNC.")
    ap.add_argument("--port", type=int, default=5910)
    ap.add_argument("--password", help="require this password (recommended)")
    ap.add_argument("--password-file", metavar="FILE",
                    help="read the password from the first line of FILE (keeps it out of the process list)")
    ap.add_argument("--sink", metavar="NAME",
                    help="send only what plays on the virtual output NAME (created if missing)")
    ap.add_argument("--setup-sink", action="store_true",
                    help="with --sink: create the output, waiting up to 30 s for the sound server, then exit")
    ap.add_argument("--test-tone", action="store_true", help="send a beep instead of the PC's sound")
    args = ap.parse_args()
    if args.setup_sink:
        if not args.sink:
            ap.error("--setup-sink needs --sink NAME")
        sys.exit(0 if ensure_sink(args.sink, wait=30) else 1)
    if args.password and args.password_file:
        ap.error("use --password or --password-file, not both")
    password = args.password
    if args.password_file:
        try:
            with open(args.password_file, encoding="utf-8") as f:
                password = f.readline().rstrip("\r\n")
        except OSError as e:
            sys.exit(f"Cannot read the password file: {e}")
    password = password.encode() if password else None

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("0.0.0.0", args.port))
    srv.listen(8)

    if args.test_tone:
        threading.Thread(target=tone_loop, daemon=True).start()
    else:
        threading.Thread(target=capture_loop, args=(args.sink,), daemon=True).start()
    print(f"Listening on port {args.port}" + (" (password required)" if password else
          " (no password set: anyone on your network can listen)"))
    for ip in local_ips():
        print(f"  This PC: {ip}")
    print("Leave this running while you use Quest VNC. Press Ctrl+C to stop.")
    try:
        while True:
            sock, addr = srv.accept()
            threading.Thread(target=handle, args=(sock, addr, password), daemon=True).start()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
