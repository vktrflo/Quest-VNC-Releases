# Quest VNC for Linux: one-step setup

This sets up everything the Quest VNC headset app needs on a Linux PC:

- **TigerVNC** with its own virtual desktop (a separate screen just for the headset, like
  `vncserver :1`). Your physical screen is left alone, and the virtual desktop keeps running
  when you take the headset off.
- **The Quest VNC sound sender**, so you hear the virtual desktop's sound in the headset.

Both run as background services of your user and start by themselves.

## Install

Open a terminal in this folder and run, as your normal user (not with `sudo`):

```
./install.sh
```

It asks a few questions; press Enter to take the suggested answer.

1. **Missing packages.** If TigerVNC, `vncpasswd`, `xauth`, Python 3 or the PulseAudio tools
   (`pactl`, `parec`) are missing, it offers to install them with your package manager
   (apt, dnf, pacman or zypper). This is the only part that needs `sudo`, apart from the
   firewall and the start-at-boot steps below. Nothing already installed is installed again.
2. **Desktop.** It picks a desktop that runs well in a virtual screen, in this order:
   XFCE, MATE, LXQt, Cinnamon, LXDE, KDE Plasma (X11), GNOME. If you have several, you choose.
   If you have none (or only GNOME / KDE), it offers to install XFCE.
3. **VNC port** (default 5901) and **sound port** (default 5910). They must differ and must not
   be used by another program; the installer checks.
4. **Screen size** (default 1920x1080). The headset can change it later while connected.
5. **Password**, typed twice. The headset uses it for both the picture and the sound.
   Use at least 6 characters. VNC only checks the first 8, so 8 is the useful length.
6. **Start at boot without signing in** (default yes). See below.
7. **Firewall.** If `ufw` or `firewalld` is on, it offers to open the two ports.

At the end it starts everything and prints the PC's address and both ports, for example:

```
Quest VNC is set up.
  This PC:     192.168.1.20  (my-pc)
  VNC port:    5901   (display :1, 1920x1080, XFCE)
  Sound port:  5910
```

### In the headset

In Quest VNC, add this PC (or use **Scan**) and connect with the password you chose.

- If you chose a **sound port other than 5910**, open the PC's **Edit** screen and set
  **Audio port** to that number (the installer reminds you).
- **Scan** looks at VNC ports 5900 to 5903. With another VNC port, add the PC by its
  address and port instead.
- The app uses the PC's VNC password for the sound too, so there's nothing else to set.
  If your password is longer than 8 characters, type all of it in the app.

## Start at boot without signing in

Normally your own background services only run while you are signed in. The installer can
turn on systemd's **linger** for your user, so the virtual desktop and the sound start when
the PC boots, even if nobody signs in on the screen. That suits a PC you only use from the
headset. It runs `loginctl enable-linger <you>` (with `sudo` if your system asks for it).

Answer **no** (or pass `--no-boot`) and it starts when you sign in instead.

### Sound when nobody is signed in

The sender needs your sound server (PipeWire or PulseAudio) to be running. The installer
makes sure its user services are enabled (`pipewire.socket`, `pipewire-pulse.socket` and
`wireplumber.service`, or `pulseaudio.socket`), so it starts with linger too.

The installer also gives the virtual desktop its **own sound output** called
"Quest-VNC-headset" (a virtual "null sink"). Apps on the virtual desktop play into it, and the
sender sends only that to the headset. This means:

- sound works even on a PC with no speakers or with nobody signed in (a signed-out PC
  often has no usable sound card for your user),
- the virtual desktop's sound doesn't play on the PC's speakers, and the physical screen's
  sound doesn't go to the headset.

If you hear nothing, check that your sound server runs (`pactl info` should answer), and see
the sender's messages with `journalctl --user -u questvnc-audio`.

## The desktop on the virtual screen

The virtual screen runs a normal desktop session (for example `startxfce4`) with its own
D-Bus session. You can be signed in on the physical screen with the same user at the same
time. XFCE, MATE and LXQt handle that well.

**GNOME** usually refuses a second session for a user who is already signed in on the screen,
and GNOME 49 and later have no X11 session that could run on a VNC screen at all. **KDE
Plasma** may also fail to start a second session while you use Plasma on the screen. If the
headset shows a black screen, install XFCE (`sudo apt install xfce4`, or let the installer
do it) and run `./install.sh` again.

Signing out inside the headset just starts a fresh desktop.

## Change ports, password or desktop

Run `./install.sh` again. It shows your current settings as the defaults, so press Enter
for anything you want to keep, and answer **no** to "Keep the current password?" to set a
new one. It also updates the sound sender. Your services restart with the new settings.

## Uninstall

```
./install.sh --uninstall
```

This stops and removes the services and the installer's files (the sender in
`~/.local/share/questvnc` and the password files in `~/.config/questvnc`). It asks before
closing the firewall ports it opened, before turning linger off again, and before removing
the packages it installed (the default is to keep them).

## Scripted installs

Every question has an option, and `--yes` takes the given value, the current one or the
default without asking:

```
QUESTVNC_PASSWORD='s3cret99' ./install.sh --yes --vnc-port 5901 --sound-port 5910 --geometry 2560x1440
./install.sh --yes --password-file /root/vncpw --desktop mate --no-firewall
./install.sh --uninstall --yes
```

| Option | Environment variable | Meaning |
|---|---|---|
| `--vnc-port N` | `QUESTVNC_VNC_PORT` | VNC port (default 5901) |
| `--sound-port N` | `QUESTVNC_SOUND_PORT` | sound port (default 5910) |
| `--password-file F` | `QUESTVNC_PASSWORD` (the password itself) | password; with `--yes` and neither given, the current password is kept |
| `--geometry WxH` | `QUESTVNC_GEOMETRY` | screen size (default 1920x1080) |
| `--desktop NAME` | `QUESTVNC_DESKTOP` | `xfce`, `mate`, `lxqt`, `cinnamon`, `lxde`, `kde`, `gnome`, or any command that starts a session |
| `--display N` | `QUESTVNC_DISPLAY` | X display number (default: VNC port − 5900, so 5901 is `:1`; otherwise the first free one from `:10`) |
| `--no-boot` | | don't turn on linger |
| `--no-firewall` | | leave the firewall alone |
| `--no-start` | | set everything up but don't start it now |
| `--yes` | | don't ask anything |

## What gets installed where

| File | What it is |
|---|---|
| `~/.config/systemd/user/questvnc.target` | starts the three services below (enabled for `default.target`) |
| `~/.config/systemd/user/questvnc-xvnc.service` | TigerVNC: `Xtigervnc :1 -rfbport 5901 -rfbauth … -SecurityTypes VncAuth -localhost=0 -geometry 1920x1080 -depth 24 -AlwaysShared -AcceptSetDesktopSize` (`Xvnc` on Fedora, Arch and openSUSE) |
| `~/.config/systemd/user/questvnc-desktop.service` | the desktop session on that display, under `dbus-run-session` |
| `~/.config/systemd/user/questvnc-audio.service` | the sound sender |
| `~/.local/share/questvnc/questvnc-audio.py` | the sound sender program |
| `~/.local/share/questvnc/questvnc-helper` | small helper the services use (X cookie, wait for the display) |
| `~/.config/questvnc/vncpasswd` | the VNC password, in VNC's own format (only you can read it) |
| `~/.config/questvnc/audio-password` | the sound password (only you can read it) |
| `~/.config/questvnc/Xauthority` | the virtual display's X cookie, made fresh at each start |
| `~/.config/questvnc/linux-install.conf` | your answers, used as defaults the next time |

Only you (and root) can open programs on the virtual display: it uses an X cookie and does not
listen on X's TCP port. TigerVNC itself listens on the network on the VNC port.

Handy commands:

```
systemctl --user status questvnc-xvnc questvnc-desktop questvnc-audio
systemctl --user restart questvnc.target
systemctl --user stop questvnc.target       # until the next boot or sign-in
journalctl --user -u questvnc-desktop -e    # why the desktop didn't start
```

## Replacing Quest VNC Server

This replaces the earlier Quest VNC Server for Linux (which shared the physical screen on port
5900). If you installed that, remove it with its own `./install.sh --uninstall`, so it stops
sharing your screen and checking for updates.

## Note for packaging

`install.sh` looks for `questvnc-audio.py` next to itself first, then in
`../../audio-sender/linux/` (the layout of the source tree). When making a download, put
`questvnc-audio.py` in the same folder as `install.sh` and this README.
